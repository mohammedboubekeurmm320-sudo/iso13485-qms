-- Demo Users for ISO 13485 QMS Application
-- Run this script in your Supabase SQL Editor to create demo users

-- Note: These users will need to be created through Supabase Auth
-- The passwords are set to 'password123' for all demo accounts

-- First, let's create a function to easily assign roles to users
CREATE OR REPLACE FUNCTION assign_user_role(user_email TEXT, user_role TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE profiles
  SET role = user_role::user_role
  WHERE email = user_email;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- The profiles will be automatically created when users sign up through the app
-- Below are the emails that should be used for demo accounts:

/*

DEMO ACCOUNT CREDENTIALS
========================

1. Quality Manager (Full Access)
   Email: quality@example.com
   Password: password123
   Role: quality_manager
   Permissions: All

2. Auditor
   Email: auditor@example.com  
   Password: password123
   Role: auditor
   Permissions: Create audits, CAPAs, NCRs

3. Document Controller
   Email: documents@example.com
   Password: password123
   Role: document_controller
   Permissions: Manage documents and training

4. Executive
   Email: executive@example.com
   Password: password123
   Role: executive
   Permissions: View reports, approve documents

5. Operator (Read-only)
   Email: operator@example.com
   Password: password123
   Role: operator
   Permissions: Read-only access

INSTRUCTIONS:
=============

1. Go to your Supabase Dashboard
2. Navigate to Authentication > Users
3. Click "Add user" for each demo account
4. Use the email and password listed above
5. After creating users, their profile will be automatically created with 'operator' role
6. Run the update queries below to assign the correct roles:

*/

-- Update roles for demo users (run after users are created)
-- These will only work if the users exist in the auth.users table

-- UPDATE profiles SET role = 'quality_manager' WHERE email = 'quality@example.com';
-- UPDATE profiles SET role = 'auditor' WHERE email = 'auditor@example.com';
-- UPDATE profiles SET role = 'document_controller' WHERE email = 'documents@example.com';
-- UPDATE profiles SET role = 'executive' WHERE email = 'executive@example.com';
-- UPDATE profiles SET role = 'operator' WHERE email = 'operator@example.com';
