-- =============================================
-- PHASE 2: Billing & Subscription Tables
-- Supabase SQL Migration Script
-- =============================================

-- =============================================
-- TABLE: subscription_plans
-- =============================================
CREATE TABLE IF NOT EXISTS public.subscription_plans (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    price_monthly INTEGER NOT NULL, -- cents
    price_yearly INTEGER NOT NULL, -- cents
    features JSONB DEFAULT '[]',
    limits JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed default plans
INSERT INTO subscription_plans (id, name, description, price_monthly, price_yearly, features, limits, sort_order) VALUES
('starter', 'Starter', 'Pour les petites équipes', 4900, 47000, 
 '["Gestion documentaire ISO 13485", "Jusqu''à 5 utilisateurs", "Support par email", "1 Go stockage"]',
 '{"users": 5, "storage_gb": 1, "documents": 100}', 1),
('professional', 'Professional', 'Pour les entreprises en croissance', 9900, 95000, 
 '["Toutes les fonctionnalités Starter", "Jusqu''à 20 utilisateurs", "Support prioritaire", "10 Go stockage", "API access", "Audit trail avancé"]',
 '{"users": 20, "storage_gb": 10, "documents": 1000, "api_access": true}', 2),
('enterprise', 'Enterprise', 'Pour les grandes organisations', 0, 0, 
 '["Toutes les fonctionnalités Professional", "Utilisateurs illimités", "Support dédié", "Stockage illimité", "On-premise option", "SSO/SAML", "Formation personnalisée"]',
 '{"users": null, "storage_gb": null, "documents": null, "api_access": true, "sso": true, "dedicated_support": true}', 3)
ON CONFLICT (id) DO NOTHING;

-- =============================================
-- TABLE: subscriptions
-- =============================================
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    stripe_subscription_id TEXT UNIQUE,
    stripe_customer_id TEXT,
    stripe_price_id TEXT,
    plan_id TEXT NOT NULL REFERENCES subscription_plans(id),
    status TEXT NOT NULL DEFAULT 'trialing',
    current_period_start TIMESTAMPTZ DEFAULT NOW(),
    current_period_end TIMESTAMPTZ,
    cancel_at_period_end BOOLEAN DEFAULT false,
    trial_end TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: invoices
-- =============================================
CREATE TABLE IF NOT EXISTS public.invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    stripe_invoice_id TEXT UNIQUE,
    stripe_payment_intent_id TEXT,
    amount INTEGER NOT NULL,
    currency TEXT DEFAULT 'EUR',
    status TEXT NOT NULL DEFAULT 'draft',
    invoice_number TEXT,
    pdf_url TEXT,
    hosted_invoice_url TEXT,
    invoice_date TIMESTAMPTZ DEFAULT NOW(),
    due_date TIMESTAMPTZ,
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: payment_methods
-- =============================================
CREATE TABLE IF NOT EXISTS public.payment_methods (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    stripe_payment_method_id TEXT UNIQUE NOT NULL,
    stripe_customer_id TEXT NOT NULL,
    type TEXT DEFAULT 'card',
    brand TEXT,
    last4 TEXT NOT NULL,
    exp_month INTEGER,
    exp_year INTEGER,
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- INDEXES
-- =============================================
CREATE INDEX IF NOT EXISTS idx_subscriptions_org ON subscriptions(organization_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_invoices_org ON invoices(organization_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_payment_methods_org ON payment_methods(organization_id);

-- =============================================
-- RLS POLICIES
-- =============================================

-- Subscriptions: only org members
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view subscriptions" ON subscriptions
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Org members can insert subscriptions" ON subscriptions
    FOR INSERT WITH CHECK (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Owners/Admins can update subscriptions" ON subscriptions
    FOR UPDATE USING (
        organization_id IN (
            SELECT organization_id FROM organization_members 
            WHERE user_id = auth.uid() AND role IN ('owner', 'admin')
        )
    );

-- Invoices: only org members
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view invoices" ON invoices
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

-- Payment methods: only org members
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view payment methods" ON payment_methods
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Org members can insert payment methods" ON payment_methods
    FOR INSERT WITH CHECK (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Org members can delete payment methods" ON payment_methods
    FOR DELETE USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

-- =============================================
-- FUNCTION: Get subscription with plan details
-- =============================================
CREATE OR REPLACE FUNCTION public.get_subscription_with_plan(p_org_id UUID)
RETURNS TABLE (
    subscription_id UUID,
    status TEXT,
    plan_id TEXT,
    plan_name TEXT,
    price_monthly INTEGER,
    price_yearly INTEGER,
    current_period_end TIMESTAMPTZ,
    trial_end TIMESTAMPTZ,
    cancel_at_period_end BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.id,
        s.status,
        s.plan_id,
        p.name,
        p.price_monthly,
        p.price_yearly,
        s.current_period_end,
        s.trial_end,
        s.cancel_at_period_end
    FROM subscriptions s
    JOIN subscription_plans p ON s.plan_id = p.id
    WHERE s.organization_id = p_org_id
    ORDER BY s.created_at DESC
    LIMIT 1;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
