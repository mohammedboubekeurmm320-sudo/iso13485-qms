-- =============================================
-- PHASE 4: Compliance & Regulatory Tables
-- Supabase SQL Migration Script
-- =============================================

-- =============================================
-- TABLE: audit_trail (enhanced 21 CFR Part 11)
-- =============================================
CREATE TABLE IF NOT EXISTS public.audit_trail (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    user_email TEXT,
    action TEXT NOT NULL, -- CREATE, READ, UPDATE, DELETE, SIGN, EXPORT, LOGIN, LOGOUT
    entity_type TEXT NOT NULL, -- document, capa, ncr, audit, etc.
    entity_id UUID,
    entity_name TEXT,
    old_value JSONB,
    new_value JSONB,
    description TEXT,
    ip_address TEXT,
    user_agent TEXT,
    hash TEXT NOT NULL, -- SHA-256 hash for integrity
    previous_hash TEXT, -- Chain for immutability
    signature_id UUID, -- If this is a signature record
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: electronic_signatures
-- =============================================
CREATE TABLE IF NOT EXISTS public.electronic_signatures (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL, -- document, capa, ncr, audit_report
    document_id UUID NOT NULL,
    document_hash TEXT NOT NULL, -- Hash of document at time of signing
    signature_hash TEXT NOT NULL, -- Hash including user + timestamp + document
    reason TEXT NOT NULL, -- Reason for signing
    signed_at TIMESTAMPTZ DEFAULT NOW(),
    is_valid BOOLEAN DEFAULT true,
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: legal_documents (versioned)
-- =============================================
CREATE TABLE IF NOT EXISTS public.legal_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type TEXT NOT NULL, -- privacy_policy, terms_of_service, DPA, cookie_policy
    version TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT NOT NULL, -- Markdown content
    is_active BOOLEAN DEFAULT true,
    effective_date TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: user_consents (RGPD)
-- =============================================
CREATE TABLE IF NOT EXISTS public.user_consents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    document_type TEXT NOT NULL,
    document_version TEXT NOT NULL,
    consent_given BOOLEAN NOT NULL,
    consent_at TIMESTAMPTZ DEFAULT NOW(),
    ip_address TEXT,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- =============================================
-- TABLE: compliance_reports
-- =============================================
CREATE TABLE IF NOT EXISTS public.compliance_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID REFERENCES organizations(id) ON DELETE SET NULL,
    type TEXT NOT NULL, -- audit_summary, document_list, training_report, etc.
    title TEXT NOT NULL,
    period_start TIMESTAMPTZ NOT NULL,
    period_end TIMESTAMPTZ NOT NULL,
    filters JSONB DEFAULT '{}',
    status TEXT DEFAULT 'pending', -- pending, generating, completed, failed
    file_url TEXT,
    generated_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

-- =============================================
-- INDEXES
-- =============================================
CREATE INDEX IF NOT EXISTS idx_audit_org ON audit_trail(organization_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_trail(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_trail(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_trail(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signatures_doc ON electronic_signatures(document_type, document_id);
CREATE INDEX IF NOT EXISTS idx_consents_user ON user_consents(user_id);

-- =============================================
-- RLS POLICIES
-- =============================================

-- Audit Trail: Only org members can view
ALTER TABLE audit_trail ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view audit trail" ON audit_trail
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

-- Electronic Signatures: Only org members
ALTER TABLE electronic_signatures ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view signatures" ON electronic_signatures
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Users can create signatures" ON electronic_signatures
    FOR INSERT WITH CHECK (user_id = auth.uid());

-- Legal Documents: Public read for active docs
ALTER TABLE legal_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view active legal docs" ON legal_documents
    FOR SELECT USING (is_active = true);

-- User Consents: Only own consents
ALTER TABLE user_consents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own consents" ON user_consents
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can insert own consents" ON user_consents
    FOR INSERT WITH CHECK (user_id = auth.uid());

-- Compliance Reports: Only org members
ALTER TABLE compliance_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Org members can view reports" ON compliance_reports
    FOR SELECT USING (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

CREATE POLICY "Users can create reports" ON compliance_reports
    FOR INSERT WITH CHECK (
        organization_id IN (SELECT organization_id FROM organization_members WHERE user_id = auth.uid())
    );

-- =============================================
-- FUNCTION: Create audit log entry with hash
-- =============================================
CREATE OR REPLACE FUNCTION public.create_audit_log(
    p_organization_id UUID,
    p_user_id UUID,
    p_user_email TEXT,
    p_action TEXT,
    p_entity_type TEXT,
    p_entity_id UUID,
    p_entity_name TEXT,
    p_old_value JSONB DEFAULT NULL,
    p_new_value JSONB DEFAULT NULL,
    p_description TEXT DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
    v_id UUID;
    v_data TEXT;
    v_hash TEXT;
    v_previous_hash TEXT;
BEGIN
    -- Get previous hash
    SELECT hash INTO v_previous_hash
    FROM audit_trail
    WHERE organization_id = p_organization_id
    ORDER BY created_at DESC
    LIMIT 1;

    -- Create data string for hashing
    v_data := COALESCE(p_organization_id::TEXT, '') ||
              COALESCE(p_user_id::TEXT, '') ||
              COALESCE(p_action, '') ||
              COALESCE(p_entity_type, '') ||
              COALESCE(p_entity_id::TEXT, '') ||
              COALESCE(p_new_value::TEXT, '') ||
              COALESCE(NOW()::TEXT, '') ||
              COALESCE(v_previous_hash, '');

    -- Generate hash
    v_hash := encode(digest(v_data, 'sha256'), 'hex');

    -- Insert audit log
    INSERT INTO audit_trail (
        organization_id,
        user_id,
        user_email,
        action,
        entity_type,
        entity_id,
        entity_name,
        old_value,
        new_value,
        description,
        hash,
        previous_hash,
        created_at
    ) VALUES (
        p_organization_id,
        p_user_id,
        p_user_email,
        p_action,
        p_entity_type,
        p_entity_id,
        p_entity_name,
        p_old_value,
        p_new_value,
        p_description,
        v_hash,
        v_previous_hash,
        NOW()
    )
    RETURNING id INTO v_id;

    RETURN v_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
