import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useOrganization } from '@/contexts/OrganizationContext';

export interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price_monthly: number;
  price_yearly: number;
  features: string[];
  limits: Record<string, any>;
  sort_order: number;
}

export interface Subscription {
  id: string;
  organization_id: string;
  stripe_subscription_id?: string;
  stripe_customer_id?: string;
  stripe_price_id?: string;
  plan_id: string;
  status: 'active' | 'trialing' | 'past_due' | 'canceled' | 'unpaid';
  current_period_start?: string;
  current_period_end?: string;
  cancel_at_period_end: boolean;
  trial_end?: string;
  created_at: string;
  plan?: SubscriptionPlan;
}

export interface Invoice {
  id: string;
  organization_id: string;
  stripe_invoice_id?: string;
  amount: number;
  currency: string;
  status: 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';
  invoice_number?: string;
  pdf_url?: string;
  hosted_invoice_url?: string;
  invoice_date: string;
  paid_at?: string;
}

interface SubscriptionContextType {
  subscription: Subscription | null;
  plans: SubscriptionPlan[];
  invoices: Invoice[];
  isLoading: boolean;
  error: string | null;
  createCheckoutSession: (planId: string, billingCycle: 'monthly' | 'yearly') => Promise<string>;
  createPortalSession: () => Promise<string>;
  cancelSubscription: () => Promise<void>;
  reactivateSubscription: () => Promise<void>;
  updateSubscription: (newPlanId: string) => Promise<void>;
  refreshSubscription: () => Promise<void>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export const SubscriptionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentOrg } = useOrganization();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load plans
  const loadPlans = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('is_active', true)
        .order('sort_order');

      if (error) throw error;
      setPlans(data || []);
    } catch (err: any) {
      console.error('Error loading plans:', err);
    }
  }, []);

  // Load subscription for current org
  const loadSubscription = useCallback(async () => {
    if (!currentOrg) {
      setSubscription(null);
      setIsLoading(false);
      return;
    }

    try {
      const { data: sub, error } = await supabase
        .from('subscriptions')
        .select(`
          *,
          plan:subscription_plans(*)
        `)
        .eq('organization_id', currentOrg.id)
        .in('status', ['active', 'trialing', 'past_due', 'canceled'])
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      if (sub) {
        setSubscription(sub as any);
      } else {
        setSubscription(null);
      }
    } catch (err: any) {
      console.error('Error loading subscription:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, [currentOrg]);

  // Load invoices
  const loadInvoices = useCallback(async () => {
    if (!currentOrg) {
      setInvoices([]);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('invoices')
        .select('*')
        .eq('organization_id', currentOrg.id)
        .order('invoice_date', { ascending: false })
        .limit(10);

      if (error) throw error;
      setInvoices(data || []);
    } catch (err: any) {
      console.error('Error loading invoices:', err);
    }
  }, [currentOrg]);

  // Load all data
  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await Promise.all([loadPlans(), loadSubscription(), loadInvoices()]);
    };
    loadData();
  }, [loadPlans, loadSubscription, loadInvoices]);

  // Create checkout session (calls backend API)
  const createCheckoutSession = async (planId: string, billingCycle: 'monthly' | 'yearly'): Promise<string> => {
    if (!currentOrg) throw new Error('No organization selected');

    // In production, this would call your backend API
    // which creates the Stripe checkout session
    const response = await fetch('/api/stripe/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        organizationId: currentOrg.id,
        planId,
        billingCycle,
      }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to create checkout session');
    }

    const { url } = await response.json();
    return url;
  };

  // Create portal session
  const createPortalSession = async (): Promise<string> => {
    if (!currentOrg) throw new Error('No organization selected');

    const response = await fetch('/api/stripe/portal', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        organizationId: currentOrg.id,
      }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to create portal session');
    }

    const { url } = await response.json();
    return url;
  };

  // Cancel subscription
  const cancelSubscription = async (): Promise<void> => {
    if (!subscription?.stripe_subscription_id) {
      throw new Error('No active subscription');
    }

    const response = await fetch('/api/stripe/cancel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscriptionId: subscription.stripe_subscription_id,
      }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to cancel subscription');
    }

    await loadSubscription();
  };

  // Reactivate subscription
  const reactivateSubscription = async (): Promise<void> => {
    if (!subscription?.stripe_subscription_id) {
      throw new Error('No active subscription');
    }

    const response = await fetch('/api/stripe/reactivate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscriptionId: subscription.stripe_subscription_id,
      }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to reactivate subscription');
    }

    await loadSubscription();
  };

  // Update subscription (change plan)
  const updateSubscription = async (newPlanId: string): Promise<void> => {
    if (!subscription?.stripe_subscription_id) {
      throw new Error('No active subscription');
    }

    const response = await fetch('/api/stripe/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        subscriptionId: subscription.stripe_subscription_id,
        newPlanId,
      }),
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.error || 'Failed to update subscription');
    }

    await loadSubscription();
  };

  // Refresh subscription
  const refreshSubscription = async () => {
    await Promise.all([loadSubscription(), loadInvoices()]);
  };

  return (
    <SubscriptionContext.Provider
      value={{
        subscription,
        plans,
        invoices,
        isLoading,
        error,
        createCheckoutSession,
        createPortalSession,
        cancelSubscription,
        reactivateSubscription,
        updateSubscription,
        refreshSubscription,
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
};

export const useSubscription = () => {
  const context = useContext(SubscriptionContext);
  if (context === undefined) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
};
