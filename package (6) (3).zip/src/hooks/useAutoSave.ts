import { useState, useEffect, useCallback, useRef } from 'react';

export interface UseAutoSaveOptions<T> {
  key: string; // Unique key for localStorage
  debounceMs?: number; // Debounce time for auto-save (default: 2000ms)
  onSave?: (data: T) => void; // Optional callback when data is saved
  enableAutoSave?: boolean; // Enable/disable auto-save (default: true)
}

export interface UseAutoSaveReturn<T> {
  data: T;
  setData: (data: T | ((prev: T) => T)) => void;
  isSaving: boolean;
  lastSaved: Date | null;
  hasUnsavedChanges: boolean;
  saveNow: () => void;
  clearSavedData: () => void;
  restoreData: () => T | null;
  error: string | null;
}

/**
 * Custom hook for automatic form data saving to localStorage
 * Provides draft management functionality for forms
 */
export function useAutoSave<T extends Record<string, unknown>>(
  initialData: T,
  options: UseAutoSaveOptions<T>
): UseAutoSaveReturn<T> {
  const {
    key,
    debounceMs = 2000,
    onSave,
    enableAutoSave = true,
  } = options;

  const [data, setDataState] = useState<T>(initialData);
  const [isSaving, setIsSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<Date | null>(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const dataRef = useRef<T>(initialData);

  // Update ref when data changes
  useEffect(() => {
    dataRef.current = data;
  }, [data]);

  // Save function
  const saveToStorage = useCallback((dataToSave: T) => {
    if (!enableAutoSave) return;
    
    try {
      setIsSaving(true);
      setError(null);
      
      const storageKey = `qms_draft_${key}`;
      const savedData = {
        data: dataToSave,
        savedAt: new Date().toISOString(),
        version: '1.0',
      };
      
      localStorage.setItem(storageKey, JSON.stringify(savedData));
      
      setLastSaved(new Date());
      setHasUnsavedChanges(false);
      
      if (onSave) {
        onSave(dataToSave);
      }
    } catch (err) {
      console.error('Auto-save error:', err);
      setError('Failed to save draft. Data may be lost.');
    } finally {
      setIsSaving(false);
    }
  }, [key, enableAutoSave, onSave]);

  // Debounced save effect
  useEffect(() => {
    if (!enableAutoSave || !hasUnsavedChanges) return;

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      saveToStorage(dataRef.current);
    }, debounceMs);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [data, hasUnsavedChanges, debounceMs, enableAutoSave, saveToStorage]);

  // Set data with tracking
  const setData = useCallback((newData: T | ((prev: T) => T)) => {
    setDataState((prev) => {
      const updated = typeof newData === 'function' 
        ? (newData as (prev: T) => T)(prev) 
        : newData;
      
      // Check if data actually changed
      const hasChanged = JSON.stringify(updated) !== JSON.stringify(prev);
      if (hasChanged) {
        setHasUnsavedChanges(true);
      }
      
      return updated;
    });
  }, []);

  // Manual save function
  const saveNow = useCallback(() => {
    saveToStorage(dataRef.current);
  }, [saveToStorage]);

  // Clear saved data
  const clearSavedData = useCallback(() => {
    try {
      const storageKey = `qms_draft_${key}`;
      localStorage.removeItem(storageKey);
      setDataState(initialData);
      setLastSaved(null);
      setHasUnsavedChanges(false);
      setError(null);
    } catch (err) {
      console.error('Error clearing draft:', err);
    }
  }, [key, initialData]);

  // Restore saved data from localStorage
  const restoreData = useCallback((): T | null => {
    try {
      const storageKey = `qms_draft_${key}`;
      const saved = localStorage.getItem(storageKey);
      
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.data && parsed.savedAt) {
          setDataState(parsed.data);
          setLastSaved(new Date(parsed.savedAt));
          setHasUnsavedChanges(false);
          return parsed.data;
        }
      }
      return null;
    } catch (err) {
      console.error('Error restoring draft:', err);
      return null;
    }
  }, [key]);

  // Load saved data on mount
  useEffect(() => {
    const saved = restoreData();
    if (saved) {
      console.log(`Draft restored for ${key}`);
    }
  }, []); // Only run on mount

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return {
    data,
    setData,
    isSaving,
    lastSaved,
    hasUnsavedChanges,
    saveNow,
    clearSavedData,
    restoreData,
    error,
  };
}

export default useAutoSave;
