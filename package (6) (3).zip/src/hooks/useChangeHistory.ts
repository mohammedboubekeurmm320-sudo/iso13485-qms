import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export type ChangeType = 'create' | 'update' | 'delete' | 'view' | 'export' | 'sign' | 'approve' | 'reject';

export interface ChangeRecord {
  id: string;
  entityType: string;
  entityId: string;
  entityName: string;
  changeType: ChangeType;
  fieldName?: string;
  oldValue?: string;
  newValue?: string;
  description: string;
  userId: string;
  userName: string;
  userEmail: string;
  userRole: string;
  ipAddress?: string;
  userAgent?: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}

export interface UseChangeHistoryReturn {
  changes: ChangeRecord[];
  isLoading: boolean;
  error: string | null;
  addChange: (change: Omit<ChangeRecord, 'id' | 'timestamp' | 'userId' | 'userName' | 'userEmail' | 'userRole' | 'ipAddress' | 'userAgent'>) => Promise<void>;
  getChanges: () => Promise<void>;
  getChangesByField: (fieldName: string) => ChangeRecord[];
  getChangesByType: (changeType: ChangeType) => ChangeRecord[];
}

// Default demo data for when database is not available
const getDemoChanges = (entityType: string, entityId: string): ChangeRecord[] => {
  const now = new Date();
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);

  return [
    {
      id: 'demo-1',
      entityType,
      entityId,
      entityName: 'Sample Record',
      changeType: 'create',
      description: 'Record created',
      userId: 'user-1',
      userName: 'Sarah Chen',
      userEmail: 'sarah.chen@example.com',
      userRole: 'Quality Manager',
      timestamp: lastWeek.toISOString(),
    },
    {
      id: 'demo-2',
      entityType,
      entityId,
      entityName: 'Sample Record',
      changeType: 'update',
      fieldName: 'status',
      oldValue: 'Draft',
      newValue: 'In Review',
      description: 'Status changed from Draft to In Review',
      userId: 'user-1',
      userName: 'Sarah Chen',
      userEmail: 'sarah.chen@example.com',
      userRole: 'Quality Manager',
      timestamp: yesterday.toISOString(),
    },
    {
      id: 'demo-3',
      entityType,
      entityId,
      entityName: 'Sample Record',
      changeType: 'approve',
      description: 'Record approved',
      userId: 'user-2',
      userName: 'Michael Torres',
      userEmail: 'michael.torres@example.com',
      userRole: 'Document Control Manager',
      timestamp: now.toISOString(),
    },
  ];
};

export function useChangeHistory(entityType: string, entityId: string): UseChangeHistoryReturn {
  const { user } = useAuth();
  const [changes, setChanges] = useState<ChangeRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (entityType && entityId) {
      getChanges();
    }
  }, [entityType, entityId]);

  const getChanges = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { data, error: fetchError } = await supabase
        .from('change_history')
        .select('*')
        .eq('entity_type', entityType)
        .eq('entity_id', entityId)
        .order('timestamp', { ascending: false });

      if (fetchError) {
        console.warn('Could not fetch from database, using demo data');
        setChanges(getDemoChanges(entityType, entityId));
        return;
      }

      const mappedChanges: ChangeRecord[] = (data || []).map((row: Record<string, unknown>) => ({
        id: row.id as string,
        entityType: row.entity_type as string,
        entityId: row.entity_id as string,
        entityName: row.entity_name as string,
        changeType: row.change_type as ChangeType,
        fieldName: row.field_name as string | undefined,
        oldValue: row.old_value as string | undefined,
        newValue: row.new_value as string | undefined,
        description: row.description as string,
        userId: row.user_id as string,
        userName: row.user_name as string,
        userEmail: row.user_email as string,
        userRole: row.user_role as string,
        ipAddress: row.ip_address as string | undefined,
        userAgent: row.user_agent as string | undefined,
        timestamp: row.timestamp as string,
        metadata: row.metadata as Record<string, unknown> | undefined,
      }));

      setChanges(mappedChanges);
    } catch (err) {
      console.error('Error fetching changes:', err);
      setChanges(getDemoChanges(entityType, entityId));
    } finally {
      setIsLoading(false);
    }
  }, [entityType, entityId]);

  const addChange = useCallback(async (change: Omit<ChangeRecord, 'id' | 'timestamp' | 'userId' | 'userName' | 'userEmail' | 'userRole' | 'ipAddress' | 'userAgent'>) => {
    if (!user) {
      console.warn('User not authenticated, cannot record change');
      return;
    }

    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name, role')
        .eq('id', user.id)
        .single();

      const timestamp = new Date().toISOString();
      const fullChange: ChangeRecord = {
        ...change,
        id: '',
        timestamp,
        userId: user.id,
        userName: profile?.full_name || user.email || 'Unknown',
        userEmail: user.email || '',
        userRole: profile?.role || 'User',
        ipAddress: 'client-ip',
        userAgent: navigator.userAgent,
      };

      const { error: insertError } = await supabase
        .from('change_history')
        .insert({
          entity_type: change.entityType,
          entity_id: change.entityId,
          entity_name: change.entityName,
          change_type: change.changeType,
          field_name: change.fieldName,
          old_value: change.oldValue,
          new_value: change.newValue,
          description: change.description,
          user_id: user.id,
          user_name: fullChange.userName,
          user_email: fullChange.userEmail,
          user_role: fullChange.userRole,
          user_agent: navigator.userAgent,
          timestamp,
        });

      if (insertError) {
        console.warn('Could not save to database, storing locally');
        const localChanges = localStorage.getItem('qms_change_history');
        const parsed = localChanges ? JSON.parse(localChanges) : [];
        fullChange.id = `local-${Date.now()}`;
        parsed.push(fullChange);
        localStorage.setItem('qms_change_history', JSON.stringify(parsed));
      }

      setChanges((prev) => [fullChange, ...prev]);
    } catch (err) {
      console.error('Error adding change:', err);
    }
  }, [user]);

  const getChangesByField = useCallback((fieldName: string): ChangeRecord[] => {
    return changes.filter((change) => change.fieldName === fieldName);
  }, [changes]);

  const getChangesByType = useCallback((changeType: ChangeType): ChangeRecord[] => {
    return changes.filter((change) => change.changeType === changeType);
  }, [changes]);

  return {
    changes,
    isLoading,
    error,
    addChange,
    getChanges,
    getChangesByField,
    getChangesByType,
  };
}

export default useChangeHistory;
