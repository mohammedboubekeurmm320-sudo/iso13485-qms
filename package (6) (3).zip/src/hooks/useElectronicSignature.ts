import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

export interface ElectronicSignature {
  id: string;
  documentId: string;
  documentType: string;
  signerId: string;
  signerName: string;
  signerEmail: string;
  signerRole: string;
  signatureType: 'approval' | 'rejection' | 'review' | 'verification';
  signatureHash: string;
  comments: string;
  ipAddress: string;
  userAgent: string;
  signedAt: string;
  expiresAt?: string;
  isValid: boolean;
  metadata?: Record<string, unknown>;
}

export interface SignatureRequest {
  documentId: string;
  documentType: string;
  signatureType: 'approval' | 'rejection' | 'review' | 'verification';
  comments?: string;
}

export interface UseElectronicSignatureReturn {
  isLoading: boolean;
  error: string | null;
  signature: ElectronicSignature | null;
  signatures: ElectronicSignature[];
  requestSignature: (request: SignatureRequest) => Promise<ElectronicSignature | null>;
  verifySignature: (signatureId: string) => Promise<boolean>;
  getSignaturesForDocument: (documentId: string) => Promise<ElectronicSignature[]>;
  revokeSignature: (signatureId: string, reason: string) => Promise<void>;
  generateHash: (data: string) => string;
}

// Generate cryptographically secure hash for signature
const generateSignatureHash = (signerId: string, documentId: string, timestamp: string, comments: string): string => {
  const data = `${signerId}|${documentId}|${timestamp}|${comments}`;
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const char = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  // Add random component for uniqueness
  const randomComponent = Math.random().toString(36).substring(2, 15);
  return `SIG-${Date.now()}-${Math.abs(hash).toString(36)}-${randomComponent}`.toUpperCase();
};

export function useElectronicSignature() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [signature, setSignature] = useState<ElectronicSignature | null>(null);
  const [signatures, setSignatures] = useState<ElectronicSignature[]>([]);

  // Generate signature hash
  const generateHash = useCallback((data: string): string => {
    return generateSignatureHash(
      user?.id || 'anonymous',
      data,
      new Date().toISOString(),
      ''
    );
  }, [user]);

  // Request and create electronic signature
  const requestSignature = useCallback(async (request: SignatureRequest): Promise<ElectronicSignature | null> => {
    if (!user) {
      setError('User must be authenticated to sign');
      return null;
    }

    setIsLoading(true);
    setError(null);

    try {
      const timestamp = new Date().toISOString();
      const signatureHash = generateSignatureHash(
        user.id,
        request.documentId,
        timestamp,
        request.comments || ''
      );

      // Get user metadata
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name, role')
        .eq('id', user.id)
        .single();

      const newSignature: Omit<ElectronicSignature, 'id'> = {
        documentId: request.documentId,
        documentType: request.documentType,
        signerId: user.id,
        signerName: profile?.full_name || user.email || 'Unknown',
        signerEmail: user.email || '',
        signerRole: profile?.role || 'User',
        signatureType: request.signatureType,
        signatureHash,
        comments: request.comments || '',
        ipAddress: 'client-ip', // Will be handled server-side
        userAgent: navigator.userAgent,
        signedAt: timestamp,
        isValid: true,
      };

      // Save to database (if table exists)
      const { data, error: insertError } = await supabase
        .from('electronic_signatures')
        .insert({
          document_id: request.documentId,
          document_type: request.documentType,
          signer_id: user.id,
          signer_name: newSignature.signerName,
          signer_email: newSignature.signerEmail,
          signer_role: newSignature.signerRole,
          signature_type: request.signatureType,
          signature_hash: signatureHash,
          comments: request.comments,
          user_agent: navigator.userAgent,
          signed_at: timestamp,
          is_valid: true,
        })
        .select()
        .single();

      if (insertError) {
        console.warn('Could not save signature to database, using local storage');
        // Create local signature object
        const localSignature: ElectronicSignature = {
          id: `local-${Date.now()}`,
          ...newSignature,
        };
        setSignature(localSignature);
        return localSignature;
      }

      const savedSignature: ElectronicSignature = {
        id: data.id,
        ...newSignature,
      };

      setSignature(savedSignature);
      return savedSignature;
    } catch (err) {
      console.error('Signature error:', err);
      setError('Failed to create signature');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [user, generateHash]);

  // Verify signature integrity
  const verifySignature = useCallback(async (signatureId: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('electronic_signatures')
        .select('*')
        .eq('id', signatureId)
        .single();

      if (error || !data) {
        // Check local storage for demo signatures
        const localSignatures = localStorage.getItem('qms_signatures');
        if (localSignatures) {
          const parsed = JSON.parse(localSignatures);
          const localSig = parsed.find((s: ElectronicSignature) => s.id === signatureId);
          return localSig?.isValid || false;
        }
        return false;
      }

      // Verify hash integrity
      const expectedHash = generateSignatureHash(
        data.signer_id,
        data.document_id,
        data.signed_at,
        data.comments || ''
      );

      return data.signature_hash === expectedHash && data.is_valid;
    } catch (err) {
      console.error('Verification error:', err);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [generateHash]);

  // Get all signatures for a document
  const getSignaturesForDocument = useCallback(async (documentId: string): Promise<ElectronicSignature[]> => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('electronic_signatures')
        .select('*')
        .eq('document_id', documentId)
        .order('signed_at', { ascending: false });

      if (error) {
        // Fallback to local storage
        const localSignatures = localStorage.getItem('qms_signatures');
        if (localSignatures) {
          const parsed = JSON.parse(localSignatures);
          return parsed.filter((s: ElectronicSignature) => s.documentId === documentId);
        }
        return [];
      }

      return data.map((row) => ({
        id: row.id,
        documentId: row.document_id,
        documentType: row.document_type,
        signerId: row.signer_id,
        signerName: row.signer_name,
        signerEmail: row.signer_email,
        signerRole: row.signer_role,
        signatureType: row.signature_type,
        signatureHash: row.signature_hash,
        comments: row.comments,
        ipAddress: row.ip_address,
        userAgent: row.user_agent,
        signedAt: row.signed_at,
        isValid: row.is_valid,
      }));
    } catch (err) {
      console.error('Error fetching signatures:', err);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Revoke a signature
  const revokeSignature = useCallback(async (signatureId: string, reason: string): Promise<void> => {
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('electronic_signatures')
        .update({
          is_valid: false,
          comments: `REVOKED: ${reason}`,
        })
        .eq('id', signatureId);

      if (error) {
        console.warn('Could not update signature in database');
      }
    } catch (err) {
      console.error('Revocation error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    isLoading,
    error,
    signature,
    signatures,
    requestSignature,
    verifySignature,
    getSignaturesForDocument,
    revokeSignature,
    generateHash,
  };
}

export default useElectronicSignature;
