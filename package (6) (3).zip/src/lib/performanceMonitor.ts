// Performance monitoring utilities for QMS application

export interface PerformanceMetrics {
  pageLoadTime: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  timeToInteractive: number;
  cumulativeLayoutShift: number;
  firstInputDelay: number;
}

export interface UserSessionMetrics {
  sessionId: string;
  startTime: Date;
  pageViews: number;
  interactions: number;
  errors: number;
  averageResponseTime: number;
}

// Core Web Vitals thresholds
export const WEB_VITALS_THRESHOLDS = {
  good: {
    fcp: 1800, // First Contentful Paint (ms)
    lcp: 2500, // Largest Contentful Paint (ms)
    cls: 0.1,  // Cumulative Layout Shift
    fid: 100,  // First Input Delay (ms)
    tti: 3800, // Time to Interactive (ms)
  },
  needsImprovement: {
    fcp: 3000,
    lcp: 4000,
    cls: 0.25,
    fid: 300,
    tti: 7300,
  },
};

class PerformanceMonitor {
  private metrics: PerformanceMetrics | null = null;
  private sessionMetrics: UserSessionMetrics | null = null;
  private observer: PerformanceObserver | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.init();
    }
  }

  private init() {
    // Get navigation timing metrics
    const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
    if (navigation) {
      this.metrics = {
        pageLoadTime: navigation.loadEventEnd - navigation.fetchStart,
        firstContentfulPaint: 0,
        largestContentfulPaint: 0,
        timeToInteractive: navigation.domInteractive - navigation.fetchStart,
        cumulativeLayoutShift: 0,
        firstInputDelay: 0,
      };
    }

    // Set up Performance Observer for Core Web Vitals
    if ('PerformanceObserver' in window) {
      try {
        // Observe Largest Contentful Paint
        const lcpObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          const lastEntry = entries[entries.length - 1] as PerformanceEntry & { renderTime: number; loadTime: number };
          if (this.metrics) {
            this.metrics.largestContentfulPaint = lastEntry.renderTime || lastEntry.loadTime;
          }
        });
        lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });

        // Observe First Input Delay
        const fidObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          const firstEntry = entries[0] as PerformanceEventTiming;
          if (this.metrics) {
            this.metrics.firstInputDelay = firstEntry.processingStart - firstEntry.startTime;
          }
        });
        fidObserver.observe({ entryTypes: ['first-input'] });

        // Observe Cumulative Layout Shift
        const clsObserver = new PerformanceObserver((list) => {
          let clsScore = 0;
          for (const entry of list.getEntries()) {
            const layoutShift = entry as PerformanceEntry & { hadRecentInput: boolean; value: number };
            if (!layoutShift.hadRecentInput) {
              clsScore += layoutShift.value;
            }
          }
          if (this.metrics) {
            this.metrics.cumulativeLayoutShift = clsScore;
          }
        });
        clsObserver.observe({ entryTypes: ['layout-shift'] });

        // Observe First Contentful Paint
        const fcpObserver = new PerformanceObserver((list) => {
          const entries = list.getEntries();
          const fcpEntry = entries.find((entry) => entry.name === 'first-contentful-paint');
          if (fcpEntry && this.metrics) {
            this.metrics.firstContentfulPaint = fcpEntry.startTime;
          }
        });
        fcpObserver.observe({ entryTypes: ['paint'] });

      } catch (error) {
        console.warn('Performance Observer not supported:', error);
      }
    }
  }

  // Get current metrics
  getMetrics(): PerformanceMetrics | null {
    return this.metrics;
  }

  // Start user session tracking
  startSession(sessionId: string): void {
    this.sessionMetrics = {
      sessionId,
      startTime: new Date(),
      pageViews: 0,
      interactions: 0,
      errors: 0,
      averageResponseTime: 0,
    };
  }

  // Track page view
  trackPageView(): void {
    if (this.sessionMetrics) {
      this.sessionMetrics.pageViews++;
    }
  }

  // Track user interaction
  trackInteraction(): void {
    if (this.sessionMetrics) {
      this.sessionMetrics.interactions++;
    }
  }

  // Track error
  trackError(): void {
    if (this.sessionMetrics) {
      this.sessionMetrics.errors++;
    }
  }

  // Track API response time
  trackResponseTime(duration: number): void {
    if (this.sessionMetrics && this.sessionMetrics.averageResponseTime > 0) {
      // Rolling average
      this.sessionMetrics.averageResponseTime = 
        (this.sessionMetrics.averageResponseTime + duration) / 2;
    } else if (this.sessionMetrics) {
      this.sessionMetrics.averageResponseTime = duration;
    }
  }

  // Get session metrics
  getSessionMetrics(): UserSessionMetrics | null {
    return this.sessionMetrics;
  }

  // Get Web Vitals rating
  getWebVitalsRating(): 'good' | 'needs-improvement' | 'poor' {
    if (!this.metrics) return 'needs-improvement';

    const { good } = WEB_VITALS_THRESHOLDS;
    let score = 0;

    if (this.metrics.firstContentfulPaint <= good.fcp) score++;
    if (this.metrics.largestContentfulPaint <= good.lcp) score++;
    if (this.metrics.cumulativeLayoutShift <= good.cls) score++;
    if (this.metrics.firstInputDelay <= good.fid) score++;
    if (this.metrics.timeToInteractive <= good.tti) score++;

    if (score >= 4) return 'good';
    if (score >= 2) return 'needs-improvement';
    return 'poor';
  }

  // Log metrics to console (debug)
  logMetrics(): void {
    if (!this.metrics) {
      console.log('No metrics available yet');
      return;
    }

    console.group('Performance Metrics');
    console.log('Page Load Time:', `${this.metrics.pageLoadTime.toFixed(2)}ms`);
    console.log('First Contentful Paint:', `${this.metrics.firstContentfulPaint.toFixed(2)}ms`);
    console.log('Largest Contentful Paint:', `${this.metrics.largestContentfulPaint.toFixed(2)}ms`);
    console.log('Time to Interactive:', `${this.metrics.timeToInteractive.toFixed(2)}ms`);
    console.log('Cumulative Layout Shift:', this.metrics.cumulativeLayoutShift.toFixed(3));
    console.log('First Input Delay:', `${this.metrics.firstInputDelay.toFixed(2)}ms`);
    console.log('Web Vitals Rating:', this.getWebVitalsRating());
    console.groupEnd();
  }

  // Send metrics to analytics (placeholder)
  sendToAnalytics(): void {
    const metrics = this.getMetrics();
    const session = this.getSessionMetrics();
    
    // In production, this would send to your analytics service
    console.log('Sending metrics to analytics:', { metrics, session });
  }
}

// Singleton instance
export const performanceMonitor = new PerformanceMonitor();

// React hook for performance monitoring
import { useEffect, useCallback } from 'react';

export const usePerformanceMonitor = (componentName: string) => {
  useEffect(() => {
    // Log component mount
    console.log(`[Performance] Component mounted: ${componentName}`);
    const startTime = performance.now();

    return () => {
      const duration = performance.now() - startTime;
      console.log(`[Performance] Component unmounted: ${componentName} (${duration.toFixed(2)}ms)`);
    };
  }, [componentName]);

  const trackInteraction = useCallback((interactionName: string) => {
    const startTime = performance.now();
    return () => {
      const duration = performance.now() - startTime;
      performanceMonitor.trackResponseTime(duration);
      console.log(`[Performance] Interaction: ${interactionName} (${duration.toFixed(2)}ms)`);
    };
  }, []);

  const trackError = useCallback((error: Error) => {
    performanceMonitor.trackError();
    console.error(`[Performance] Error in ${componentName}:`, error);
  }, [componentName]);

  return {
    trackInteraction,
    trackError,
    metrics: performanceMonitor.getMetrics(),
  };
};

export default performanceMonitor;
