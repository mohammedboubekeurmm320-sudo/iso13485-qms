// Chart export utilities for PNG and SVG export

export interface ExportOptions {
  filename?: string;
  format?: 'png' | 'svg' | 'jpeg';
  width?: number;
  height?: number;
  backgroundColor?: string;
  quality?: number;
  title?: string;
  subtitle?: string;
  watermark?: string;
}

/**
 * Export a chart or any SVG/HTML element to image
 */
export const exportToImage = async (
  element: HTMLElement | null,
  options: ExportOptions = {}
): Promise<void> => {
  if (!element) {
    console.error('No element provided for export');
    return;
  }

  const {
    filename = 'chart-export',
    format = 'png',
    width,
    height,
    backgroundColor = '#ffffff',
    quality = 1,
    title,
    subtitle,
    watermark,
  } = options;

  try {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      throw new Error('Could not get canvas context');
    }

    // Get element dimensions
    const rect = element.getBoundingClientRect();
    const scale = window.devicePixelRatio || 1;

    canvas.width = (width || rect.width) * scale;
    canvas.height = (height || rect.height) * scale;

    // Fill background
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add title if provided
    if (title) {
      ctx.fillStyle = '#1f2937';
      ctx.font = `bold ${16 * scale}px Arial, sans-serif`;
      ctx.fillText(title, 20 * scale, 30 * scale);
    }

    // Add subtitle if provided
    if (subtitle) {
      ctx.fillStyle = '#6b7280';
      ctx.font = `${12 * scale}px Arial, sans-serif`;
      ctx.fillText(subtitle, 20 * scale, 50 * scale);
    }

    // Use HTML2Canvas or similar approach for HTML elements
    // For SVG elements, we can use direct serialization
    if (element.tagName.toLowerCase() === 'svg') {
      const svgData = new XMLSerializer().serializeToString(element);
      const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);

      const img = new Image();
      img.onload = () => {
        ctx.drawImage(
          img,
          0,
          (title ? 60 : 20) * scale,
          (width || rect.width) * scale,
          (height || rect.height) * scale * 0.8
        );
        URL.revokeObjectURL(url);

        // Add watermark
        if (watermark) {
          ctx.fillStyle = 'rgba(156, 163, 175, 0.5)';
          ctx.font = `${10 * scale}px Arial, sans-serif`;
          ctx.textAlign = 'right';
          ctx.fillText(
            watermark,
            (canvas.width - 10 * scale),
            (canvas.height - 10 * scale)
          );
        }

        // Download
        downloadCanvas(canvas, filename, format, quality);
      };
      img.src = url;
    } else {
      // For HTML elements, we need html2canvas
      // Using a simple approach with foreignObject in SVG
      const data = await htmlToSvgDataUrl(element);
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(
          img,
          0,
          0,
          canvas.width,
          canvas.height
        );

        // Add watermark
        if (watermark) {
          ctx.fillStyle = 'rgba(156, 163, 175, 0.5)';
          ctx.font = `${10 * scale}px Arial, sans-serif`;
          ctx.textAlign = 'right';
          ctx.fillText(
            watermark,
            (canvas.width - 10 * scale),
            (canvas.height - 10 * scale)
          );
        }

        // Download
        downloadCanvas(canvas, filename, format, quality);
      };
      img.src = data;
    }
  } catch (error) {
    console.error('Export error:', error);
    throw error;
  }
};

/**
 * Convert HTML element to SVG data URL using foreignObject
 */
const htmlToSvgDataUrl = async (element: HTMLElement): Promise<string> => {
  const html = element.outerHTML;
  const width = element.getBoundingClientRect().width;
  const height = element.getBoundingClientRect().height;

  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
      <foreignObject width="100%" height="100%">
        <div xmlns="http://www.w3.org/1999/xhtml">
          ${html}
        </div>
      </foreignObject>
    </svg>
  `;

  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
};

/**
 * Download canvas content as file
 */
const downloadCanvas = (
  canvas: HTMLCanvasElement,
  filename: string,
  format: 'png' | 'svg' | 'jpeg',
  quality: number
): void => {
  let dataUrl: string;
  let mimeType: string;

  switch (format) {
    case 'jpeg':
      dataUrl = canvas.toDataURL('image/jpeg', quality);
      mimeType = 'image/jpeg';
      break;
    case 'svg':
      // Canvas doesn't support SVG export directly
      console.warn('SVG export from canvas not supported, using PNG instead');
      dataUrl = canvas.toDataURL('image/png');
      mimeType = 'image/png';
      break;
    case 'png':
    default:
      dataUrl = canvas.toDataURL('image/png');
      mimeType = 'image/png';
  }

  const link = document.createElement('a');
  link.download = `${filename}.${format === 'svg' ? 'png' : format}`;
  link.href = dataUrl;
  link.type = mimeType;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

/**
 * Export SVG element directly
 */
export const exportSvgElement = (
  svgElement: SVGElement | null,
  options: ExportOptions = {}
): void => {
  if (!svgElement) {
    console.error('No SVG element provided');
    return;
  }

  const {
    filename = 'chart-export',
    format = 'svg',
    width,
    height,
  } = options;

  // Clone the SVG to avoid modifying the original
  const clonedSvg = svgElement.cloneNode(true) as SVGSVGElement;

  // Set dimensions if provided
  if (width) clonedSvg.setAttribute('width', String(width));
  if (height) clonedSvg.setAttribute('height', String(height));

  // Serialize to string
  const serializer = new XMLSerializer();
  let svgString = serializer.serializeToString(clonedSvg);

  // Add XML declaration
  svgString = '<?xml version="1.0" encoding="UTF-8"?>' + svgString;

  // Create blob and download
  const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.download = `${filename}.svg`;
  link.href = url;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
};

/**
 * Export chart using Recharts (common React charting library)
 */
export const exportRechartsChart = async (
  chartContainerRef: React.RefObject<HTMLDivElement>,
  options: ExportOptions = {}
): Promise<void> => {
  if (!chartContainerRef.current) {
    console.error('Chart container ref not provided');
    return;
  }

  // Find SVG element within the container
  const svgElement = chartContainerRef.current.querySelector('svg');

  if (svgElement) {
    exportSvgElement(svgElement, options);
  } else {
    // Fallback: try to export the whole container
    await exportToImage(chartContainerRef.current, options);
  }
};

/**
 * Export utility hook for React components
 */
import { useCallback, useRef } from 'react';

export const useChartExport = (options: ExportOptions = {}) => {
  const chartRef = useRef<HTMLDivElement>(null);

  const exportAsPng = useCallback(async () => {
    if (chartRef.current) {
      await exportToImage(chartRef.current, { ...options, format: 'png' });
    }
  }, [options]);

  const exportAsSvg = useCallback(async () => {
    if (chartRef.current) {
      await exportToImage(chartRef.current, { ...options, format: 'svg' });
    }
  }, [options]);

  const exportAsJpeg = useCallback(async () => {
    if (chartRef.current) {
      await exportToImage(chartRef.current, { ...options, format: 'jpeg' });
    }
  }, [options]);

  return {
    chartRef,
    exportAsPng,
    exportAsSvg,
    exportAsJpeg,
  };
};

export default {
  exportToImage,
  exportSvgElement,
  exportRechartsChart,
  useChartExport,
};
