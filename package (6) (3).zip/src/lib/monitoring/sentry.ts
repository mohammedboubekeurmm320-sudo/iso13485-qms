// Configuration Sentry pour le monitoring d'erreurs
// ISO 13485 compliant error tracking

import * as Sentry from '@sentry/react';

// Configuration de l'environnement
const environment = import.meta.env.VITE_ENVIRONMENT || 'development';
const dsn = import.meta.env.VITE_SENTRY_DSN;

// Initialisation de Sentry
export const initSentry = () => {
  if (!dsn) {
    console.warn('Sentry DSN not configured. Error tracking disabled.');
    return;
  }

  Sentry.init({
    dsn,
    environment,
    
    // Taux d'échantillonnage pour les traces (1.0 = 100%)
    tracesSampleRate: environment === 'production' ? 0.1 : 1.0,
    
    // Taux d'échantillonnage pour les replays de session
    replaysSessionSampleRate: 0.1,
    
    // Taux d'échantillonnage pour les replays en cas d'erreur
    replaysOnErrorSampleRate: 1.0,
    
    // Integrations
    integrations: [
      Sentry.browserTracingIntegration(),
      Sentry.replayIntegration({
        maskAllText: false,
        blockAllMedia: false,
      }),
    ],
    
    // Filtres avant traitement
    beforeSend(event, hint) {
      // Filtrer les erreurs non pertinentes
      const error = hint.originalException;
      
      // Ignorer les erreurs de réseau dans certains cas
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        // Ne pas envoyer les erreurs de réseau silencieuses
        return null;
      }
      
      // Ajouter des données de contexte
      if (event.tags) {
        event.tags.environment = environment;
        event.tags.qmsVersion = '1.0.0';
      }
      
      return event;
    },
    
    // Callback lors de la perte de connexion
    transportOptions: {
      // Fallback si fetch échoue
      fetchSentAtBlocks: true,
    },
  });
};

// Hook pour capturer des messages personnalisés
export const useSentry = () => {
  const captureMessage = (message: string, level: Sentry.SeverityLevel = 'info') => {
    if (dsn) {
      Sentry.captureMessage(message, level);
    }
  };

  const captureException = (error: Error, context?: Record<string, any>) => {
    if (dsn) {
      Sentry.captureException(error, {
        extra: context,
      });
    }
  };

  const setUser = (user: { id: string; email: string; username?: string } | null) => {
    if (dsn) {
      Sentry.setUser(user);
    }
  };

  const addBreadcrumb = (breadcrumb: {
    category?: string;
    message?: string;
    level?: Sentry.SeverityLevel;
    data?: Record<string, any>;
  }) => {
    if (dsn) {
      Sentry.addBreadcrumb({
        timestamp: Date.now() / 1000,
        ...breadcrumb,
      });
    }
  };

  return {
    captureMessage,
    captureException,
    setUser,
    addBreadcrumb,
  };
};

// Wrapper de composant pour capturer les erreurs React
export const SentryErrorBoundary = Sentry.ErrorBoundary;

// Export par défaut
export default {
  initSentry,
  useSentry,
  SentryErrorBoundary,
};
