import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { useCompliance, ComplianceProvider } from '../contexts/ComplianceContext';
import { SupabaseClient } from '@supabase/supabase-js';

// Mock Supabase
const mockSupabase = {
  auth: {
    getUser: vi.fn(),
  },
  from: vi.fn(() => ({
    select: vi.fn().mockReturnThis(),
    eq: vi.fn().mockReturnThis(),
    order: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    single: vi.fn(),
  })),
  rpc: vi.fn(),
};

vi.mock('@/lib/supabase', () => ({
  supabase: mockSupabase,
}));

vi.mock('react-router-dom', () => ({
  ...vi.importActual('react-router-dom'),
  useNavigate: () => vi.fn(),
}));

describe('ComplianceContext', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should provide initial compliance status as compliant when no pending documents', async () => {
    const mockUser = { id: 'user-1', email: 'test@example.com' };
    
    (mockSupabase.auth.getUser as any).mockResolvedValue({
      data: { user: mockUser },
    });
    
    (mockSupabase.from as any).mockImplementation((table: string) => {
      if (table === 'legal_documents') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockResolvedValue({ data: [], error: null }),
          order: vi.fn().mockResolvedValue({ data: [], error: null }),
        };
      }
      if (table === 'user_consents') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockResolvedValue({ data: [], error: null }),
        };
      }
      if (table === 'organization_members') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockReturnThis(),
          single: vi.fn().mockResolvedValue({ data: { organization_id: 'org-1' }, error: null }),
        };
      }
      return {
        select: vi.fn().mockReturnThis(),
        eq: vi.fn().mockReturnThis(),
        order: vi.fn().mockReturnThis(),
        single: vi.fn(),
      };
    });

    const { result } = renderHook(() => useCompliance(), {
      wrapper: ComplianceProvider,
    });

    await waitFor(() => {
      expect(result.current.complianceStatus).toBe('compliant');
    });
  });

  it('should set pending documents when user has not accepted latest version', async () => {
    const mockUser = { id: 'user-1', email: 'test@example.com' };
    const mockDocs = [
      { id: 'doc-1', type: 'terms_of_service', version: '2.0', title: 'CGU', content: 'Content', is_active: true },
    ];
    const mockConsents = [
      { id: 'consent-1', user_id: 'user-1', document_type: 'terms_of_service', document_version: '1.0', consent_given: true },
    ];
    
    (mockSupabase.auth.getUser as any).mockResolvedValue({
      data: { user: mockUser },
    });
    
    (mockSupabase.from as any).mockImplementation((table: string) => {
      if (table === 'legal_documents') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockResolvedValue({ data: mockDocs, error: null }),
          order: vi.fn().mockResolvedValue({ data: mockDocs, error: null }),
        };
      }
      if (table === 'user_consents') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockResolvedValue({ data: mockConsents, error: null }),
        };
      }
      if (table === 'organization_members') {
        return {
          select: vi.fn().mockReturnThis(),
          eq: vi.fn().mockReturnThis(),
          single: vi.fn().mockResolvedValue({ data: { organization_id: 'org-1' }, error: null }),
        };
      }
      return {
        select: vi.fn().mockReturnThis(),
        eq: vi.fn().mockReturnThis(),
        order: vi.fn().mockReturnThis(),
        single: vi.fn(),
      };
    });

    const { result } = renderHook(() => useCompliance(), {
      wrapper: ComplianceProvider,
    });

    await waitFor(() => {
      expect(result.current.pendingDocuments.length).toBeGreaterThan(0);
    });
  });
});
