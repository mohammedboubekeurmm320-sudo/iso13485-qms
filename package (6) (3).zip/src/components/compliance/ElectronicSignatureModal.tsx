import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useOrganization } from '@/contexts/OrganizationContext';
import { supabase } from '@/lib/supabase';
import { FileSignature, Lock, Check, AlertCircle, Loader2, Eye } from 'lucide-react';

interface ElectronicSignatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentType: string;
  documentId: string;
  documentName: string;
  documentContent?: any;
  onSigned?: () => void;
}

const signatureReasons = [
  { id: 'approved', label: 'Approved', description: 'I approve this document for release' },
  { id: 'reviewed', label: 'Reviewed', description: 'I have reviewed this document' },
  { id: 'author', label: 'Author', description: 'I am the author of this document' },
  { id: 'verified', label: 'Verified', description: 'I verify this document is accurate' },
  { id: 'other', label: 'Other', description: 'Other reason (specify below)' },
];

const ElectronicSignatureModal: React.FC<ElectronicSignatureModalProps> = ({
  isOpen,
  onClose,
  documentType,
  documentId,
  documentName,
  documentContent,
  onSigned,
}) => {
  const { user } = useAuth();
  const { currentOrg } = useOrganization();
  const [reason, setReason] = useState<string>('');
  const [customReason, setCustomReason] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const handleSign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !currentOrg) return;

    setError(null);
    setIsLoading(true);

    try {
      // Verify password (in production, this would verify against auth)
      if (!password) {
        throw new Error('Password is required for electronic signature');
      }

      const reasonText = reason === 'other' ? customReason : 
        signatureReasons.find(r => r.id === reason)?.label || 'Other';

      // Create document hash
      const contentString = JSON.stringify(documentContent || {});
      const encoder = new TextEncoder();
      const data = encoder.encode(contentString);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const documentHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

      // Create signature hash including user + timestamp + document
      const signatureData = `${user.id}-${Date.now()}-${documentHash}`;
      const signatureBuffer = encoder.encode(signatureData);
      const signatureHashBuffer = await crypto.subtle.digest('SHA-256', signatureBuffer);
      const signatureHashArray = Array.from(new Uint8Array(signatureHashBuffer));
      const signatureHash = signatureHashArray.map(b => b.toString(16).padStart(2, '0')).join('');

      // Save signature to database
      const { error: signatureError } = await supabase
        .from('electronic_signatures')
        .insert({
          organization_id: currentOrg.id,
          user_id: user.id,
          document_type: documentType,
          document_id: documentId,
          document_hash: documentHash,
          signature_hash: signatureHash,
          reason: reasonText,
          ip_address: '0.0.0.0', // In production, capture real IP
          user_agent: navigator.userAgent,
        });

      if (signatureError) throw signatureError;

      // Create audit log
      await supabase.rpc('create_audit_log', {
        p_organization_id: currentOrg.id,
        p_user_id: user.id,
        p_user_email: user.email,
        p_action: 'SIGN',
        p_entity_type: documentType,
        p_entity_id: documentId,
        p_entity_name: documentName,
        p_description: `Electronic signature: ${reasonText}`,
      });

      setSuccess(true);
      setTimeout(() => {
        onSigned?.();
        onClose();
        // Reset form
        setReason('');
        setCustomReason('');
        setPassword('');
        setSuccess(false);
      }, 2000);

    } catch (err: any) {
      setError(err.message || 'Failed to sign document');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      
      <div className="relative bg-white rounded-xl shadow-xl w-full max-w-lg mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-purple-600">
          <div className="flex items-center gap-3 text-white">
            <FileSignature className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Electronic Signature</h2>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white">
            <AlertCircle className="w-5 h-5" />
          </button>
        </div>

        {/* Warning Banner */}
        <div className="px-6 py-3 bg-amber-50 border-b border-amber-100">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-amber-800">
              <p className="font-medium">Legal Notice</p>
              <p className="text-amber-700">
                This electronic signature is legally binding and compliant with 21 CFR Part 11. 
                It cannot be rejected or denied.
              </p>
            </div>
          </div>
        </div>

        {success ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Document Signed!</h3>
            <p className="text-gray-600">Your electronic signature has been recorded.</p>
          </div>
        ) : (
          <form onSubmit={handleSign} className="p-6 space-y-4">
            {/* Document Info */}
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Signing Document</p>
              <p className="font-medium text-gray-900">{documentName}</p>
              <p className="text-xs text-gray-500 mt-1">ID: {documentId}</p>
            </div>

            {/* Error */}
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-4 h-4" />
                <p className="text-sm">{error}</p>
              </div>
            )}

            {/* Reason Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Reason for Signing *
              </label>
              <div className="space-y-2">
                {signatureReasons.map((r) => (
                  <label
                    key={r.id}
                    className={`flex items-start gap-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                      reason === r.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reason"
                      value={r.id}
                      checked={reason === r.id}
                      onChange={(e) => setReason(e.target.value)}
                      className="mt-1"
                    />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{r.label}</p>
                      <p className="text-xs text-gray-500">{r.description}</p>
                    </div>
                  </label>
                ))}
              </div>
              
              {reason === 'other' && (
                <textarea
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  placeholder="Please specify your reason..."
                  className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  rows={2}
                  required
                />
              )}
            </div>

            {/* Preview Toggle */}
            <button
              type="button"
              onClick={() => setShowPreview(!showPreview)}
              className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
            >
              <Eye className="w-4 h-4" />
              {showPreview ? 'Hide' : 'Show'} Document Preview
            </button>

            {showPreview && documentContent && (
              <div className="p-4 bg-gray-50 border rounded-lg max-h-40 overflow-y-auto">
                <pre className="text-xs text-gray-600 whitespace-pre-wrap">
                  {JSON.stringify(documentContent, null, 2)}
                </pre>
              </div>
            )}

            {/* Password Confirmation */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Lock className="w-4 h-4 inline mr-1" />
                Confirm Your Identity *
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password to sign"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Your password confirms your intent to sign this document
              </p>
            </div>

            {/* Submit */}
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!reason || !password || isLoading}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Signing...
                  </>
                ) : (
                  <>
                    <FileSignature className="w-4 h-4" />
                    Sign Document
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default ElectronicSignatureModal;
