import React, { useState, useEffect } from 'react';
import { useOrganization } from '@/contexts/OrganizationContext';
import { supabase } from '@/lib/supabase';
import { Upload, Loader2, Check, AlertCircle, Palette } from 'lucide-react';

interface OrganizationSettings {
  id?: string;
  organization_id: string;
  primary_color: string;
  logo_url?: string;
  favicon_url?: string;
  email_footer_text?: string;
  custom_domain?: string;
}

const OrganizationBranding: React.FC = () => {
  const { currentOrg } = useOrganization();
  const [settings, setSettings] = useState<OrganizationSettings | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const defaultColors = [
    '#3b82f6', // Blue
    '#10b981', // Green
    '#8b5cf6', // Purple
    '#ec4899', // Pink
    '#f59e0b', // Amber
    '#ef4444', // Red
    '#06b6d4', // Cyan
    '#6366f1', // Indigo
  ];

  useEffect(() => {
    if (currentOrg) {
      loadSettings();
    }
  }, [currentOrg]);

  const loadSettings = async () => {
    if (!currentOrg) return;

    try {
      const { data, error } = await supabase
        .from('organization_settings')
        .select('*')
        .eq('organization_id', currentOrg.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setSettings(data);
      } else {
        // Create default settings
        setSettings({
          organization_id: currentOrg.id,
          primary_color: '#3b82f6',
        });
      }
    } catch (err) {
      console.error('Error loading settings:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    if (!settings || !currentOrg) return;

    setIsSaving(true);
    setMessage(null);

    try {
      const { error } = await supabase
        .from('organization_settings')
        .upsert({
          ...settings,
          organization_id: currentOrg.id,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'organization_id',
        });

      if (error) throw error;

      // Apply theme immediately
      applyTheme(settings.primary_color);

      setMessage({ type: 'success', text: 'Settings saved successfully!' });
    } catch (err) {
      console.error('Error saving settings:', err);
      setMessage({ type: 'error', text: 'Failed to save settings' });
    } finally {
      setIsSaving(false);
    }
  };

  const applyTheme = (color: string) => {
    document.documentElement.style.setProperty('--primary', color);
    document.documentElement.style.setProperty('--primary-foreground', '#ffffff');
  };

  const handleColorChange = (color: string) => {
    setSettings(prev => prev ? { ...prev, primary_color: color } : null);
    applyTheme(color);
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentOrg) return;

    // Validate file
    if (file.size > 2 * 1024 * 1024) {
      setMessage({ type: 'error', text: 'File size must be less than 2MB' });
      return;
    }

    const allowedTypes = ['image/png', 'image/jpeg', 'image/svg+xml'];
    if (!allowedTypes.includes(file.type)) {
      setMessage({ type: 'error', text: 'Allowed formats: PNG, JPG, SVG' });
      return;
    }

    setIsSaving(true);

    try {
      // Upload to Supabase Storage
      const fileName = `${currentOrg.id}/logo.${file.type.split('/')[1]}`;
      const { data, error } = await supabase.storage
        .from('organization-assets')
        .upload(fileName, file, {
          upsert: true,
          contentType: file.type,
        });

      if (error) throw error;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('organization-assets')
        .getPublicUrl(fileName);

      setSettings(prev => prev ? { ...prev, logo_url: publicUrl } : null);
      setMessage({ type: 'success', text: 'Logo uploaded successfully!' });
    } catch (err) {
      console.error('Error uploading logo:', err);
      setMessage({ type: 'error', text: 'Failed to upload logo' });
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!settings) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
          <Palette className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Branding</h3>
          <p className="text-sm text-gray-500">Customize your organization's appearance</p>
        </div>
      </div>

      {/* Message */}
      {message && (
        <div className={`p-4 rounded-lg flex items-center gap-3 ${
          message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {message.type === 'success' ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <p className="text-sm">{message.text}</p>
        </div>
      )}

      {/* Logo Upload */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Organization Logo</h4>
        <div className="flex items-start gap-6">
          <div className="w-24 h-24 rounded-xl border-2 border-dashed border-gray-200 flex items-center justify-center overflow-hidden bg-gray-50">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt="Logo" className="w-full h-full object-contain" />
            ) : (
              <Upload className="w-8 h-8 text-gray-400" />
            )}
          </div>
          <div className="flex-1">
            <label className="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
              <Upload className="w-4 h-4 mr-2 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Upload Logo</span>
              <input
                type="file"
                accept="image/png,image/jpeg,image/svg+xml"
                onChange={handleLogoUpload}
                className="hidden"
                disabled={isSaving}
              />
            </label>
            <p className="text-xs text-gray-500 mt-2">
              PNG, JPG or SVG. Max 2MB. Recommended: 200x200px
            </p>
          </div>
        </div>
      </div>

      {/* Primary Color */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Primary Color</h4>
        <div className="flex flex-wrap gap-3">
          {defaultColors.map((color) => (
            <button
              key={color}
              onClick={() => handleColorChange(color)}
              className={`w-10 h-10 rounded-lg transition-all ${
                settings.primary_color === color
                  ? 'ring-2 ring-offset-2 ring-gray-900 scale-110'
                  : 'hover:scale-105'
              }`}
              style={{ backgroundColor: color }}
            />
          ))}
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={settings.primary_color}
              onChange={(e) => handleColorChange(e.target.value)}
              className="w-10 h-10 rounded-lg border-2 border-gray-200 cursor-pointer"
            />
            <span className="text-sm text-gray-500">{settings.primary_color}</span>
          </div>
        </div>

        {/* Preview */}
        <div className="mt-6 p-4 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-500 mb-2">Preview</p>
          <button
            className="px-4 py-2 rounded-lg text-white font-medium"
            style={{ backgroundColor: settings.primary_color }}
          >
            Primary Button
          </button>
        </div>
      </div>

      {/* Custom Domain */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h4 className="font-medium text-gray-900 mb-4">Custom Domain</h4>
        <input
          type="text"
          value={settings.custom_domain || ''}
          onChange={(e) => setSettings(prev => prev ? { ...prev, custom_domain: e.target.value } : null)}
          placeholder="yourcompany.com"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
        />
        <p className="text-xs text-gray-500 mt-2">
          Point your domain CNAME to our servers to use your own domain
        </p>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 px-6 py-2.5 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors disabled:opacity-50"
        >
          {isSaving ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              Save Changes
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default OrganizationBranding;
