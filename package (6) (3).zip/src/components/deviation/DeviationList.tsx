import React, { useState } from 'react';
import { useDeviation } from '@/contexts/DeviationContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { Plus, Search, AlertTriangle, CheckCircle, Clock, XCircle, AlertCircle, Link } from 'lucide-react';
import { Deviation, DeviationSeverity, DeviationStatus } from '@/types/qms';
import CreateNCRModal from '../CreateNCRModal';
import CreateCAPAModal from '../CreateCAPAModal';

const statusConfig: Record<DeviationStatus, { label: string; color: string; icon: React.ReactNode }> = {
  OPEN: { label: 'Open', color: 'bg-red-100 text-red-800', icon: <AlertCircle className="h-4 w-4" /> },
  UNDER_INVESTIGATION: { label: 'Under Investigation', color: 'bg-blue-100 text-blue-800', icon: <Search className="h-4 w-4" /> },
  QA_REVIEW: { label: 'QA Review', color: 'bg-yellow-100 text-yellow-800', icon: <Clock className="h-4 w-4" /> },
  PENDING_DISPOSITION: { label: 'Pending Disposition', color: 'bg-purple-100 text-purple-800', icon: <AlertTriangle className="h-4 w-4" /> },
  CLOSED: { label: 'Closed', color: 'bg-green-100 text-green-800', icon: <CheckCircle className="h-4 w-4" /> },
  REJECTED: { label: 'Rejected', color: 'bg-gray-100 text-gray-800', icon: <XCircle className="h-4 w-4" /> },
};

const severityConfig: Record<DeviationSeverity, { label: string; color: string }> = {
  MINOR: { label: 'Minor', color: 'bg-blue-100 text-blue-800' },
  MAJOR: { label: 'Major', color: 'bg-orange-100 text-orange-800' },
  CRITICAL: { label: 'Critical', color: 'bg-red-100 text-red-800' },
};

interface DeviationListProps {
  onSelectDeviation?: (id: string) => void;
}

export default function DeviationList({ onSelectDeviation }: DeviationListProps) {
  const { deviations, loading, createDeviation, categories } = useDeviation();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedDeviation, setSelectedDeviation] = useState<Deviation | null>(null);
  const [showCreateNCRModal, setShowCreateNCRModal] = useState(false);
  const [showCreateCAPAModal, setShowCreateCAPAModal] = useState(false);
  const [newDeviation, setNewDeviation] = useState({
    title: '',
    descriptionOfEvent: '',
    severity: 'MINOR' as DeviationSeverity,
    immediateActionTaken: '',
    productQuarantined: false,
    quarantineLotNumber: '',
  });

  const filteredDeviations = deviations.filter(dev => {
    const matchesSearch = dev.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dev.referenceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dev.descriptionOfEvent?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || dev.status === statusFilter;
    const matchesSeverity = severityFilter === 'all' || dev.severity === severityFilter;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  const handleCreate = async () => {
    if (!newDeviation.title || !newDeviation.descriptionOfEvent) return;
    await createDeviation({
      ...newDeviation,
      occurrenceDate: new Date().toISOString(),
    });
    setIsCreateDialogOpen(false);
    setNewDeviation({
      title: '',
      descriptionOfEvent: '',
      severity: 'MINOR',
      immediateActionTaken: '',
      productQuarantined: false,
      quarantineLotNumber: '',
    });
  };

  const stats = {
    total: deviations.length,
    open: deviations.filter(d => d.status === 'OPEN').length,
    investigating: deviations.filter(d => d.status === 'UNDER_INVESTIGATION').length,
    pendingDisposition: deviations.filter(d => d.status === 'PENDING_DISPOSITION').length,
    closed: deviations.filter(d => d.status === 'CLOSED').length,
    critical: deviations.filter(d => d.severity === 'CRITICAL' && d.status !== 'CLOSED').length,
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Open</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.open}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Investigating</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.investigating}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Disposition</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.pendingDisposition}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Closed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.closed}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Critical Open</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.critical}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Actions */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex flex-1 gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-initial">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search deviations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 w-full sm:w-[250px]"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="OPEN">Open</SelectItem>
              <SelectItem value="UNDER_INVESTIGATION">Under Investigation</SelectItem>
              <SelectItem value="QA_REVIEW">QA Review</SelectItem>
              <SelectItem value="PENDING_DISPOSITION">Pending Disposition</SelectItem>
              <SelectItem value="CLOSED">Closed</SelectItem>
            </SelectContent>
          </Select>
          <Select value={severityFilter} onValueChange={setSeverityFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Severity" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="MINOR">Minor</SelectItem>
              <SelectItem value="MAJOR">Major</SelectItem>
              <SelectItem value="CRITICAL">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Report Deviation
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Report New Deviation</DialogTitle>
              <DialogDescription>
                Document any departure from established procedures or specifications.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={newDeviation.title}
                  onChange={(e) => setNewDeviation({ ...newDeviation, title: e.target.value })}
                  placeholder="Brief title of the deviation"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description of Event *</Label>
                <Textarea
                  id="description"
                  value={newDeviation.descriptionOfEvent}
                  onChange={(e) => setNewDeviation({ ...newDeviation, descriptionOfEvent: e.target.value })}
                  placeholder="Detailed description of what happened"
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Severity *</Label>
                  <Select
                    value={newDeviation.severity}
                    onValueChange={(value) => setNewDeviation({ ...newDeviation, severity: value as DeviationSeverity })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="MINOR">Minor</SelectItem>
                      <SelectItem value="MAJOR">Major</SelectItem>
                      <SelectItem value="CRITICAL">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="immediateAction">Immediate Action Taken</Label>
                <Textarea
                  id="immediateAction"
                  value={newDeviation.immediateActionTaken}
                  onChange={(e) => setNewDeviation({ ...newDeviation, immediateActionTaken: e.target.value })}
                  placeholder="What was done immediately to address the deviation?"
                  rows={2}
                />
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="quarantine"
                  checked={newDeviation.productQuarantined}
                  onChange={(e) => setNewDeviation({ ...newDeviation, productQuarantined: e.target.checked })}
                  className="rounded"
                />
                <Label htmlFor="quarantine" className="font-normal">
                  Product has been quarantined
                </Label>
              </div>
              {newDeviation.productQuarantined && (
                <div className="grid gap-2">
                  <Label htmlFor="lotNumber">Quarantine Lot Number</Label>
                  <Input
                    id="lotNumber"
                    value={newDeviation.quarantineLotNumber}
                    onChange={(e) => setNewDeviation({ ...newDeviation, quarantineLotNumber: e.target.value })}
                    placeholder="Enter lot/serial number"
                  />
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleCreate} disabled={!newDeviation.title || !newDeviation.descriptionOfEvent}>
                Report Deviation
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reference</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Severity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Occurrence Date</TableHead>
                <TableHead>CAPA Required</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDeviations.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    No deviations found
                  </TableCell>
                </TableRow>
              ) : (
                filteredDeviations.map((dev) => (
                  <TableRow key={dev.id}>
                    <TableCell className="font-mono text-sm">
                      {dev.referenceNumber}
                    </TableCell>
                    <TableCell className="font-medium">
                      <div>{dev.title}</div>
                      {dev.productQuarantined && (
                        <Badge variant="outline" className="mt-1 text-xs">Quarantined</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge className={severityConfig[dev.severity].color}>
                        {severityConfig[dev.severity].label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={statusConfig[dev.status].color}>
                        {statusConfig[dev.status].label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(dev.occurrenceDate).toLocaleDateString()}
                    </TableCell>
                    <TableCell>
                      {dev.capaRequired ? (
                        <Badge variant="destructive">Yes</Badge>
                      ) : (
                        <Badge variant="outline">No</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        {(dev.status === 'CLOSED' || dev.severity === 'CRITICAL' || dev.severity === 'MAJOR') && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-red-600 border-red-300 hover:bg-red-50"
                              onClick={() => {
                                setSelectedDeviation(dev);
                                setShowCreateNCRModal(true);
                              }}
                            >
                              NCR
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-amber-600 border-amber-300 hover:bg-amber-50"
                              onClick={() => {
                                setSelectedDeviation(dev);
                                setShowCreateCAPAModal(true);
                              }}
                            >
                              CAPA
                            </Button>
                          </>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onSelectDeviation?.(dev.id)}
                        >
                          View
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create NCR Modal - Linked to Deviation */}
      {selectedDeviation && (
        <CreateNCRModal
          isOpen={showCreateNCRModal}
          onClose={() => {
            setShowCreateNCRModal(false);
            setSelectedDeviation(null);
          }}
        />
      )}

      {/* Create CAPA Modal - Linked to Deviation */}
      {selectedDeviation && (
        <CreateCAPAModal
          isOpen={showCreateCAPAModal}
          onClose={() => {
            setShowCreateCAPAModal(false);
            setSelectedDeviation(null);
          }}
        />
      )}
    </div>
  );
}
