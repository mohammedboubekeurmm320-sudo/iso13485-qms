import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useAudits, useCreateAudit } from '../modules/audits/hooks/useAudits';
import { Audit } from '../types/qms';
import { useOrganization } from '@/contexts/OrganizationContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import CreateNCRModal from './CreateNCRModal';
import CreateCAPAModal from './CreateCAPAModal';

const AuditManagement: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const { user } = useAuth();
  const [selectedAudit, setSelectedAudit] = useState<Audit | null>(null);
  const [showNewAuditModal, setShowNewAuditModal] = useState(false);
  const [showCreateNCRModal, setShowCreateNCRModal] = useState(false);
  const [showCreateCAPAModal, setShowCreateCAPAModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  
  // New audit form state
  const [newAuditData, setNewAuditData] = useState({
    title: '',
    type: 'Internal' as string,
    scheduledDate: '',
    leadAuditor: '',
    department: '',
    scope: '',
    auditCriteria: '',
    auditProgram: '',
    standardReferences: '',
    auditees: [] as string[],
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Use React Query hooks for data fetching
  const { data: audits = [], isLoading, error, refetch } = useAudits(currentOrganization?.id || '', {
    type: filterType !== 'all' ? filterType : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
  });
  
  // Use mutations
  const createAuditMutation = useCreateAudit();

  // Handle new audit creation
  const handleCreateAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Authentication required');
      return;
    }

    // Validation
    if (!newAuditData.title.trim()) {
      toast.error('Audit title is required');
      return;
    }
    if (!newAuditData.scheduledDate) {
      toast.error('Scheduled date is required');
      return;
    }
    if (!newAuditData.leadAuditor) {
      toast.error('Lead auditor is required');
      return;
    }
    if (!newAuditData.department) {
      toast.error('Department is required');
      return;
    }

    setIsSubmitting(true);
    try {
      await createAuditMutation.mutateAsync({
        organizationId: currentOrganization.id,
        auditData: {
          title: newAuditData.title,
          type: newAuditData.type as Audit['type'],
          scheduledDate: newAuditData.scheduledDate,
          leadAuditor: newAuditData.leadAuditor,
          department: newAuditData.department,
          scope: newAuditData.scope,
          auditCriteria: newAuditData.auditCriteria,
          auditProgram: newAuditData.auditProgram,
          standardReferences: newAuditData.standardReferences,
          auditees: newAuditData.auditees,
        },
      });
      
      toast.success('Audit created successfully!', {
        description: `Audit has been scheduled for ${newAuditData.scheduledDate}.`,
      });
      
      // Reset form and close modal
      setNewAuditData({
        title: '',
        type: 'Internal',
        scheduledDate: '',
        leadAuditor: '',
        department: '',
        scope: '',
        auditCriteria: '',
        auditProgram: '',
        standardReferences: '',
        auditees: [],
      });
      setShowNewAuditModal(false);
      
      // Refresh the audit list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create audit');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredAudits = useMemo(() => {
    return audits.filter(audit => {
      if (filterType !== 'all' && audit.type !== filterType) return false;
      if (filterStatus !== 'all' && audit.status !== filterStatus) return false;
      return true;
    });
  }, [audits, filterType, filterStatus]);

  const columns = [
    { key: 'auditNumber', header: 'Audit #', sortable: true },
    { key: 'title', header: 'Title', sortable: true },
    { 
      key: 'type', 
      header: 'Type',
      render: (audit: Audit) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          audit.type === 'Internal' ? 'bg-blue-100 text-blue-700' :
          audit.type === 'External' ? 'bg-purple-100 text-purple-700' :
          audit.type === 'Supplier' ? 'bg-green-100 text-green-700' :
          'bg-red-100 text-red-700'
        }`}>
          {audit.type}
        </span>
      )
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (audit: Audit) => <StatusBadge status={audit.status} />
    },
    { key: 'scheduledDate', header: 'Scheduled Date', sortable: true },
    { key: 'leadAuditor', header: 'Lead Auditor', sortable: true },
    { key: 'department', header: 'Department', sortable: true },
    { 
      key: 'findings', 
      header: 'Findings',
      render: (audit: Audit) => (
        <div className="flex items-center gap-2">
          {audit.findings > 0 && (
            <span className="px-2 py-0.5 bg-red-100 text-red-700 rounded text-xs font-medium">
              {audit.findings} NC
            </span>
          )}
          {audit.observations > 0 && (
            <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded text-xs font-medium">
              {audit.observations} OBS
            </span>
          )}
          {audit.findings === 0 && audit.observations === 0 && audit.status === 'Completed' && (
            <span className="text-green-600 text-xs">Clean</span>
          )}
          {audit.status !== 'Completed' && (
            <span className="text-gray-400 text-xs">-</span>
          )}
        </div>
      )
    },
  ];

  const stats = {
    total: audits.length,
    scheduled: audits.filter(a => a.status === 'Scheduled').length,
    inProgress: audits.filter(a => a.status === 'In Progress').length,
    completed: audits.filter(a => a.status === 'Completed').length,
    totalFindings: audits.reduce((sum, a) => sum + a.findings, 0),
  };

  const isoClauseChecklist = [
    { clause: '4.1', title: 'Quality Management System - General Requirements', checked: true },
    { clause: '4.2', title: 'Documentation Requirements', checked: true },
    { clause: '5.1', title: 'Management Commitment', checked: false },
    { clause: '5.2', title: 'Customer Focus', checked: false },
    { clause: '5.3', title: 'Quality Policy', checked: true },
    { clause: '5.4', title: 'Planning', checked: false },
    { clause: '6.1', title: 'Provision of Resources', checked: false },
    { clause: '6.2', title: 'Human Resources', checked: true },
    { clause: '7.1', title: 'Planning of Product Realization', checked: false },
    { clause: '7.2', title: 'Customer-related Processes', checked: false },
    { clause: '7.3', title: 'Design and Development', checked: true },
    { clause: '7.4', title: 'Purchasing', checked: false },
    { clause: '7.5', title: 'Production and Service Provision', checked: true },
    { clause: '8.2', title: 'Monitoring and Measurement', checked: false },
    { clause: '8.3', title: 'Control of Nonconforming Product', checked: true },
    { clause: '8.5', title: 'Improvement', checked: false },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Audit Management</h2>
          <p className="text-gray-500 mt-1">Internal and external audits per ISO 13485 Section 8.2.4</p>
        </div>
        <button
          onClick={() => setShowNewAuditModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Schedule Audit
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total Audits</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Scheduled</p>
          <p className="text-2xl font-bold text-yellow-600 mt-1">{stats.scheduled}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">In Progress</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.inProgress}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Completed</p>
          <p className="text-2xl font-bold text-green-600 mt-1">{stats.completed}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total Findings</p>
          <p className="text-2xl font-bold text-red-600 mt-1">{stats.totalFindings}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Audit Type</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Types</option>
            <option value="Internal">Internal</option>
            <option value="External">External</option>
            <option value="Supplier">Supplier</option>
            <option value="Regulatory">Regulatory</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Scheduled">Scheduled</option>
            <option value="In Progress">In Progress</option>
            <option value="Completed">Completed</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Audit Calendar
          </button>
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Export
          </button>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredAudits}
        columns={columns}
        onRowClick={(audit) => setSelectedAudit(audit)}
        searchPlaceholder="Search audits..."
        searchKeys={['auditNumber', 'title', 'leadAuditor', 'department']}
      />

      {/* Audit Detail Modal */}
      <Modal
        isOpen={!!selectedAudit}
        onClose={() => setSelectedAudit(null)}
        title="Audit Details"
        size="xl"
      >
        {selectedAudit && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="text-lg font-semibold text-gray-900">{selectedAudit.auditNumber}</h4>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${
                    selectedAudit.type === 'Internal' ? 'bg-blue-100 text-blue-700' :
                    selectedAudit.type === 'External' ? 'bg-purple-100 text-purple-700' :
                    selectedAudit.type === 'Supplier' ? 'bg-green-100 text-green-700' :
                    'bg-red-100 text-red-700'
                  }`}>
                    {selectedAudit.type}
                  </span>
                </div>
                <p className="text-gray-700 mt-1">{selectedAudit.title}</p>
              </div>
              <StatusBadge status={selectedAudit.status} />
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Scheduled Date</p>
                <p className="font-medium text-gray-900">{selectedAudit.scheduledDate}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Lead Auditor</p>
                <p className="font-medium text-gray-900">{selectedAudit.leadAuditor}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Department</p>
                <p className="font-medium text-gray-900">{selectedAudit.department}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Auditees</p>
                <p className="font-medium text-gray-900">{selectedAudit.auditees.join(', ')}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Scope</p>
              <p className="text-gray-700">{selectedAudit.scope}</p>
            </div>

            {selectedAudit.status === 'Completed' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-red-50 rounded-lg p-4 border border-red-200">
                  <p className="text-xs text-red-600 uppercase tracking-wider mb-1">Non-Conformances</p>
                  <p className="text-2xl font-bold text-red-700">{selectedAudit.findings}</p>
                </div>
                <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                  <p className="text-xs text-yellow-600 uppercase tracking-wider mb-1">Observations</p>
                  <p className="text-2xl font-bold text-yellow-700">{selectedAudit.observations}</p>
                </div>
              </div>
            )}

            <div className="flex flex-wrap items-center gap-3 pt-4 border-t">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                {selectedAudit.status === 'Scheduled' ? 'Start Audit' : 'View Report'}
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Edit Audit
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                View Checklist
              </button>
            </div>

            {/* Action Buttons for Creating Related Items - ISO 13485 Workflow */}
            {selectedAudit.status === 'Completed' && (
              <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
                <h4 className="text-sm font-semibold text-yellow-900 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                  Actions Following Audit (ISO 13485 Workflow)
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <button 
                    onClick={() => setShowCreateNCRModal(true)}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    Raise NCR
                  </button>
                  <button 
                    onClick={() => setShowCreateCAPAModal(true)}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                    </svg>
                    Initiate CAPA
                  </button>
                </div>
                <p className="text-xs text-yellow-700 mt-2">
                  Create follow-up actions based on audit findings to ensure compliance closure.
                </p>
              </div>
            )}

            {/* Linked Items Section */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                </svg>
                Traceability - Linked Items
              </h4>
              <div className="text-sm text-gray-500">
                {selectedAudit.linkedNCRs && selectedAudit.linkedNCRs.length > 0 ? (
                  <div className="space-y-2">
                    {selectedAudit.linkedNCRs.map((ncr: any) => (
                      <div key={ncr.id} className="flex items-center justify-between p-2 bg-white rounded border">
                        <span className="font-medium text-red-600">{ncr.ncrNumber}</span>
                        <span className="text-gray-500">{ncr.title}</span>
                        <StatusBadge status={ncr.status} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 italic">No linked NCRs or CAPAs</p>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* New Audit Modal */}
      <Modal
        isOpen={showNewAuditModal}
        onClose={() => setShowNewAuditModal(false)}
        title="Schedule New Audit"
        size="xl"
      >
        <form className="space-y-6" onSubmit={handleCreateAudit}>
          {/* ISO 13485 Section 8.2.2 Compliance Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h4 className="font-medium text-blue-900 mb-2">ISO 13485:2016 Section 8.2.2 Compliant</h4>
            <p className="text-sm text-blue-700">Audit planning shall include audit criteria, scope, frequency, and methods.</p>
          </div>

          {/* Audit Identification */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Audit Identification</h4>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Audit Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newAuditData.type}
                  onChange={(e) => setNewAuditData({...newAuditData, type: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="Internal">Internal Audit</option>
                  <option value="External">External Audit</option>
                  <option value="Supplier">Supplier Audit</option>
                  <option value="Regulatory">Regulatory Audit</option>
                  <option value="Unannounced">Unannounced Audit</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Scheduled Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={newAuditData.scheduledDate}
                  onChange={(e) => setNewAuditData({...newAuditData, scheduledDate: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                />
              </div>
            </div>
          </div>

          {/* Audit Details */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Audit Details</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Audit Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newAuditData.title}
                  onChange={(e) => setNewAuditData({...newAuditData, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., Q1 Internal Audit - Production"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Lead Auditor <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={newAuditData.leadAuditor}
                    onChange={(e) => setNewAuditData({...newAuditData, leadAuditor: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    required
                  >
                    <option value="">Select Lead Auditor</option>
                    <option value="Lisa Park">Lisa Park</option>
                    <option value="Michael Torres">Michael Torres</option>
                    <option value="Sarah Chen">Sarah Chen</option>
                    <option value="John Smith">John Smith</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Department <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={newAuditData.department}
                    onChange={(e) => setNewAuditData({...newAuditData, department: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                    required
                  >
                    <option value="">Select Department</option>
                    <option value="Quality Assurance">Quality Assurance</option>
                    <option value="Production">Production</option>
                    <option value="R&D">Research & Development</option>
                    <option value="Supply Chain">Supply Chain</option>
                    <option value="Human Resources">Human Resources</option>
                    <option value="Regulatory Affairs">Regulatory Affairs</option>
                    <option value="Engineering">Engineering</option>
                    <option value="Quality Control">Quality Control</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Audit Criteria & Scope - ISO 13485:8.2.2 */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-3 pb-2 border-b">Audit Criteria & Scope (ISO 13485:8.2.2)</h4>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Audit Criteria</label>
                <input
                  type="text"
                  value={newAuditData.auditCriteria}
                  onChange={(e) => setNewAuditData({...newAuditData, auditCriteria: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., ISO 13485:2016, MDSAP, FDA 21 CFR Part 820"
                />
                <p className="text-xs text-gray-500 mt-1">Standards, regulations, or requirements to be audited against</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Standard References</label>
                <input
                  type="text"
                  value={newAuditData.standardReferences}
                  onChange={(e) => setNewAuditData({...newAuditData, standardReferences: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., ISO 9001, IATF 16949, EN ISO 13485"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Audit Program</label>
                <select
                  value={newAuditData.auditProgram}
                  onChange={(e) => setNewAuditData({...newAuditData, auditProgram: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Audit Program</option>
                  <option value="Annual Schedule">Annual Schedule</option>
                  <option value="Quarterly Review">Quarterly Review</option>
                  <option value="Process Audit">Process Audit</option>
                  <option value="Product Audit">Product Audit</option>
                  <option value="System Audit">System Audit</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Scope</label>
                <textarea
                  rows={3}
                  value={newAuditData.scope}
                  onChange={(e) => setNewAuditData({...newAuditData, scope: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Define the audit scope and objectives - processes, departments, and areas to be audited"
                />
              </div>
            </div>
          </div>

          {/* ISO Clause Checklist */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">ISO 13485 Clauses to Audit</label>
            <div className="max-h-48 overflow-y-auto border border-gray-200 rounded-lg p-3 space-y-2">
              {isoClauseChecklist.map((item) => (
                <label key={item.clause} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                  <input
                    type="checkbox"
                    defaultChecked={item.checked}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-gray-700">{item.clause}</span>
                  <span className="text-sm text-gray-500">- {item.title}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'Creating...' : 'Schedule Audit'}
            </button>
            <button
              type="button"
              onClick={() => setShowNewAuditModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Create NCR Modal - Linked to Audit */}
      <CreateNCRModal
        isOpen={showCreateNCRModal}
        onClose={() => setShowCreateNCRModal(false)}
        sourceAudit={selectedAudit || undefined}
        onSuccess={() => refetch()}
      />

      {/* Create CAPA Modal - Linked to Audit */}
      <CreateCAPAModal
        isOpen={showCreateCAPAModal}
        onClose={() => setShowCreateCAPAModal(false)}
        sourceAudit={selectedAudit || undefined}
        onSuccess={() => refetch()}
      />
    </div>
  );
};

export default AuditManagement;
