import React, { useState } from 'react';
import Modal from '@/components/ui/Modal';
import { useCreateTraining } from '@/modules/training/hooks/useTraining';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { CAPA, Document } from '@/types/qms';

interface CreateTrainingModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceCAPA?: CAPA;
  sourceDocument?: Document;
  onSuccess?: () => void;
}

const CreateTrainingModal: React.FC<CreateTrainingModalProps> = ({
  isOpen,
  onClose,
  sourceCAPA,
  sourceDocument,
  onSuccess,
}) => {
  const { user } = useAuth();
  const createTrainingMutation = useCreateTraining();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Determine pre-filled data based on source
  const getDefaultValues = () => {
    if (sourceCAPA) {
      return {
        trainingTitle: `Training for CAPA ${sourceCAPA.capaNumber}`,
        competenceRequirements: `Training required as corrective action for CAPA ${sourceCAPA.capaNumber}: ${sourceCAPA.title}`,
        effectivenessEvaluation: `Effectiveness to be verified upon completion of CAPA ${sourceCAPA.capaNumber}`,
      };
    }
    if (sourceDocument) {
      return {
        trainingTitle: `Training for Document ${sourceDocument.documentNumber}`,
        competenceRequirements: `Training required for document: ${sourceDocument.title} (${sourceDocument.documentNumber})`,
        effectivenessEvaluation: `Employee must acknowledge and understand document ${sourceDocument.documentNumber}`,
      };
    }
    return {
      trainingTitle: '',
      competenceRequirements: '',
      effectivenessEvaluation: '',
    };
  };
  
  const defaults = getDefaultValues();
  
  const [formData, setFormData] = useState({
    employeeName: '',
    employeeId: '',
    employeeEmail: '',
    department: '',
    jobTitle: '',
    trainingTitle: defaults.trainingTitle,
    trainingType: 'Initial' as 'Initial' | 'Refresher' | 'Certification' | 'On-the-Job' | 'External',
    trainingCategory: 'Quality' as 'GMP' | 'ISO 13485' | 'Quality' | 'Technical' | 'Safety' | 'Regulatory' | 'Software' | 'Process',
    trainingProvider: '',
    trainingLocation: '',
    competenceRequirements: defaults.competenceRequirements,
    skillsMatrixArea: '',
    dueDate: '',
    startDate: '',
    expirationDate: '',
    trainer: '',
    trainingMethod: 'Classroom' as 'Classroom' | 'Online' | 'OJT' | 'Workshop' | 'External Course' | 'Self-Paced',
    trainingDuration: '',
    assessmentMethod: 'Exam' as 'Exam' | 'Practical' | 'Observation' | 'Certification' | 'Portfolio',
    documentRef: sourceDocument?.documentNumber || '',
    effectivenessEvaluation: defaults.effectivenessEvaluation,
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('User not found');
      return;
    }

    if (!formData.employeeName.trim()) {
      toast.error('Employee name is required');
      return;
    }

    if (!formData.trainingTitle.trim()) {
      toast.error('Training title is required');
      return;
    }

    if (!formData.dueDate) {
      toast.error('Due date is required');
      return;
    }

    if (!formData.department.trim()) {
      toast.error('Department is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const training = await createTrainingMutation.mutateAsync({
        input: {
          employeeName: formData.employeeName,
          employeeId: formData.employeeId || undefined,
          employeeEmail: formData.employeeEmail || undefined,
          department: formData.department,
          jobTitle: formData.jobTitle || undefined,
          trainingTitle: formData.trainingTitle,
          trainingType: formData.trainingType,
          trainingCategory: formData.trainingCategory || undefined,
          trainingProvider: formData.trainingProvider || undefined,
          trainingLocation: formData.trainingLocation || undefined,
          competenceRequirements: formData.competenceRequirements || undefined,
          skillsMatrixArea: formData.skillsMatrixArea || undefined,
          dueDate: formData.dueDate,
          startDate: formData.startDate || undefined,
          expirationDate: formData.expirationDate || undefined,
          trainer: formData.trainer || undefined,
          trainingMethod: formData.trainingMethod || undefined,
          trainingDuration: formData.trainingDuration || undefined,
          assessmentMethod: formData.assessmentMethod || undefined,
          documentRef: formData.documentRef || `TR-${Date.now()}`,
          effectivenessCriteria: formData.effectivenessEvaluation || undefined,
          linkedCAPAId: sourceCAPA?.id,
        },
        userId: user.id,
      });

      if (sourceCAPA) {
        toast.success('Training assigned successfully and linked to CAPA!', {
          description: `Training "${training.trainingTitle}" has been created for CAPA ${sourceCAPA.capaNumber}.`,
        });
      } else {
        toast.success('Training assigned successfully!', {
          description: `Training "${training.trainingTitle}" has been created.`,
        });
      }

      // Reset form
      setFormData({
        employeeName: '',
        employeeId: '',
        employeeEmail: '',
        department: '',
        jobTitle: '',
        trainingTitle: '',
        trainingType: 'Initial',
        trainingCategory: 'Quality',
        trainingProvider: '',
        trainingLocation: '',
        competenceRequirements: '',
        skillsMatrixArea: '',
        dueDate: '',
        startDate: '',
        expirationDate: '',
        trainer: '',
        trainingMethod: 'Classroom',
        trainingDuration: '',
        assessmentMethod: 'Exam',
        documentRef: '',
        effectivenessEvaluation: '',
      });

      onSuccess?.();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create training');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Assign Training"
      size="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Source Information */}
        {sourceCAPA && (
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <h4 className="text-sm font-semibold text-green-800 mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Source Information
            </h4>
            <p className="text-sm text-green-700">
              <strong>Source CAPA:</strong> {sourceCAPA.capaNumber} - {sourceCAPA.title}
            </p>
            <p className="text-xs text-green-600 mt-1">
              This training will be linked to the CAPA for effectiveness verification and traceability.
            </p>
          </div>
        )}

        {/* Employee Information */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Employee Information</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Employee Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="employeeName"
                value={formData.employeeName}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Enter employee name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Employee ID
              </label>
              <input
                type="text"
                name="employeeId"
                value={formData.employeeId}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Employee ID"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                type="email"
                name="employeeEmail"
                value={formData.employeeEmail}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="employee@company.com"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Department <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="department"
                value={formData.department}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Department"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Job Title
              </label>
              <input
                type="text"
                name="jobTitle"
                value={formData.jobTitle}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Job title"
              />
            </div>
          </div>
        </div>

        {/* Training Details */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Training Details</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Training Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="trainingTitle"
                value={formData.trainingTitle}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Training title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Training Type
              </label>
              <select
                name="trainingType"
                value={formData.trainingType}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="Initial">Initial</option>
                <option value="Refresher">Refresher</option>
                <option value="Certification">Certification</option>
                <option value="On-the-Job">On-the-Job</option>
                <option value="External">External</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Training Category
              </label>
              <select
                name="trainingCategory"
                value={formData.trainingCategory}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="GMP">GMP</option>
                <option value="ISO 13485">ISO 13485</option>
                <option value="Quality">Quality</option>
                <option value="Technical">Technical</option>
                <option value="Safety">Safety</option>
                <option value="Regulatory">Regulatory</option>
                <option value="Software">Software</option>
                <option value="Process">Process</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Training Method
              </label>
              <select
                name="trainingMethod"
                value={formData.trainingMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="Classroom">Classroom</option>
                <option value="Online">Online</option>
                <option value="OJT">OJT</option>
                <option value="Workshop">Workshop</option>
                <option value="External Course">External Course</option>
                <option value="Self-Paced">Self-Paced</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Training Provider
              </label>
              <input
                type="text"
                name="trainingProvider"
                value={formData.trainingProvider}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Training provider"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <input
                type="text"
                name="trainingLocation"
                value={formData.trainingLocation}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Training location"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Due Date <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                name="dueDate"
                value={formData.dueDate}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Trainer
              </label>
              <input
                type="text"
                name="trainer"
                value={formData.trainer}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Trainer name"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Duration
              </label>
              <input
                type="text"
                name="trainingDuration"
                value={formData.trainingDuration}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="e.g., 4 hours"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                name="trainingStatus"
                value={formData.trainingStatus}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="Scheduled">Scheduled</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
                <option value="Passed">Passed</option>
                <option value="Failed">Failed</option>
                <option value="Expired">Expired</option>
              </select>
            </div>
          </div>
        </div>

        {/* Competence and Assessment */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Competence & Assessment</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Competence Requirements
              </label>
              <textarea
                name="competenceRequirements"
                value={formData.competenceRequirements}
                onChange={handleChange}
                rows={2}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Required competencies..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Skills Matrix Area
              </label>
              <input
                type="text"
                name="skillsMatrixArea"
                value={formData.skillsMatrixArea}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="Skills matrix area"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Assessment Method
              </label>
              <select
                name="assessmentMethod"
                value={formData.assessmentMethod}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
              >
                <option value="Exam">Exam</option>
                <option value="Practical">Practical</option>
                <option value="Observation">Observation</option>
                <option value="Certification">Certification</option>
                <option value="Portfolio">Portfolio</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Effectiveness Evaluation
              </label>
              <textarea
                name="effectivenessEvaluation"
                value={formData.effectivenessEvaluation}
                onChange={handleChange}
                rows={2}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                placeholder="How effectiveness will be evaluated..."
              />
            </div>
          </div>
        </div>

        {/* Notes */}
        <div className="border-t pt-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Notes
          </label>
          <textarea
            name="trainingNotes"
            value={formData.trainingNotes}
            onChange={handleChange}
            rows={2}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            placeholder="Additional notes..."
          />
        </div>

        {/* Form Actions */}
        <div className="flex gap-3 pt-4 border-t">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Creating Training...' : 'Assign Training'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default CreateTrainingModal;
