import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useTrainings, useCreateTraining } from '../modules/training/hooks/useTraining';
import { TrainingRecord } from '../types/qms';
import { useOrganization } from '@/contexts/OrganizationContext';
import { toast } from 'sonner';
import CreateCAPAModal from './CreateCAPAModal';

const TrainingRecords: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const [selectedRecord, setSelectedRecord] = useState<TrainingRecord | null>(null);
  const [showNewTrainingModal, setShowNewTrainingModal] = useState(false);
  const [showCreateCAPAModal, setShowCreateCAPAModal] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterDepartment, setFilterDepartment] = useState<string>('all');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Training form state - ISO 13485:7.2 & 7.3 compliant
  const [newTrainingData, setNewTrainingData] = useState({
    // Employee Information
    employeeName: '',
    employeeId: '',
    employeeEmail: '',
    department: '',
    jobTitle: '',
    
    // Training Details
    trainingTitle: '',
    trainingType: 'Initial' as string,
    trainingCategory: '' as string,
    trainingProvider: '',
    trainingLocation: '',
    
    // Competence requirements
    competenceRequirements: '',
    skillsMatrixArea: '',
    
    // Dates
    dueDate: '',
    startDate: '',
    expirationDate: '',
    
    // Training delivery
    trainer: '',
    trainingMethod: '' as string,
    trainingDuration: '',
    
    // Assessment
    assessmentMethod: '' as string,
    passingScore: 70,
    
    // Documentation
    documentRef: '',
    trainingMaterialRef: '',
    
    // Effectiveness
    effectivenessCriteria: '',
    
    // Links
    linkedCAPAId: '',
    linkedAuditId: '',
  });

  // Use React Query hooks for data fetching
  const { data: trainingRecords = [], isLoading, error, refetch } = useTrainings({
    status: filterStatus !== 'all' ? filterStatus : undefined,
    type: filterType !== 'all' ? filterType : undefined,
    department: filterDepartment !== 'all' ? filterDepartment : undefined,
  });
  
  // Use mutations
  const createTrainingMutation = useCreateTraining();

  // Handle new training creation
  const handleCreateTraining = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization) {
      toast.error('Organization required');
      return;
    }

    // Validation
    if (!newTrainingData.employeeName.trim()) {
      toast.error('Employee name is required');
      return;
    }
    if (!newTrainingData.trainingTitle.trim()) {
      toast.error('Training title is required');
      return;
    }
    if (!newTrainingData.department.trim()) {
      toast.error('Department is required');
      return;
    }

    setIsSubmitting(true);
    try {
      await createTrainingMutation.mutateAsync({
        input: {
          // Employee Information
          employeeName: newTrainingData.employeeName,
          employeeId: newTrainingData.employeeId,
          employeeEmail: newTrainingData.employeeEmail,
          department: newTrainingData.department,
          jobTitle: newTrainingData.jobTitle,
          
          // Training Details
          trainingTitle: newTrainingData.trainingTitle,
          trainingType: newTrainingData.trainingType as 'Initial' | 'Refresher' | 'Certification' | 'On-the-Job' | 'External',
          trainingCategory: newTrainingData.trainingCategory as 'GMP' | 'ISO 13485' | 'Quality' | 'Technical' | 'Safety' | 'Regulatory' | 'Software' | 'Process' | undefined,
          trainingProvider: newTrainingData.trainingProvider,
          trainingLocation: newTrainingData.trainingLocation,
          
          // Competence requirements
          competenceRequirements: newTrainingData.competenceRequirements,
          skillsMatrixArea: newTrainingData.skillsMatrixArea,
          
          // Dates
          dueDate: newTrainingData.dueDate,
          startDate: newTrainingData.startDate,
          expirationDate: newTrainingData.expirationDate,
          
          // Training delivery
          trainer: newTrainingData.trainer,
          trainingMethod: newTrainingData.trainingMethod as 'Classroom' | 'Online' | 'OJT' | 'Workshop' | 'External Course' | 'Self-Paced' | undefined,
          trainingDuration: newTrainingData.trainingDuration,
          
          // Assessment
          assessmentMethod: newTrainingData.assessmentMethod as 'Exam' | 'Practical' | 'Observation' | 'Certification' | 'Portfolio' | undefined,
          passingScore: newTrainingData.passingScore,
          
          // Documentation
          documentRef: newTrainingData.documentRef,
          trainingMaterialRef: newTrainingData.trainingMaterialRef,
          
          // Effectiveness
          effectivenessCriteria: newTrainingData.effectivenessCriteria,
          
          // Links
          linkedCAPAId: newTrainingData.linkedCAPAId,
          linkedAuditId: newTrainingData.linkedAuditId,
        },
        userId: currentOrganization.id,
      });
      
      toast.success('Training assigned successfully!', {
        description: `Training has been assigned to ${newTrainingData.employeeName}.`,
      });
      
      // Reset form and close modal
      setNewTrainingData({
        employeeName: '',
        employeeId: '',
        employeeEmail: '',
        department: '',
        jobTitle: '',
        trainingTitle: '',
        trainingType: 'Initial',
        trainingCategory: '',
        trainingProvider: '',
        trainingLocation: '',
        competenceRequirements: '',
        skillsMatrixArea: '',
        dueDate: '',
        startDate: '',
        expirationDate: '',
        trainer: '',
        trainingMethod: '',
        trainingDuration: '',
        assessmentMethod: '',
        passingScore: 70,
        documentRef: '',
        trainingMaterialRef: '',
        effectivenessCriteria: '',
        linkedCAPAId: '',
        linkedAuditId: '',
      });
      setShowNewTrainingModal(false);
      
      // Refresh the training list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create training');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredRecords = useMemo(() => {
    return trainingRecords.filter(record => {
      if (filterStatus !== 'all' && record.status !== filterStatus) return false;
      if (filterType !== 'all' && record.trainingType !== filterType) return false;
      if (filterDepartment !== 'all' && record.department !== filterDepartment) return false;
      return true;
    });
  }, [trainingRecords, filterStatus, filterType, filterDepartment]);

  const columns = [
    { key: 'employeeName', header: 'Employee', sortable: true },
    { key: 'department', header: 'Department', sortable: true },
    { key: 'trainingTitle', header: 'Training', sortable: true },
    { 
      key: 'trainingType', 
      header: 'Type',
      render: (record: TrainingRecord) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          record.trainingType === 'Initial' ? 'bg-blue-100 text-blue-700' :
          record.trainingType === 'Refresher' ? 'bg-purple-100 text-purple-700' :
          record.trainingType === 'Certification' ? 'bg-green-100 text-green-700' :
          'bg-orange-100 text-orange-700'
        }`}>
          {record.trainingType}
        </span>
      )
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (record: TrainingRecord) => <StatusBadge status={record.status} />
    },
    { key: 'dueDate', header: 'Due Date', sortable: true },
    { 
      key: 'score', 
      header: 'Score',
      render: (record: TrainingRecord) => (
        record.score ? (
          <span className={`font-medium ${record.score >= 80 ? 'text-green-600' : 'text-amber-600'}`}>
            {record.score}%
          </span>
        ) : (
          <span className="text-gray-400">-</span>
        )
      )
    },
    { key: 'trainer', header: 'Trainer', sortable: true },
  ];

  const stats = {
    total: trainingRecords.length,
    completed: trainingRecords.filter(t => t.status === 'Completed').length,
    inProgress: trainingRecords.filter(t => t.status === 'In Progress').length,
    scheduled: trainingRecords.filter(t => t.status === 'Scheduled').length,
    overdue: trainingRecords.filter(t => t.status === 'Overdue').length,
  };

  const complianceRate = Math.round((stats.completed / stats.total) * 100);

  // Competency matrix data
  const competencyMatrix = [
    { employee: 'Sarah Chen', gmp: true, iso13485: true, capa: true, audit: true, risk: true },
    { employee: 'Michael Torres', gmp: true, iso13485: true, capa: true, audit: false, risk: false },
    { employee: 'James Wilson', gmp: false, iso13485: true, capa: false, audit: false, risk: false },
    { employee: 'Emily Rodriguez', gmp: true, iso13485: true, capa: false, audit: false, risk: true },
    { employee: 'Lisa Park', gmp: true, iso13485: true, capa: true, audit: true, risk: true },
    { employee: 'David Martinez', gmp: true, iso13485: true, capa: false, audit: false, risk: false },
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Training Records</h2>
          <p className="text-gray-500 mt-1">Competence and training per ISO 13485 Section 6.2</p>
        </div>
        <button
          onClick={() => setShowNewTrainingModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Assign Training
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total Records</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Completed</p>
          <p className="text-2xl font-bold text-green-600 mt-1">{stats.completed}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">In Progress</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.inProgress}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Scheduled</p>
          <p className="text-2xl font-bold text-yellow-600 mt-1">{stats.scheduled}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 bg-red-50 border-red-200">
          <p className="text-sm text-red-600">Overdue</p>
          <p className="text-2xl font-bold text-red-700 mt-1">{stats.overdue}</p>
        </div>
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white">
          <p className="text-sm text-blue-100">Compliance Rate</p>
          <p className="text-2xl font-bold mt-1">{complianceRate}%</p>
        </div>
      </div>

      {/* Competency Matrix */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Competency Matrix</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-600">Employee</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-gray-600">GMP</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-gray-600">ISO 13485</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-gray-600">CAPA</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-gray-600">Internal Audit</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-gray-600">Risk Mgmt</th>
              </tr>
            </thead>
            <tbody>
              {competencyMatrix.map((row, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-4 text-sm font-medium text-gray-900">{row.employee}</td>
                  <td className="py-3 px-4 text-center">
                    {row.gmp ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                        <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.iso13485 ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                        <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.capa ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                        <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.audit ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                        <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {row.risk ? (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-green-100 rounded-full">
                        <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      </span>
                    ) : (
                      <span className="inline-flex items-center justify-center w-6 h-6 bg-red-100 rounded-full">
                        <svg className="w-4 h-4 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="In Progress">In Progress</option>
            <option value="Scheduled">Scheduled</option>
            <option value="Overdue">Overdue</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Training Type</label>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Types</option>
            <option value="Initial">Initial</option>
            <option value="Refresher">Refresher</option>
            <option value="Certification">Certification</option>
            <option value="On-the-Job">On-the-Job</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
          <select
            value={filterDepartment}
            onChange={(e) => setFilterDepartment(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Departments</option>
            <option value="Quality Assurance">Quality Assurance</option>
            <option value="Production">Production</option>
            <option value="R&D">R&D</option>
            <option value="Supply Chain">Supply Chain</option>
            <option value="Executive">Executive</option>
          </select>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredRecords}
        columns={columns}
        onRowClick={(record) => setSelectedRecord(record)}
        searchPlaceholder="Search training records..."
        searchKeys={['employeeName', 'trainingTitle', 'trainer', 'department']}
      />

      {/* Training Detail Modal */}
      <Modal
        isOpen={!!selectedRecord}
        onClose={() => setSelectedRecord(null)}
        title="Training Record Details"
        size="lg"
      >
        {selectedRecord && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-lg font-semibold text-gray-900">{selectedRecord.trainingTitle}</h4>
                <p className="text-gray-600">{selectedRecord.employeeName} - {selectedRecord.department}</p>
              </div>
              <StatusBadge status={selectedRecord.status} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Training Type</p>
                <p className="font-medium text-gray-900">{selectedRecord.trainingType}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Trainer</p>
                <p className="font-medium text-gray-900">{selectedRecord.trainer}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Due Date</p>
                <p className="font-medium text-gray-900">{selectedRecord.dueDate}</p>
              </div>
              {selectedRecord.completedDate && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Completed Date</p>
                  <p className="font-medium text-gray-900">{selectedRecord.completedDate}</p>
                </div>
              )}
              {selectedRecord.score && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Score</p>
                  <p className={`font-medium ${selectedRecord.score >= 80 ? 'text-green-600' : 'text-amber-600'}`}>
                    {selectedRecord.score}%
                  </p>
                </div>
              )}
              {selectedRecord.expirationDate && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Expiration Date</p>
                  <p className="font-medium text-gray-900">{selectedRecord.expirationDate}</p>
                </div>
              )}
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Document Reference</p>
                <p className="font-medium text-blue-600">{selectedRecord.documentRef}</p>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                {selectedRecord.status === 'Completed' ? 'View Certificate' : 'Mark Complete'}
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Edit Record
              </button>
            </div>

            {/* Training Ineffective - Create CAPA Action */}
            {(selectedRecord.status === 'Failed' || (selectedRecord.score !== undefined && selectedRecord.score < 70)) && (
              <div className="mt-4 p-4 bg-red-50 rounded-lg border border-red-200">
                <h4 className="text-sm font-semibold text-red-800 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  Training Ineffective - Requires CAPA
                </h4>
                <button 
                  onClick={() => setShowCreateCAPAModal(true)}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                  Create CAPA for Ineffective Training
                </button>
                <p className="text-xs text-red-700 mt-2">
                  Per ISO 13485:7.3.1, ineffective training requires corrective action.
                </p>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* New Training Modal - ISO 13485:7.2 & 7.3 Compliant Form */}
      <Modal
        isOpen={showNewTrainingModal}
        onClose={() => setShowNewTrainingModal(false)}
        title="Assign New Training"
        size="2xl"
      >
        <form onSubmit={handleCreateTraining} className="space-y-6">
          {/* Section 1: Employee Information - ISO 13485:7.2 */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <h3 className="text-sm font-semibold text-blue-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              Employee Information (ISO 13485:7.2)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newTrainingData.employeeName}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, employeeName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Enter employee name"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee ID
                </label>
                <input
                  type="text"
                  value={newTrainingData.employeeId}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, employeeId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Employee ID"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Employee Email
                </label>
                <input
                  type="email"
                  value={newTrainingData.employeeEmail}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, employeeEmail: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="employee@company.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Department <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newTrainingData.department}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, department: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Department"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Job Title
                </label>
                <input
                  type="text"
                  value={newTrainingData.jobTitle}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, jobTitle: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Job title"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Skills Matrix Area
                </label>
                <input
                  type="text"
                  value={newTrainingData.skillsMatrixArea}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, skillsMatrixArea: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g., GMP, ISO 13485, CAPA"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Training Details - ISO 13485:7.2 */}
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <h3 className="text-sm font-semibold text-green-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
              Training Details (ISO 13485:7.2)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainingTitle}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingTitle: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Enter training title"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Type <span className="text-red-500">*</span>
                </label>
                <select
                  value={newTrainingData.trainingType}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingType: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  required
                >
                  <option value="Initial">Initial</option>
                  <option value="Refresher">Refresher</option>
                  <option value="Certification">Certification</option>
                  <option value="On-the-Job">On-the-Job</option>
                  <option value="External">External</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Category
                </label>
                <select
                  value={newTrainingData.trainingCategory}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingCategory: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                >
                  <option value="">Select Category</option>
                  <option value="GMP">GMP</option>
                  <option value="ISO 13485">ISO 13485</option>
                  <option value="Quality">Quality</option>
                  <option value="Technical">Technical</option>
                  <option value="Safety">Safety</option>
                  <option value="Regulatory">Regulatory</option>
                  <option value="Software">Software</option>
                  <option value="Process">Process</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Method
                </label>
                <select
                  value={newTrainingData.trainingMethod}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingMethod: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                >
                  <option value="">Select Method</option>
                  <option value="Classroom">Classroom</option>
                  <option value="Online">Online</option>
                  <option value="OJT">On-the-Job Training</option>
                  <option value="Workshop">Workshop</option>
                  <option value="External Course">External Course</option>
                  <option value="Self-Paced">Self-Paced</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Provider
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainingProvider}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingProvider: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Training provider name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Location
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainingLocation}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingLocation: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Training location"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Trainer
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainer}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainer: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Trainer name"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Duration
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainingDuration}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingDuration: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="e.g., 8 hours"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Competence Requirements - ISO 13485:7.2 */}
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <h3 className="text-sm font-semibold text-purple-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Competence Requirements (ISO 13485:7.2)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Competence Requirements
                </label>
                <textarea
                  value={newTrainingData.competenceRequirements}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, competenceRequirements: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="Describe the competence requirements for this training"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Dates - ISO 13485:7.3 */}
          <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
            <h3 className="text-sm font-semibold text-yellow-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              Schedule (ISO 13485:7.3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Start Date
                </label>
                <input
                  type="date"
                  value={newTrainingData.startDate}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, startDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  value={newTrainingData.dueDate}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, dueDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Expiration Date
                </label>
                <input
                  type="date"
                  value={newTrainingData.expirationDate}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, expirationDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 5: Assessment - ISO 13485:7.3 */}
          <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
            <h3 className="text-sm font-semibold text-orange-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
              </svg>
              Assessment (ISO 13485:7.3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Assessment Method
                </label>
                <select
                  value={newTrainingData.assessmentMethod}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, assessmentMethod: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                >
                  <option value="">Select Method</option>
                  <option value="Exam">Exam</option>
                  <option value="Practical">Practical</option>
                  <option value="Observation">Observation</option>
                  <option value="Certification">Certification</option>
                  <option value="Portfolio">Portfolio</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Passing Score (%)
                </label>
                <input
                  type="number"
                  value={newTrainingData.passingScore}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, passingScore: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none"
                  min="0"
                  max="100"
                />
              </div>
            </div>
          </div>

          {/* Section 6: Documentation - ISO 13485:7.3 */}
          <div className="bg-teal-50 rounded-lg p-4 border border-teal-200">
            <h3 className="text-sm font-semibold text-teal-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Documentation (ISO 13485:7.3)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Document Reference <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newTrainingData.documentRef}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, documentRef: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
                  placeholder="e.g., SOP-QMS-001"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Training Material Reference
                </label>
                <input
                  type="text"
                  value={newTrainingData.trainingMaterialRef}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, trainingMaterialRef: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 outline-none"
                  placeholder="Reference to training materials"
                />
              </div>
            </div>
          </div>

          {/* Section 7: Effectiveness - ISO 13485:7.3.1 */}
          <div className="bg-indigo-50 rounded-lg p-4 border border-indigo-200">
            <h3 className="text-sm font-semibold text-indigo-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
              Effectiveness Criteria (ISO 13485:7.3.1)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Effectiveness Criteria
                </label>
                <textarea
                  value={newTrainingData.effectivenessCriteria}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, effectivenessCriteria: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  placeholder="Define criteria for evaluating training effectiveness"
                />
              </div>
            </div>
          </div>

          {/* Section 8: Links to Other Modules */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Links to Other Modules
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked CAPA ID
                </label>
                <input
                  type="text"
                  value={newTrainingData.linkedCAPAId}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, linkedCAPAId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none"
                  placeholder="e.g., CAPA-2025-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked Audit ID
                </label>
                <input
                  type="text"
                  value={newTrainingData.linkedAuditId}
                  onChange={(e) => setNewTrainingData({ ...newTrainingData, linkedAuditId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none"
                  placeholder="e.g., AUD-2025-001"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Assigning Training...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Assign Training
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowNewTrainingModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Create CAPA Modal - Linked to Failed Training */}
      <CreateCAPAModal
        isOpen={showCreateCAPAModal}
        onClose={() => setShowCreateCAPAModal(false)}
      />
    </div>
  );
};

export default TrainingRecords;
