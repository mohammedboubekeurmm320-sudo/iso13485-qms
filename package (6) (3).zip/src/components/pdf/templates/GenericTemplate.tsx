/**
 * Generic PDF Template
 * A flexible template that can be used for any type of report
 */

import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from '@react-pdf/renderer';
import { PDFConfig, formatPDFDate, hexToRGB } from '../../../utils/pdfUtils';

// Register fonts
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf', fontWeight: 'normal' },
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf', fontWeight: 'bold' },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    lineHeight: 1.5,
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#1e40af',
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6b7280',
  },
  documentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    padding: 10,
    backgroundColor: '#f3f4f6',
    borderRadius: 4,
  },
  documentInfoItem: {
    fontSize: 9,
    color: '#4b5563',
  },
  documentInfoLabel: {
    fontWeight: 'bold',
    color: '#1f2937',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#1e40af',
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
    width: 140,
    color: '#374151',
  },
  value: {
    flex: 1,
    color: '#1f2937',
  },
  table: {
    marginTop: 10,
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#1e40af',
    padding: 8,
    borderTopLeftRadius: 4,
    borderTopRightRadius: 4,
  },
  tableHeaderCell: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 9,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    padding: 8,
    backgroundColor: 'white',
  },
  tableRowAlt: {
    backgroundColor: '#f9fafb',
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    textAlign: 'center',
    flex: 1,
  },
  tableCellLeft: {
    textAlign: 'left',
    flex: 2,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 8,
  },
  footerText: {
    fontSize: 8,
    color: '#9ca3af',
  },
  pageNumber: {
    fontSize: 8,
    color: '#9ca3af',
  },
  signatureSection: {
    marginTop: 30,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  signatureRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  signatureBox: {
    width: '45%',
  },
  signatureLine: {
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
    marginBottom: 8,
    paddingBottom: 4,
  },
  signatureLabel: {
    fontSize: 8,
    color: '#6b7280',
  },
  signatureDate: {
    fontSize: 8,
    color: '#6b7280',
    marginTop: 4,
  },
  statusBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    fontSize: 8,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  description: {
    marginTop: 8,
    padding: 10,
    backgroundColor: '#f9fafb',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#1e40af',
  },
  descriptionText: {
    fontSize: 9,
    color: '#374151',
    lineHeight: 1.6,
  },
});

interface GenericPDFProps {
  config: PDFConfig;
  title: string;
  data: Record<string, any>;
  tableData?: Record<string, any>[];
  tableColumns?: { key: string; label: string; width?: number }[];
  notes?: string;
  signatures?: { name: string; role: string; date: string }[];
}

const GenericPDF: React.FC<GenericPDFProps> = ({
  config,
  title,
  data,
  tableData,
  tableColumns,
  notes,
  signatures = [],
}) => {
  const primaryRGB = hexToRGB(config.primaryColor);

  return (
    <Document>
      <Page size={config.pageSize === 'A4' ? 'A4' : config.pageSize === 'LETTER' ? 'LETTER' : 'LEGAL'} style={styles.page}>
        {/* Header */}
        {config.showHeader && (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>{config.headerTitle}</Text>
            <Text style={styles.headerSubtitle}>{config.headerSubtitle}</Text>
          </View>
        )}

        {/* Document Info */}
        <View style={styles.documentInfo}>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Document ID: </Text>
              {config.documentId}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Révision: </Text>
              {config.revision}
            </Text>
          </View>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Date: </Text>
              {formatPDFDate(new Date())}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Auteur: </Text>
              {config.author}
            </Text>
          </View>
        </View>

        {/* Title */}
        <View style={styles.section}>
          <Text style={{ ...styles.sectionTitle, fontSize: 16 }}>{title}</Text>
        </View>

        {/* Data Fields */}
        <View style={styles.section}>
          {Object.entries(data).map(([key, value]) => (
            <View key={key} style={styles.row}>
              <Text style={styles.label}>{key}:</Text>
              <Text style={styles.value}>{String(value) || '-'}</Text>
            </View>
          ))}
        </View>

        {/* Table */}
        {tableData && tableColumns && tableData.length > 0 && (
          <View style={styles.table}>
            <View style={styles.tableHeader}>
              {tableColumns.map((col, index) => (
                <Text
                  key={index}
                  style={[
                    styles.tableHeaderCell,
                    col.width ? { flex: col.width } : { flex: 1 },
                  ]}
                >
                  {col.label}
                </Text>
              ))}
            </View>
            {tableData.map((row, rowIndex) => (
              <View
                key={rowIndex}
                style={[
                  styles.tableRow,
                  rowIndex % 2 === 1 && styles.tableRowAlt,
                ]}
              >
                {tableColumns.map((col, colIndex) => (
                  <Text
                    key={colIndex}
                    style={[
                      styles.tableCell,
                      colIndex === 0 && styles.tableCellLeft,
                      col.width ? { flex: col.width } : { flex: 1 },
                    ]}
                  >
                    {row[col.key] || '-'}
                  </Text>
                ))}
              </View>
            ))}
          </View>
        )}

        {/* Notes */}
        {notes && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes / Observations</Text>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{notes}</Text>
            </View>
          </View>
        )}

        {/* Signatures */}
        {signatures.length > 0 && (
          <View style={styles.signatureSection}>
            <Text style={styles.sectionTitle}>Signatures</Text>
            <View style={styles.signatureRow}>
              {signatures.map((sig, index) => (
                <View key={index} style={styles.signatureBox}>
                  <View style={styles.signatureLine} />
                  <Text style={styles.signatureLabel}>{sig.name}</Text>
                  <Text style={styles.signatureLabel}>{sig.role}</Text>
                  <Text style={styles.signatureDate}>Date: {formatPDFDate(sig.date)}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Footer */}
        {config.showFooter && (
          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>{config.showCompanyName}</Text>
            {config.showDate && (
              <Text style={styles.footerText}>
                Imprimé le {formatPDFDate(new Date())}
              </Text>
            )}
            <Text style={styles.pageNumber} render={({ pageNumber, totalPages }) =>
              `${pageNumber} / ${totalPages}`
            } />
          </View>
        )}
      </Page>
    </Document>
  );
};

export default GenericPDF;
