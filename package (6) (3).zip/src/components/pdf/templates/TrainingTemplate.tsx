/**
 * Training Record PDF Template
 * Professional template for Training reports
 */

import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from '@react-pdf/renderer';
import { PDFConfig, formatPDFDate, getStatusColor } from '../../../utils/pdfUtils';

// Register fonts
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf', fontWeight: 'normal' },
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf', fontWeight: 'bold' },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    lineHeight: 1.5,
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#059669',
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#059669',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6b7280',
  },
  documentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#ecfdf5',
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#059669',
  },
  documentInfoItem: {
    fontSize: 9,
    color: '#4b5563',
  },
  documentInfoLabel: {
    fontWeight: 'bold',
    color: '#1f2937',
  },
  trainingTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#059669',
    marginBottom: 15,
    textAlign: 'center',
    textDecoration: 'underline',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#059669',
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    textTransform: 'uppercase',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
    width: 150,
    color: '#374151',
  },
  value: {
    flex: 1,
    color: '#1f2937',
  },
  description: {
    marginTop: 8,
    padding: 10,
    backgroundColor: '#ecfdf5',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#059669',
  },
  descriptionText: {
    fontSize: 9,
    color: '#374151',
    lineHeight: 1.6,
  },
  statusBox: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    alignSelf: 'flex-start',
  },
  table: {
    marginTop: 10,
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#059669',
    padding: 8,
  },
  tableHeaderCell: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 8,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    padding: 8,
    backgroundColor: 'white',
  },
  tableRowAlt: {
    backgroundColor: '#f9fafb',
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    textAlign: 'center',
    flex: 1,
  },
  tableCellLeft: {
    textAlign: 'left',
    flex: 2,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 8,
  },
  footerText: {
    fontSize: 8,
    color: '#9ca3af',
  },
  pageNumber: {
    fontSize: 8,
    color: '#9ca3af',
  },
  signatureSection: {
    marginTop: 25,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  signatureTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#059669',
    marginBottom: 15,
  },
  signatureRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  signatureBox: {
    width: '30%',
  },
  signatureLine: {
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
    marginBottom: 8,
    paddingBottom: 4,
  },
  signatureLabel: {
    fontSize: 8,
    color: '#6b7280',
  },
  signatureDate: {
    fontSize: 8,
    color: '#6b7280',
    marginTop: 4,
  },
  complianceSummary: {
    flexDirection: 'row',
    marginBottom: 15,
    gap: 10,
  },
  complianceCard: {
    flex: 1,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  complianceNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  complianceLabel: {
    fontSize: 8,
    marginTop: 4,
  },
});

interface TrainingData {
  id: string;
  title: string;
  description: string;
  status: string;
  type: string;
  category: string;
  department: string;
  trainer: string;
  location: string;
  duration: number;
  scheduledDate: string;
  completionDate: string;
  dueDate: string;
  maxParticipants: number;
  currentParticipants: number;
  passingScore: number;
  certificateRequired: boolean;
  notes: string;
}

interface TrainingRecordData {
  id: string;
  employeeName: string;
  employeeId: string;
  department: string;
  status: string;
  score: number;
  passed: boolean;
  attendance: string;
  completedDate: string;
  certificateIssued: boolean;
  certificateDate: string;
  expiryDate: string;
  trainer: string;
  notes: string;
}

interface TrainingPDFProps {
  config: PDFConfig;
  training: TrainingData;
  records?: TrainingRecordData[];
}

const TrainingPDF: React.FC<TrainingPDFProps> = ({ config, training, records = [] }) => {
  const statusColor = getStatusColor(training.status);
  
  const completedCount = records.filter(r => r.status === 'Completed').length;
  const inProgressCount = records.filter(r => r.status === 'In Progress').length;
  const overdueCount = records.filter(r => r.status === 'Overdue').length;
  const passedCount = records.filter(r => r.passed).length;

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        {config.showHeader && (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>{config.headerTitle}</Text>
            <Text style={styles.headerSubtitle}>{config.headerSubtitle}</Text>
          </View>
        )}

        {/* Document Info */}
        <View style={styles.documentInfo}>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Document ID: </Text>
              {config.documentId}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Catégorie: </Text>
              {training.category}
            </Text>
          </View>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Date: </Text>
              {formatPDFDate(new Date())}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Auteur: </Text>
              {config.author}
            </Text>
          </View>
        </View>

        {/* Training Title */}
        <Text style={styles.trainingTitle}>
          FICHE DE FORMATION
        </Text>

        {/* Training ID and Status */}
        <View style={[styles.row, { marginBottom: 15 }]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>N° Formation:</Text>
            <Text style={[styles.value, { fontWeight: 'bold', fontSize: 12 }]}>{training.id}</Text>
          </View>
          <View style={{ flex: 1, alignItems: 'flex-start' }}>
            <Text style={styles.label}>Statut:</Text>
            <View style={[styles.statusBox, { backgroundColor: statusColor }]}>
              <Text style={{ color: 'white' }}>{training.status}</Text>
            </View>
          </View>
        </View>

        {/* Compliance Summary */}
        {records.length > 0 && (
          <View style={styles.complianceSummary}>
            <View style={[styles.complianceCard, { backgroundColor: '#ecfdf5' }]}>
              <Text style={[styles.complianceNumber, { color: '#059669' }]}>{completedCount}</Text>
              <Text style={styles.complianceLabel}>Complétés</Text>
            </View>
            <View style={[styles.complianceCard, { backgroundColor: '#eff6ff' }]}>
              <Text style={[styles.complianceNumber, { color: '#2563eb' }]}>{inProgressCount}</Text>
              <Text style={styles.complianceLabel}>En cours</Text>
            </View>
            <View style={[styles.complianceCard, { backgroundColor: '#fef2f2' }]}>
              <Text style={[styles.complianceNumber, { color: '#dc2626' }]}>{overdueCount}</Text>
              <Text style={styles.complianceLabel}>En retard</Text>
            </View>
            <View style={[styles.complianceCard, { backgroundColor: '#f3f4f6' }]}>
              <Text style={[styles.complianceNumber, { color: '#059669' }]}>
                {records.length > 0 ? Math.round((passedCount / records.length) * 100) : 0}%
              </Text>
              <Text style={styles.complianceLabel}>Taux de réussite</Text>
            </View>
          </View>
        )}

        {/* Section 1: Training Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Informations sur la formation</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Titre:</Text>
            <Text style={styles.value}>{training.title}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Type:</Text>
            <Text style={styles.value}>{training.type}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Catégorie:</Text>
            <Text style={styles.value}>{training.category}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Département:</Text>
            <Text style={styles.value}>{training.department}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Formateur:</Text>
            <Text style={styles.value}>{training.trainer}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Lieu:</Text>
            <Text style={styles.value}>{training.location}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Durée:</Text>
            <Text style={styles.value}>{training.duration} heures</Text>
          </View>
        </View>

        {/* Section 2: Dates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. Échéances</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Date prévue:</Text>
            <Text style={styles.value}>{training.scheduledDate ? formatPDFDate(training.scheduledDate) : '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date d'échéance:</Text>
            <Text style={styles.value}>{training.dueDate ? formatPDFDate(training.dueDate) : '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date de complétion:</Text>
            <Text style={styles.value}>{training.completionDate ? formatPDFDate(training.completionDate) : '-'}</Text>
          </View>
        </View>

        {/* Section 3: Description */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Objectifs de la formation</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{training.description}</Text>
          </View>
        </View>

        {/* Section 4: Requirements */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Exigences</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Participants max:</Text>
            <Text style={styles.value}>{training.maxParticipants}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Score minimum:</Text>
            <Text style={styles.value}>{training.passingScore}%</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Certificat requis:</Text>
            <Text style={styles.value}>{training.certificateRequired ? 'Oui' : 'Non'}</Text>
          </View>
        </View>

        {/* Records Table */}
        {records.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>5. Registre des participants</Text>
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={[styles.tableHeaderCell, { flex: 1.5 }]}>Employé</Text>
                <Text style={[styles.tableHeaderCell, { flex: 1 }]}>Département</Text>
                <Text style={[styles.tableHeaderCell, { flex: 1 }]}>Statut</Text>
                <Text style={[styles.tableHeaderCell, { flex: 0.5 }]}>Note</Text>
                <Text style={[styles.tableHeaderCell, { flex: 1 }]}>Date</Text>
              </View>
              {records.slice(0, 10).map((record, index) => (
                <View key={index} style={[styles.tableRow, index % 2 === 1 && styles.tableRowAlt]}>
                  <Text style={[styles.tableCell, styles.tableCellLeft, { flex: 1.5 }]}>
                    {record.employeeName}
                  </Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>{record.department}</Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>
                    <Text style={{ color: getStatusColor(record.status) }}>{record.status}</Text>
                  </Text>
                  <Text style={[styles.tableCell, { flex: 0.5 }]}>
                    {record.score ? `${record.score}%` : '-'}
                  </Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>
                    {record.completedDate ? formatPDFDate(record.completedDate).split(' ')[0] : '-'}
                  </Text>
                </View>
              ))}
            </View>
            {records.length > 10 && (
              <Text style={{ fontSize: 8, color: '#6b7280', textAlign: 'center', marginTop: 5 }}>
                ... et {records.length - 10} autres participants
              </Text>
            )}
          </View>
        )}

        {/* Notes */}
        {training.notes && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes</Text>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{training.notes}</Text>
            </View>
          </View>
        )}

        {/* Signatures */}
        <View style={styles.signatureSection}>
          <Text style={styles.signatureTitle}>Signatures</Text>
          <View style={styles.signatureRow}>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Formateur</Text>
              <Text style={styles.signatureDate}>{training.trainer}</Text>
              <Text style={styles.signatureDate}></Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Responsable formation</Text>
              <Text style={styles.signatureDate}></Text>
              <Text style={styles.signatureDate}></Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Direction</Text>
              <Text style={styles.signatureDate}></Text>
              <Text style={styles.signatureDate}></Text>
            </View>
          </View>
        </View>

        {/* Footer */}
        {config.showFooter && (
          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>{config.showCompanyName}</Text>
            {config.showDate && (
              <Text style={styles.footerText}>
                Imprimé le {formatPDFDate(new Date())}
              </Text>
            )}
            <Text style={styles.pageNumber} render={({ pageNumber, totalPages }) =>
              `${pageNumber} / ${totalPages}`
            } />
          </View>
        )}
      </Page>
    </Document>
  );
};

export default TrainingPDF;
