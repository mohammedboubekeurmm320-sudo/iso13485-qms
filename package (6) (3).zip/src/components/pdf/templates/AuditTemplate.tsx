/**
 * Audit Report PDF Template
 * Professional template for Audit reports following ISO 13485 requirements
 */

import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from '@react-pdf/renderer';
import { PDFConfig, formatPDFDate, getStatusColor } from '../../../utils/pdfUtils';

// Register fonts
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf', fontWeight: 'normal' },
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf', fontWeight: 'bold' },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    lineHeight: 1.5,
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#7c3aed',
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#7c3aed',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6b7280',
  },
  documentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#f5f3ff',
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#7c3aed',
  },
  documentInfoItem: {
    fontSize: 9,
    color: '#4b5563',
  },
  documentInfoLabel: {
    fontWeight: 'bold',
    color: '#1f2937',
  },
  auditTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#7c3aed',
    marginBottom: 15,
    textAlign: 'center',
    textDecoration: 'underline',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#7c3aed',
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    textTransform: 'uppercase',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
    width: 150,
    color: '#374151',
  },
  value: {
    flex: 1,
    color: '#1f2937',
  },
  description: {
    marginTop: 8,
    padding: 10,
    backgroundColor: '#f5f3ff',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#7c3aed',
  },
  descriptionText: {
    fontSize: 9,
    color: '#374151',
    lineHeight: 1.6,
  },
  statusBox: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    alignSelf: 'flex-start',
  },
  findingsSummary: {
    flexDirection: 'row',
    marginBottom: 15,
    gap: 10,
  },
  findingCard: {
    flex: 1,
    padding: 10,
    borderRadius: 4,
    alignItems: 'center',
  },
  findingNumber: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  findingLabel: {
    fontSize: 8,
    marginTop: 4,
  },
  table: {
    marginTop: 10,
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#7c3aed',
    padding: 8,
  },
  tableHeaderCell: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 8,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    padding: 8,
    backgroundColor: 'white',
  },
  tableRowAlt: {
    backgroundColor: '#f9fafb',
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    textAlign: 'center',
    flex: 1,
  },
  tableCellLeft: {
    textAlign: 'left',
    flex: 2,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 8,
  },
  footerText: {
    fontSize: 8,
    color: '#9ca3af',
  },
  pageNumber: {
    fontSize: 8,
    color: '#9ca3af',
  },
  signatureSection: {
    marginTop: 25,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  signatureTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#7c3aed',
    marginBottom: 15,
  },
  signatureRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  signatureBox: {
    width: '30%',
  },
  signatureLine: {
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
    marginBottom: 8,
    paddingBottom: 4,
  },
  signatureLabel: {
    fontSize: 8,
    color: '#6b7280',
  },
  signatureDate: {
    fontSize: 8,
    color: '#6b7280',
    marginTop: 4,
  },
  checklistItem: {
    flexDirection: 'row',
    marginBottom: 4,
    padding: 4,
  },
  checkbox: {
    width: 14,
    height: 14,
    borderWidth: 1,
    borderColor: '#7c3aed',
    marginRight: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checklistText: {
    fontSize: 9,
    color: '#374151',
    flex: 1,
  },
});

interface FindingData {
  id: string;
  description: string;
  severity: 'Critical' | 'Major' | 'Minor' | 'Observation';
  status: string;
  category: string;
  clause: string;
  rootCause: string;
  correctiveAction: string;
  dueDate: string;
  closedDate: string;
  closedBy: string;
}

interface AuditData {
  id: string;
  title: string;
  type: 'Internal' | 'External' | 'Supplier';
  status: string;
  scope: string;
  objective: string;
  criteria: string;
  department: string;
  location: string;
  leadAuditor: string;
  auditors: string[];
  auditees: string[];
  startDate: string;
  endDate: string;
  findings: number;
  criticalFindings: number;
  majorFindings: number;
  minorFindings: number;
  observations: number;
  summary: string;
  conclusion: string;
  recommendations: string;
  followUpRequired: boolean;
  followUpDate: string;
}

interface AuditPDFProps {
  config: PDFConfig;
  audit: AuditData;
  findings?: FindingData[];
}

const AuditPDF: React.FC<AuditPDFProps> = ({ config, audit, findings = [] }) => {
  const statusColor = getStatusColor(audit.status);
  const severityColors: Record<string, string> = {
    'Critical': '#dc2626',
    'Major': '#ea580c',
    'Minor': '#d97706',
    'Observation': '#6b7280',
  };

  const typeLabels: Record<string, string> = {
    'Internal': 'Audit interne',
    'External': 'Audit externe',
    'Supplier': 'Audit fournisseur',
  };

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        {config.showHeader && (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>{config.headerTitle}</Text>
            <Text style={styles.headerSubtitle}>{config.headerSubtitle}</Text>
          </View>
        )}

        {/* Document Info */}
        <View style={styles.documentInfo}>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Document ID: </Text>
              {config.documentId}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Type: </Text>
              {typeLabels[audit.type] || audit.type}
            </Text>
          </View>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Date: </Text>
              {formatPDFDate(new Date())}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Auteur: </Text>
              {config.author}
            </Text>
          </View>
        </View>

        {/* Audit Title */}
        <Text style={styles.auditTitle}>
          RAPPORT D'AUDIT
        </Text>

        {/* Audit ID and Status */}
        <View style={[styles.row, { marginBottom: 15 }]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>N° Audit:</Text>
            <Text style={[styles.value, { fontWeight: 'bold', fontSize: 12 }]}>{audit.id}</Text>
          </View>
          <View style={{ flex: 1, alignItems: 'flex-start' }}>
            <Text style={styles.label}>Statut:</Text>
            <View style={[styles.statusBox, { backgroundColor: statusColor }]}>
              <Text style={{ color: 'white' }}>{audit.status}</Text>
            </View>
          </View>
        </View>

        {/* Findings Summary */}
        <View style={styles.findingsSummary}>
          <View style={[styles.findingCard, { backgroundColor: '#fef2f2' }]}>
            <Text style={[styles.findingNumber, { color: '#dc2626' }]}>{audit.criticalFindings}</Text>
            <Text style={styles.findingLabel}>Critiques</Text>
          </View>
          <View style={[styles.findingCard, { backgroundColor: '#fff7ed' }]}>
            <Text style={[styles.findingNumber, { color: '#ea580c' }]}>{audit.majorFindings}</Text>
            <Text style={styles.findingLabel}>Majeures</Text>
          </View>
          <View style={[styles.findingCard, { backgroundColor: '#fef3c7' }]}>
            <Text style={[styles.findingNumber, { color: '#d97706' }]}>{audit.minorFindings}</Text>
            <Text style={styles.findingLabel}>Mineures</Text>
          </View>
          <View style={[styles.findingCard, { backgroundColor: '#f3f4f6' }]}>
            <Text style={[styles.findingNumber, { color: '#6b7280' }]}>{audit.observations}</Text>
            <Text style={styles.findingLabel}>Observations</Text>
          </View>
        </View>

        {/* Section 1: Audit Information */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Informations sur l'audit</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Titre:</Text>
            <Text style={styles.value}>{audit.title}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Département:</Text>
            <Text style={styles.value}>{audit.department}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Lieu:</Text>
            <Text style={styles.value}>{audit.location}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Auditeur leader:</Text>
            <Text style={styles.value}>{audit.leadAuditor}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Auditeurs:</Text>
            <Text style={styles.value}>{audit.auditors?.join(', ') || '-'}</Text>
          </View>
        </View>

        {/* Section 2: Dates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. Dates</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Date de début:</Text>
            <Text style={styles.value}>{formatPDFDate(audit.startDate)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date de fin:</Text>
            <Text style={styles.value}>{formatPDFDate(audit.endDate)}</Text>
          </View>
          {audit.followUpRequired && audit.followUpDate && (
            <View style={styles.row}>
              <Text style={styles.label}>Date de suivi:</Text>
              <Text style={styles.value}>{formatPDFDate(audit.followUpDate)}</Text>
            </View>
          )}
        </View>

        {/* Section 3: Scope and Criteria */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Portée et critères</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Portée:</Text>
            <Text style={styles.value}>{audit.scope}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Critères:</Text>
            <Text style={styles.value}>{audit.criteria}</Text>
          </View>
        </View>

        {/* Section 4: Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Résumé de l'audit</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{audit.summary}</Text>
          </View>
        </View>

        {/* Section 5: Conclusion */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>5. Conclusion</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{audit.conclusion}</Text>
          </View>
        </View>

        {/* Section 6: Recommendations */}
        {audit.recommendations && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>6. Recommandations</Text>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{audit.recommendations}</Text>
            </View>
          </View>
        )}

        {/* Findings Table */}
        {findings.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>7. Constatations détaillées</Text>
            <View style={styles.table}>
              <View style={styles.tableHeader}>
                <Text style={[styles.tableHeaderCell, { flex: 0.5 }]}>N°</Text>
                <Text style={[styles.tableHeaderCell, { flex: 2 }]}>Description</Text>
                <Text style={[styles.tableHeaderCell, { flex: 1 }]}>Sévérité</Text>
                <Text style={[styles.tableHeaderCell, { flex: 1 }]}>Statut</Text>
              </View>
              {findings.map((finding, index) => (
                <View key={index} style={[styles.tableRow, index % 2 === 1 && styles.tableRowAlt]}>
                  <Text style={[styles.tableCell, { flex: 0.5 }]}>{index + 1}</Text>
                  <Text style={[styles.tableCell, styles.tableCellLeft, { flex: 2 }]}>
                    {finding.description.substring(0, 80)}...
                  </Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>
                    <Text style={{ color: severityColors[finding.severity] }}>{finding.severity}</Text>
                  </Text>
                  <Text style={[styles.tableCell, { flex: 1 }]}>{finding.status}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Signatures */}
        <View style={styles.signatureSection}>
          <Text style={styles.signatureTitle}>Signatures</Text>
          <View style={styles.signatureRow}>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Auditeur leader</Text>
              <Text style={styles.signatureDate}>{audit.leadAuditor}</Text>
              <Text style={styles.signatureDate}>{formatPDFDate(audit.endDate)}</Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Représentant qualité</Text>
              <Text style={styles.signatureDate}></Text>
              <Text style={styles.signatureDate}></Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Direction</Text>
              <Text style={styles.signatureDate}></Text>
              <Text style={styles.signatureDate}></Text>
            </View>
          </View>
        </View>

        {/* Footer */}
        {config.showFooter && (
          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>{config.showCompanyName}</Text>
            {config.showDate && (
              <Text style={styles.footerText}>
                Imprimé le {formatPDFDate(new Date())}
              </Text>
            )}
            <Text style={styles.pageNumber} render={({ pageNumber, totalPages }) =>
              `${pageNumber} / ${totalPages}`
            } />
          </View>
        )}
      </Page>
    </Document>
  );
};

export default AuditPDF;
