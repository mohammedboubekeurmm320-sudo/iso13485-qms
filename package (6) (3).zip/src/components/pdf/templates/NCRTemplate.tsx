/**
 * NCR (Non-Conformance Report) PDF Template
 * Professional template for NCR reports following ISO 13485 requirements
 */

import React from 'react';
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from '@react-pdf/renderer';
import { PDFConfig, formatPDFDate, getStatusColor } from '../../../utils/pdfUtils';

// Register fonts
Font.register({
  family: 'Helvetica',
  fonts: [
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxP.ttf', fontWeight: 'normal' },
    { src: 'https://fonts.gstatic.com/s/roboto/v30/KFOlCnqEu92Fr1MmWUlfBBc9.ttf', fontWeight: 'bold' },
  ],
});

const styles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: 'Helvetica',
    fontSize: 10,
    lineHeight: 1.5,
  },
  header: {
    marginBottom: 20,
    borderBottomWidth: 2,
    borderBottomColor: '#dc2626',
    paddingBottom: 10,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#6b7280',
  },
  documentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#fef2f2',
    borderRadius: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#dc2626',
  },
  documentInfoItem: {
    fontSize: 9,
    color: '#4b5563',
  },
  documentInfoLabel: {
    fontWeight: 'bold',
    color: '#1f2937',
  },
  ncrTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 15,
    textAlign: 'center',
    textDecoration: 'underline',
  },
  section: {
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 8,
    paddingBottom: 4,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    textTransform: 'uppercase',
  },
  row: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
    width: 150,
    color: '#374151',
  },
  value: {
    flex: 1,
    color: '#1f2937',
  },
  description: {
    marginTop: 8,
    padding: 10,
    backgroundColor: '#fef2f2',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#dc2626',
  },
  descriptionText: {
    fontSize: 9,
    color: '#374151',
    lineHeight: 1.6,
  },
  statusBox: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
    alignSelf: 'flex-start',
  },
  severityBox: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 9,
    fontWeight: 'bold',
    color: 'white',
    textAlign: 'center',
  },
  table: {
    marginTop: 10,
    marginBottom: 15,
  },
  tableHeader: {
    flexDirection: 'row',
    backgroundColor: '#dc2626',
    padding: 8,
  },
  tableHeaderCell: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 8,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
    padding: 8,
    backgroundColor: 'white',
  },
  tableRowAlt: {
    backgroundColor: '#f9fafb',
  },
  tableCell: {
    fontSize: 9,
    color: '#374151',
    textAlign: 'center',
    flex: 1,
  },
  tableCellLeft: {
    textAlign: 'left',
    flex: 2,
  },
  footer: {
    position: 'absolute',
    bottom: 30,
    left: 40,
    right: 40,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
    paddingTop: 8,
  },
  footerText: {
    fontSize: 8,
    color: '#9ca3af',
  },
  pageNumber: {
    fontSize: 8,
    color: '#9ca3af',
  },
  signatureSection: {
    marginTop: 25,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb',
  },
  signatureTitle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#dc2626',
    marginBottom: 15,
  },
  signatureRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  signatureBox: {
    width: '30%',
  },
  signatureLine: {
    borderBottomWidth: 1,
    borderBottomColor: '#1f2937',
    marginBottom: 8,
    paddingBottom: 4,
  },
  signatureLabel: {
    fontSize: 8,
    color: '#6b7280',
  },
  signatureDate: {
    fontSize: 8,
    color: '#6b7280',
    marginTop: 4,
  },
  dispositionBox: {
    marginTop: 10,
    padding: 10,
    backgroundColor: '#fef3c7',
    borderRadius: 4,
    borderLeftWidth: 3,
    borderLeftColor: '#d97706',
  },
  dispositionTitle: {
    fontSize: 10,
    fontWeight: 'bold',
    color: '#d97706',
    marginBottom: 5,
  },
});

interface NCRData {
  id: string;
  title: string;
  description: string;
  status: string;
  severity: 'Critical' | 'Major' | 'Minor' | 'Observation';
  category: string;
  source: string;
  department: string;
  product: string;
  lotNumber: string;
  quantityAffected: number;
  rootCause: string;
  immediateAction: string;
  disposition: string;
  finalDisposition: string;
  correctiveAction: string;
  preventiveAction: string;
  assignedTo: string;
  createdBy: string;
  dueDate: string;
  completionDate: string;
  createdAt: string;
  updatedAt: string;
  verifiedBy: string;
  verifiedDate: string;
  notes: string;
  concessions: string;
}

interface NCRPDFProps {
  config: PDFConfig;
  ncr: NCRData;
}

const NCRPDF: React.FC<NCRPDFProps> = ({ config, ncr }) => {
  const statusColor = getStatusColor(ncr.status);
  const severityColors: Record<string, string> = {
    'Critical': '#dc2626',
    'Major': '#ea580c',
    'Minor': '#d97706',
    'Observation': '#6b7280',
  };
  const severityColor = severityColors[ncr.severity] || '#6b7280';

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header */}
        {config.showHeader && (
          <View style={styles.header}>
            <Text style={styles.headerTitle}>{config.headerTitle}</Text>
            <Text style={styles.headerSubtitle}>{config.headerSubtitle}</Text>
          </View>
        )}

        {/* Document Info */}
        <View style={styles.documentInfo}>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Document ID: </Text>
              {config.documentId}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Catégorie: </Text>
              {ncr.category}
            </Text>
          </View>
          <View>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Date: </Text>
              {formatPDFDate(new Date())}
            </Text>
            <Text style={styles.documentInfoItem}>
              <Text style={styles.documentInfoLabel}>Auteur: </Text>
              {config.author}
            </Text>
          </View>
        </View>

        {/* NCR Title */}
        <Text style={styles.ncrTitle}>
          RAPPORT DE NON-CONFORMITÉ
        </Text>

        {/* NCR ID, Status and Severity */}
        <View style={[styles.row, { marginBottom: 15 }]}>
          <View style={{ flex: 1 }}>
            <Text style={styles.label}>N° NCR:</Text>
            <Text style={[styles.value, { fontWeight: 'bold', fontSize: 12 }]}>{ncr.id}</Text>
          </View>
          <View style={{ flex: 1, alignItems: 'flex-start' }}>
            <Text style={styles.label}>Statut:</Text>
            <View style={[styles.statusBox, { backgroundColor: statusColor }]}>
              <Text style={{ color: 'white' }}>{ncr.status}</Text>
            </View>
          </View>
          <View style={{ flex: 1, alignItems: 'flex-start' }}>
            <Text style={styles.label}>Sévérité:</Text>
            <View style={[styles.severityBox, { backgroundColor: severityColor }]}>
              <Text style={{ color: 'white' }}>{ncr.severity}</Text>
            </View>
          </View>
        </View>

        {/* Section 1: Identification */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>1. Identification</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Titre:</Text>
            <Text style={styles.value}>{ncr.title}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Département:</Text>
            <Text style={styles.value}>{ncr.department}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Source:</Text>
            <Text style={styles.value}>{ncr.source}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Produit:</Text>
            <Text style={styles.value}>{ncr.product || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Numéro de lot:</Text>
            <Text style={styles.value}>{ncr.lotNumber || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Quantité affectée:</Text>
            <Text style={styles.value}>{ncr.quantityAffected || '-'}</Text>
          </View>
        </View>

        {/* Section 2: Description */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>2. Description de la non-conformité</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{ncr.description}</Text>
          </View>
        </View>

        {/* Section 3: Immediate Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>3. Actions immédiates</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{ncr.immediateAction || '-'}</Text>
          </View>
        </View>

        {/* Section 4: Root Cause */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>4. Analyse des causes</Text>
          <View style={styles.description}>
            <Text style={styles.descriptionText}>{ncr.rootCause || '-'}</Text>
          </View>
        </View>

        {/* Section 5: Disposition */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>5. Disposition</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Disposition proposée:</Text>
            <Text style={styles.value}>{ncr.disposition || '-'}</Text>
          </View>
          <View style={styles.dispositionBox}>
            <Text style={styles.dispositionTitle}>Décision finale:</Text>
            <Text style={styles.descriptionText}>{ncr.finalDisposition || 'En attente de décision'}</Text>
          </View>
        </View>

        {/* Section 6: Corrective/Preventive Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>6. Actions correctives / préventives</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Action corrective:</Text>
            <Text style={styles.value}>{ncr.correctiveAction || '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Action préventive:</Text>
            <Text style={styles.value}>{ncr.preventiveAction || '-'}</Text>
          </View>
        </View>

        {/* Section 7: Dates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>7. Échéances</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Date de création:</Text>
            <Text style={styles.value}>{formatPDFDate(ncr.createdAt)}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Créé par:</Text>
            <Text style={styles.value}>{ncr.createdBy}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date d'échéance:</Text>
            <Text style={styles.value}>{ncr.dueDate ? formatPDFDate(ncr.dueDate) : '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Date de clôture:</Text>
            <Text style={styles.value}>{ncr.completionDate ? formatPDFDate(ncr.completionDate) : '-'}</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Vérifié par:</Text>
            <Text style={styles.value}>{ncr.verifiedBy || '-'}</Text>
          </View>
        </View>

        {/* Notes */}
        {ncr.notes && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Notes supplémentaires</Text>
            <View style={styles.description}>
              <Text style={styles.descriptionText}>{ncr.notes}</Text>
            </View>
          </View>
        )}

        {/* Signatures */}
        <View style={styles.signatureSection}>
          <Text style={styles.signatureTitle}>Signatures</Text>
          <View style={styles.signatureRow}>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Rapporté par</Text>
              <Text style={styles.signatureDate}>{ncr.createdBy}</Text>
              <Text style={styles.signatureDate}>{formatPDFDate(ncr.createdAt)}</Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Approuvé par Qualité</Text>
              <Text style={styles.signatureDate}></Text>
              <Text style={styles.signatureDate}></Text>
            </View>
            <View style={styles.signatureBox}>
              <View style={styles.signatureLine} />
              <Text style={styles.signatureLabel}>Vérifié par</Text>
              <Text style={styles.signatureLabel}>{ncr.verifiedBy || 'En attente'}</Text>
              <Text style={styles.signatureDate}>{ncr.verifiedDate ? formatPDFDate(ncr.verifiedDate) : ''}</Text>
            </View>
          </View>
        </View>

        {/* Footer */}
        {config.showFooter && (
          <View style={styles.footer} fixed>
            <Text style={styles.footerText}>{config.showCompanyName}</Text>
            {config.showDate && (
              <Text style={styles.footerText}>
                Imprimé le {formatPDFDate(new Date())}
              </Text>
            )}
            <Text style={styles.pageNumber} render={({ pageNumber, totalPages }) =>
              `${pageNumber} / ${totalPages}`
            } />
          </View>
        )}
      </Page>
    </Document>
  );
};

export default NCRPDF;
