/**
 * PDF Module - Index
 * Main export point for all PDF-related components and utilities
 */

// Components
export { default as PDFPreviewModal } from './PDFPreviewModal';
export { default as PDFConfigurationPanel } from './PDFConfigurationPanel';
export { default as PDFExportButton, SimplePDFButton, PrintButton } from './PDFExportButton';

// Templates
export { default as GenericTemplate } from './templates/GenericTemplate';
export { default as CAPAPDF } from './templates/CAPATemplate';
export { default as NCRPDF } from './templates/NCRTemplate';
export { default as AuditPDF } from './templates/AuditTemplate';
export { default as TrainingPDF } from './templates/TrainingTemplate';

// Utilities
export * from '../../utils/pdfUtils';

// Hooks
export { default as usePDFGenerator } from '../../hooks/usePDFGenerator';
