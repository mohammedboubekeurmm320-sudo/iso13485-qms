import React, { useState } from 'react';
import { Document } from '@/types/qms';

interface EditDocumentFormProps {
  document: Document;
  onSave: (updates: Partial<Document>) => Promise<void>;
  onCancel: () => void;
  isLoading: boolean;
}

const EditDocumentForm: React.FC<EditDocumentFormProps> = ({
  document,
  onSave,
  onCancel,
  isLoading,
}) => {
  const [formData, setFormData] = useState({
    title: document.title || '',
    description: document.description || '',
    department: document.department || '',
    owner: document.owner || '',
    version: document.version || '1.0',
    classification: document.classification || 'Internal',
    retentionPeriod: document.retentionPeriod || '7 years',
    effectiveDate: document.effectiveDate || '',
    nextReviewDate: document.nextReview || '',
    scope: document.scope || '',
    references: document.references || '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Document Title <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            required
          />
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            rows={3}
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Department
          </label>
          <select
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="">Select Department</option>
            <option value="Quality Assurance">Quality Assurance</option>
            <option value="Production">Production</option>
            <option value="R&D">Research & Development</option>
            <option value="Supply Chain">Supply Chain</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Regulatory Affairs">Regulatory Affairs</option>
            <option value="Engineering">Engineering</option>
            <option value="Quality Control">Quality Control</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Document Owner
          </label>
          <input
            type="text"
            value={formData.owner}
            onChange={(e) => setFormData({ ...formData, owner: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Version
          </label>
          <input
            type="text"
            value={formData.version}
            onChange={(e) => setFormData({ ...formData, version: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Classification
          </label>
          <select
            value={formData.classification}
            onChange={(e) => setFormData({ ...formData, classification: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="Internal">Internal</option>
            <option value="External">External (Customer/Supplier)</option>
            <option value="Regulatory">Regulatory (FDA/CE)</option>
            <option value="Confidential">Confidential</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Effective Date
          </label>
          <input
            type="date"
            value={formData.effectiveDate}
            onChange={(e) => setFormData({ ...formData, effectiveDate: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Next Review Date
          </label>
          <input
            type="date"
            value={formData.nextReviewDate}
            onChange={(e) => setFormData({ ...formData, nextReviewDate: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Retention Period
          </label>
          <select
            value={formData.retentionPeriod}
            onChange={(e) => setFormData({ ...formData, retentionPeriod: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="1 year">1 year</option>
            <option value="3 years">3 years</option>
            <option value="5 years">5 years</option>
            <option value="7 years">7 years</option>
            <option value="10 years">10 years</option>
            <option value="Lifetime">Lifetime</option>
          </select>
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Scope
          </label>
          <textarea
            rows={2}
            value={formData.scope}
            onChange={(e) => setFormData({ ...formData, scope: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            References
          </label>
          <input
            type="text"
            value={formData.references}
            onChange={(e) => setFormData({ ...formData, references: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
            placeholder="Related SOPs, forms, specifications"
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4 border-t">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
        >
          {isLoading ? 'Saving...' : 'Save Changes'}
        </button>
      </div>
    </form>
  );
};

export default EditDocumentForm;
