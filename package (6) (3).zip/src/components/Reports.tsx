import React, { useState, useMemo } from 'react';
import { useCAPAs } from '../modules/capas/hooks/useCAPAs';
import { useAudits } from '../modules/audits/hooks/useAudits';
import { useNonConformances } from '../modules/non-conformances/hooks/useNCRs';
import { useDocuments } from '../modules/documents/hooks/useDocuments';
import { useTrainings } from '../modules/training/hooks/useTraining';
import { useOrganization } from '@/contexts/OrganizationContext';
import { toast } from 'sonner';
import { PDFPreviewModal, ReportType, generateDocumentId, getReportTypePrefix, defaultPDFConfig } from '@/components/pdf';

const Reports: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState({ start: '2025-01-01', end: '2025-02-02' });
  
  // PDF Modal State
  const [pdfModalOpen, setPdfModalOpen] = useState(false);
  const [pdfReportType, setPdfReportType] = useState<ReportType>('GENERIC');
  const [pdfTitle, setPdfTitle] = useState('Rapport QMS');
  const [pdfData, setPdfData] = useState<any>({});

  // Use React Query hooks for data fetching
  const { data: capas = [] } = useCAPAs();
  const { data: audits = [] } = useAudits(currentOrganization?.id || '');
  const { data: nonConformances = [] } = useNonConformances();
  const { data: documents = [] } = useDocuments();
  const { data: trainingRecords = [] } = useTrainings();

  // Calculate stats using useMemo
  const stats = useMemo(() => ({
    openCapas: capas.filter(c => c.status !== 'Closed').length,
    closedCapas: capas.filter(c => c.status === 'Closed').length,
    capaEffectiveness: Math.round((capas.filter(c => c.effectiveness === 'Effective').length / capas.filter(c => c.effectiveness).length) * 100) || 0,
    openNCRs: nonConformances.filter(n => n.status !== 'Closed').length,
    completedAudits: audits.filter(a => a.status === 'Completed').length,
    totalFindings: audits.reduce((sum, a) => sum + (a.findings || 0), 0),
    trainingCompliance: trainingRecords.length > 0 
      ? Math.round((trainingRecords.filter(t => t.status === 'Completed').length / trainingRecords.length) * 100) 
      : 0,
    documentsApproved: documents.filter(d => d.status === 'Approved').length,
    documentsTotal: documents.length,
  }), [capas, audits, nonConformances, documents, trainingRecords]);

  // KPI Data
  const kpiData = [
    { label: 'Open CAPAs', value: stats.openCapas, target: 10, unit: '', trend: -2 },
    { label: 'Open NCRs', value: stats.openNCRs, target: 15, unit: '', trend: -5 },
    { label: 'Audit Findings', value: stats.totalFindings, target: 20, unit: '', trend: -3 },
    { label: 'Training Compliance', value: stats.trainingCompliance, target: 95, unit: '%', trend: 2 },
    { label: 'Doc Approval', value: stats.documentsApproved, target: stats.documentsTotal || 1, unit: '', trend: 5 },
    { label: 'CAPA Effectiveness', value: stats.capaEffectiveness, target: 90, unit: '%', trend: 3 },
  ];

  // Monthly Trends Data
  const monthlyTrends = [
    { month: 'Jan', capas: 3, ncrs: 5, audits: 2 },
    { month: 'Feb', capas: 2, ncrs: 4, audits: 3 },
    { month: 'Mar', capas: 4, ncrs: 6, audits: 2 },
    { month: 'Apr', capas: 1, ncrs: 3, audits: 4 },
    { month: 'May', capas: 3, ncrs: 4, audits: 3 },
    { month: 'Jun', capas: 2, ncrs: 5, audits: 2 },
  ];

  const reportTypes = [
    { id: 'management-review', title: 'Management Review Report', icon: '📊', description: 'Comprehensive QMS performance summary for management review meetings' },
    { id: 'capa-summary', title: 'CAPA Summary Report', icon: '📋', description: 'Overview of corrective and preventive actions status and trends' },
    { id: 'audit-summary', title: 'Audit Summary Report', icon: '🔍', description: 'Internal and external audit findings and closure status' },
    { id: 'ncr-analysis', title: 'NCR Trend Analysis', icon: '📈', description: 'Non-conformance trends by type, source, and severity' },
    { id: 'training-compliance', title: 'Training Compliance Report', icon: '🎓', description: 'Employee training status and competency matrix' },
    { id: 'risk-summary', title: 'Risk Management Summary', icon: '⚠️', description: 'Risk register status and mitigation effectiveness' },
    { id: 'supplier-quality', title: 'Supplier Quality Report', icon: '🏭', description: 'Supplier performance metrics and quality scores' },
    { id: 'customer-feedback', title: 'Customer Feedback Analysis', icon: '💬', description: 'Customer complaints and feedback trends' },
  ];

  const handleGenerateReport = (reportTypeId: string) => {
    let type: ReportType = 'GENERIC';
    let title = 'Rapport QMS';
    let data = {};
    
    switch (reportTypeId) {
      case 'capa-summary':
        type = 'CAPA';
        title = 'Résumé des CAPA';
        data = {
          id: generateDocumentId('CAPA'),
          title: 'Résumé des Actions Correctives/Préventives',
          total: capas.length,
          open: stats.openCapas,
          closed: stats.closedCapas,
          effectiveness: stats.capaEffectiveness,
          dateRange: `${dateRange.start} - ${dateRange.end}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        break;
      case 'ncr-analysis':
        type = 'NCR';
        title = 'Analyse des NCR';
        data = {
          id: generateDocumentId('NCR'),
          title: 'Analyse des Non-Conformités',
          total: nonConformances.length,
          open: stats.openNCRs,
          closed: nonConformances.filter(n => n.status === 'Closed').length,
          critical: nonConformances.filter(n => n.severity === 'Critical').length,
          major: nonConformances.filter(n => n.severity === 'Major').length,
          minor: nonConformances.filter(n => n.severity === 'Minor').length,
          dateRange: `${dateRange.start} - ${dateRange.end}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        break;
      case 'audit-summary':
        type = 'AUDIT';
        title = 'Résumé des Audits';
        data = {
          id: generateDocumentId('AUD'),
          title: 'Résumé des Audits',
          total: audits.length,
          completed: stats.completedAudits,
          findings: stats.totalFindings,
          dateRange: `${dateRange.start} - ${dateRange.end}`,
          startDate: dateRange.start,
          endDate: dateRange.end,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        break;
      case 'training-compliance':
        type = 'TRAINING';
        title = 'Conformité des Formations';
        data = {
          id: generateDocumentId('TRG'),
          title: 'Rapport de Conformité des Formations',
          total: trainingRecords.length,
          completed: trainingRecords.filter(t => t.status === 'Completed').length,
          inProgress: trainingRecords.filter(t => t.status === 'In Progress').length,
          overdue: trainingRecords.filter(t => t.status === 'Overdue').length,
          compliance: stats.trainingCompliance,
          dateRange: `${dateRange.start} - ${dateRange.end}`,
          scheduledDate: dateRange.start,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        break;
      default:
        type = 'GENERIC';
        title = 'Rapport de Synthèse QMS';
        data = {
          id: generateDocumentId('RPT'),
          title: 'Rapport de Synthèse QMS',
          summary: 'Rapport de synthèse des indicateurs qualité',
          capas: capas.length,
          ncrs: nonConformances.length,
          audits: audits.length,
          documents: documents.length,
          trainings: trainingRecords.length,
          dateRange: `${dateRange.start} - ${dateRange.end}`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
    }
    
    setPdfReportType(type);
    setPdfTitle(title);
    setPdfData(data);
    setPdfModalOpen(true);
    toast.success('Génération du PDF en cours...');
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Reports & Analytics</h2>
          <p className="text-gray-500 mt-1">Management review and QMS performance reports per ISO 13485 Section 5.6</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-600">From:</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
            />
          </div>
          <div className="flex items-center gap-2">
            <label className="text-sm text-gray-600">To:</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-sm"
            />
          </div>
        </div>
      </div>

      {/* Executive Summary */}
      <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-4">Executive Summary - Q1 2025</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div>
            <p className="text-slate-400 text-sm">QMS Compliance Score</p>
            <p className="text-3xl font-bold text-green-400 mt-1">94%</p>
            <p className="text-xs text-slate-400 mt-1">+2% from last quarter</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm">CAPA Effectiveness</p>
            <p className="text-3xl font-bold text-blue-400 mt-1">{stats.capaEffectiveness}%</p>
            <p className="text-xs text-slate-400 mt-1">{stats.closedCapas} closed this period</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm">Training Compliance</p>
            <p className="text-3xl font-bold text-purple-400 mt-1">{stats.trainingCompliance}%</p>
            <p className="text-xs text-slate-400 mt-1">Target: 95%</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm">Audit Findings</p>
            <p className="text-3xl font-bold text-amber-400 mt-1">{stats.totalFindings}</p>
            <p className="text-xs text-slate-400 mt-1">From {stats.completedAudits} audits</p>
          </div>
        </div>
      </div>

      {/* KPI Dashboard */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Performance Indicators</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {kpiData.map((kpi, index) => {
            const isOnTarget = kpi.value >= kpi.target;
            return (
              <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-2">{kpi.label}</p>
                <p className={`text-2xl font-bold ${isOnTarget ? 'text-green-600' : 'text-amber-600'}`}>
                  {kpi.value}{kpi.unit}
                </p>
                <p className="text-xs text-gray-500 mt-1">Target: {kpi.target}{kpi.unit}</p>
                <div className="mt-2 h-1.5 bg-gray-200 rounded-full">
                  <div
                    className={`h-full rounded-full ${isOnTarget ? 'bg-green-500' : 'bg-amber-500'}`}
                    style={{ width: `${Math.min((kpi.value / kpi.target) * 100, 100)}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Trend Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Quality Metrics</h3>
          <div className="h-64 flex items-end justify-between gap-4">
            {monthlyTrends.map((month, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full flex flex-col gap-1 items-center">
                  <div
                    className="w-full max-w-8 bg-blue-500 rounded-t transition-all hover:bg-blue-600"
                    style={{ height: `${month.capas * 20}px` }}
                    title={`CAPAs: ${month.capas}`}
                  />
                  <div
                    className="w-full max-w-8 bg-amber-500 transition-all hover:bg-amber-600"
                    style={{ height: `${month.ncrs * 10}px` }}
                    title={`NCRs: ${month.ncrs}`}
                  />
                  <div
                    className="w-full max-w-8 bg-emerald-500 rounded-b transition-all hover:bg-emerald-600"
                    style={{ height: `${month.audits * 25}px` }}
                    title={`Audits: ${month.audits}`}
                  />
                </div>
                <span className="text-xs text-gray-500 mt-3">{month.month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-6 mt-4 pt-4 border-t">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span className="text-sm text-gray-600">CAPAs</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-amber-500 rounded" />
              <span className="text-sm text-gray-600">NCRs</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded" />
              <span className="text-sm text-gray-600">Audits</span>
            </div>
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Current Status Distribution</h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">CAPAs</span>
                <span className="text-sm text-gray-500">{capas.length} total</span>
              </div>
              <div className="h-4 bg-gray-100 rounded-full flex overflow-hidden">
                <div className="bg-green-500" style={{ width: `${(capas.filter(c => c.status === 'Closed').length / capas.length) * 100}%` }} title="Closed" />
                <div className="bg-blue-500" style={{ width: `${(capas.filter(c => ['Investigation', 'Implementation', 'Verification'].includes(c.status)).length / capas.length) * 100}%` }} title="In Progress" />
                <div className="bg-yellow-500" style={{ width: `${(capas.filter(c => c.status === 'Open').length / capas.length) * 100}%` }} title="Open" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">NCRs</span>
                <span className="text-sm text-gray-500">{nonConformances.length} total</span>
              </div>
              <div className="h-4 bg-gray-100 rounded-full flex overflow-hidden">
                <div className="bg-green-500" style={{ width: `${(nonConformances.filter(n => n.status === 'Closed').length / nonConformances.length) * 100}%` }} title="Closed" />
                <div className="bg-blue-500" style={{ width: `${(nonConformances.filter(n => n.status === 'Under Investigation').length / nonConformances.length) * 100}%` }} title="Investigating" />
                <div className="bg-purple-500" style={{ width: `${(nonConformances.filter(n => n.status === 'Pending Disposition').length / nonConformances.length) * 100}%` }} title="Pending" />
                <div className="bg-yellow-500" style={{ width: `${(nonConformances.filter(n => n.status === 'Open').length / nonConformances.length) * 100}%` }} title="Open" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Documents</span>
                <span className="text-sm text-gray-500">{documents.length} total</span>
              </div>
              <div className="h-4 bg-gray-100 rounded-full flex overflow-hidden">
                <div className="bg-green-500" style={{ width: `${(documents.filter(d => d.status === 'Approved').length / documents.length) * 100}%` }} title="Approved" />
                <div className="bg-blue-500" style={{ width: `${(documents.filter(d => d.status === 'In Review').length / documents.length) * 100}%` }} title="In Review" />
                <div className="bg-yellow-500" style={{ width: `${(documents.filter(d => d.status === 'Draft').length / documents.length) * 100}%` }} title="Draft" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Training</span>
                <span className="text-sm text-gray-500">{trainingRecords.length} records</span>
              </div>
              <div className="h-4 bg-gray-100 rounded-full flex overflow-hidden">
                <div className="bg-green-500" style={{ width: `${(trainingRecords.filter(t => t.status === 'Completed').length / trainingRecords.length) * 100}%` }} title="Completed" />
                <div className="bg-blue-500" style={{ width: `${(trainingRecords.filter(t => t.status === 'In Progress').length / trainingRecords.length) * 100}%` }} title="In Progress" />
                <div className="bg-yellow-500" style={{ width: `${(trainingRecords.filter(t => t.status === 'Scheduled').length / trainingRecords.length) * 100}%` }} title="Scheduled" />
                <div className="bg-red-500" style={{ width: `${(trainingRecords.filter(t => t.status === 'Overdue').length / trainingRecords.length) * 100}%` }} title="Overdue" />
              </div>
            </div>
          </div>
          <div className="flex items-center justify-center gap-4 mt-6 pt-4 border-t flex-wrap">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span className="text-xs text-gray-600">Closed/Complete</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span className="text-xs text-gray-600">In Progress</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-yellow-500 rounded" />
              <span className="text-xs text-gray-600">Open/Pending</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded" />
              <span className="text-xs text-gray-600">Overdue</span>
            </div>
          </div>
        </div>
      </div>

      {/* Report Types */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Reports</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {reportTypes.map((report) => (
            <button
              key={report.id}
              onClick={() => setSelectedReport(report.id)}
              className={`p-4 rounded-xl border-2 text-left transition-all hover:shadow-md ${
                selectedReport === report.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-200 bg-white hover:border-blue-300'
              }`}
            >
              <div className="text-2xl mb-2">{report.icon}</div>
              <h4 className="font-semibold text-gray-900">{report.title}</h4>
              <p className="text-sm text-gray-500 mt-1">{report.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Generate Report Buttons */}
      {selectedReport && (
        <div className="flex items-center justify-center gap-4 p-6 bg-gray-50 rounded-xl">
          <button 
            onClick={() => handleGenerateReport(selectedReport)}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Générer le rapport
          </button>
          <button 
            onClick={() => handleGenerateReport(selectedReport)}
            className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-white transition-colors flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Exporter en PDF
          </button>
          <button className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-white transition-colors flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            Email Report
          </button>
        </div>
      )}

      {/* PDF Preview Modal */}
      {pdfModalOpen && (
        <PDFPreviewModal
          isOpen={pdfModalOpen}
          onClose={() => setPdfModalOpen(false)}
          reportType={pdfReportType}
          title={pdfTitle}
          data={pdfData}
        />
      )}
    </div>
  );
};

export default Reports;
