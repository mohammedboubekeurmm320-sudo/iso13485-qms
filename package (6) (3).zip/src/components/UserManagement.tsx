import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, UserRole, roleLabels, roleDescriptions } from '@/types/auth';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Search, Trash2, Edit, Shield, Mail, Building, AlertTriangle, Lock, Unlock, Eye, History, Send, RotateCcw, UserCheck, UserX, FileText } from 'lucide-react';
import { toast } from 'sonner';

// Demo users data for the management interface
const initialUsers: (User & { role: UserRole })[] = [
  { id: '1', email: 'admin@example.com', full_name: 'System Administrator', role: 'admin', department: 'IT', job_title: 'Administrator', created_at: '2024-01-01', updated_at: '2024-01-01' },
  { id: '2', email: 'quality@example.com', full_name: 'Sarah Chen', role: 'quality_manager', department: 'Quality', job_title: 'Quality Manager', created_at: '2024-01-15', updated_at: '2024-01-15' },
  { id: '3', email: 'auditor@example.com', full_name: 'Michael Torres', role: 'auditor', department: 'Quality', job_title: 'Internal Auditor', created_at: '2024-02-01', updated_at: '2024-02-01' },
  { id: '4', email: 'documents@example.com', full_name: 'Emily Rodriguez', role: 'document_controller', department: 'Quality', job_title: 'Document Controller', created_at: '2024-02-15', updated_at: '2024-02-15' },
  { id: '5', email: 'executive@example.com', full_name: 'James Wilson', role: 'executive', department: 'Management', job_title: 'Executive', created_at: '2024-03-01', updated_at: '2024-03-01' },
  { id: '6', email: 'operator@example.com', full_name: 'David Martinez', role: 'operator', department: 'Production', job_title: 'Operator', created_at: '2024-03-15', updated_at: '2024-03-15' },
];

const roleColors: Record<UserRole, string> = {
  admin: 'bg-red-100 text-red-700 border-red-200',
  quality_manager: 'bg-purple-100 text-purple-700 border-purple-200',
  executive: 'bg-blue-100 text-blue-700 border-blue-200',
  auditor: 'bg-green-100 text-green-700 border-green-200',
  document_controller: 'bg-amber-100 text-amber-700 border-amber-200',
  operator: 'bg-gray-100 text-gray-700 border-gray-200',
};

interface UserManagementProps {
  currentUserRole?: UserRole;
}

export default function UserManagement({ currentUserRole = 'admin' }: UserManagementProps) {
  const { profile, isAdmin } = useAuth();
  const [users, setUsers] = useState<(User & { role: UserRole; status: 'active' | 'inactive' })[]>(
    initialUsers.map(u => ({ ...u, status: 'active' as const }))
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<(User & { role: UserRole; status: 'active' | 'inactive' }) | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [changeReason, setChangeReason] = useState('');
  const [selectedAuditUser, setSelectedAuditUser] = useState<(User & { role: UserRole; status: 'active' | 'inactive' }) | null>(null);
  const [showPasswordReset, setShowPasswordReset] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);

  // Audit log state
  const [auditLogs, setAuditLogs] = useState<{
    id: string;
    action: string;
    userId: string;
    userName: string;
    targetUserId: string;
    targetUserName: string;
    details: string;
    timestamp: string;
    performedBy: string;
  }[]>([
    {
      id: '1',
      action: 'USER_CREATED',
      userId: '1',
      userName: 'System Administrator',
      targetUserId: '2',
      targetUserName: 'Sarah Chen',
      details: 'Created new user account',
      timestamp: '2024-01-15T10:30:00Z',
      performedBy: 'System Administrator',
    },
    {
      id: '2',
      action: 'ROLE_CHANGED',
      userId: '1',
      userName: 'System Administrator',
      targetUserId: '3',
      targetUserName: 'Michael Torres',
      details: 'Role changed from operator to auditor',
      timestamp: '2024-02-05T14:20:00Z',
      performedBy: 'System Administrator',
    },
    {
      id: '3',
      action: 'USER_DEACTIVATED',
      userId: '1',
      userName: 'System Administrator',
      targetUserId: '6',
      targetUserName: 'David Martinez',
      details: 'Account deactivated - employment terminated',
      timestamp: '2024-03-20T09:15:00Z',
      performedBy: 'System Administrator',
    },
    {
      id: '4',
      action: 'PASSWORD_RESET',
      userId: '1',
      userName: 'System Administrator',
      targetUserId: '4',
      targetUserName: 'Emily Rodriguez',
      details: 'Password reset requested',
      timestamp: '2024-04-10T11:45:00Z',
      performedBy: 'System Administrator',
    },
  ]);

  // Add audit log entry
  const addAuditLog = (action: string, targetUser: User & { status: 'active' | 'inactive' }, details: string) => {
    const newLog = {
      id: String(auditLogs.length + 1),
      action,
      userId: profile?.id || '1',
      userName: profile?.full_name || 'System Administrator',
      targetUserId: targetUser.id,
      targetUserName: targetUser.full_name || targetUser.email,
      details,
      timestamp: new Date().toISOString(),
      performedBy: profile?.full_name || 'System Administrator',
    };
    setAuditLogs([newLog, ...auditLogs]);
  };

  // Send welcome email (simulated)
  const handleSendWelcomeEmail = (user: User & { status: 'active' | 'inactive' }) => {
    toast.success(`Email de bienvenue envoyé à ${user.email}`, {
      description: `Un email de bienvenue a été envoyé à ${user.full_name || user.email} avec les instructions de connexion.`,
    });
    addAuditLog('WELCOME_EMAIL_SENT', user, 'Welcome email sent to user');
  };

  // Password reset (simulated)
  const handlePasswordReset = (user: User & { status: 'active' | 'inactive' }) => {
    toast.success(`Email de réinitialisation envoyé à ${user.email}`, {
      description: `Un email de réinitialisation de mot de passe a été envoyé à ${user.full_name || user.email}.`,
    });
    addAuditLog('PASSWORD_RESET', user, 'Password reset email sent');
    setShowPasswordReset(null);
  };

  // Handle user creation with welcome email option
  const handleCreateUser = (sendWelcome: boolean = false) => {
    if (!newUser.email || !newUser.full_name) return;
    
    const user: User & { role: UserRole; status: 'active' | 'inactive' } = {
      id: String(users.length + 1),
      email: newUser.email,
      full_name: newUser.full_name,
      role: newUser.role,
      department: newUser.department,
      job_title: newUser.job_title,
      status: 'active',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    
    setUsers([...users, user]);
    addAuditLog('USER_CREATED', user, `Created new user: ${user.email} with role ${user.role}`);
    
    if (sendWelcome) {
      handleSendWelcomeEmail(user);
    }
    
    setIsCreateDialogOpen(false);
    setNewUser({
      email: '',
      full_name: '',
      role: 'operator',
      department: '',
      job_title: '',
    });
  };

  // Handle user update
  const handleUpdateUser = () => {
    if (!editingUser || !changeReason) return;
    
    setUsers(users.map(u => u.id === editingUser.id ? editingUser : u));
    addAuditLog('USER_UPDATED', editingUser, changeReason);
    setEditingUser(null);
    setChangeReason('');
    setShowEditModal(false);
    toast.success('Utilisateur mis à jour avec succès');
  };

  // Handle user deactivation
  const handleDeleteUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setUsers(users.map(u => u.id === userId ? { ...u, status: 'inactive' as const } : u));
      addAuditLog('USER_DEACTIVATED', user, 'User account deactivated');
    }
    setShowDeleteConfirm(null);
    toast.success('Utilisateur désactivé avec succès');
  };

  // Handle user activation
  const handleActivateUser = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) {
      setUsers(users.map(u => u.id === userId ? { ...u, status: 'active' as const } : u));
      addAuditLog('USER_ACTIVATED', user, 'User account reactivated');
      toast.success('Utilisateur activé avec succès');
    }
  };

  // Admin access check
  if (!isAdmin) {
    return (
      <div className="p-6 flex items-center justify-center min-h-[400px]">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <CardTitle className="text-xl text-red-600">Accès refusé</CardTitle>
            <CardDescription>
              Vous n'avez pas les permissions nécessaires pour accéder à ce module
            </CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <p className="text-sm text-gray-500 mb-4">
              Seul les administrateurs peuvent gérer les utilisateurs.
            </p>
            <Button onClick={() => window.history.back()} variant="outline">
              Retour
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const [newUser, setNewUser] = useState({
    email: '',
    full_name: '',
    role: 'operator' as UserRole,
    department: '',
    job_title: '',
  });

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    const matchesStatus = statusFilter === 'all' || user.status === statusFilter;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const stats = {
    total: users.length,
    admins: users.filter(u => u.role === 'admin').length,
    active: users.filter(u => u.status === 'active').length,
    inactive: users.filter(u => u.status === 'inactive').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestion des utilisateurs</h2>
          <p className="text-gray-500 mt-1">Créer et gérer les comptes utilisateurs</p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Nouvel utilisateur
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Créer un nouvel utilisateur</DialogTitle>
              <DialogDescription>
                Ajoutez un nouvel utilisateur au système QMS
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Nom complet</label>
                <Input
                  value={newUser.full_name}
                  onChange={(e) => setNewUser({ ...newUser, full_name: e.target.value })}
                  placeholder="John Doe"
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  placeholder="john@company.com"
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Rôle</label>
                <Select
                  value={newUser.role}
                  onValueChange={(value) => setNewUser({ ...newUser, role: value as UserRole })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrateur</SelectItem>
                    <SelectItem value="quality_manager">Quality Manager</SelectItem>
                    <SelectItem value="auditor">Auditeur</SelectItem>
                    <SelectItem value="document_controller">Contrôleur de documents</SelectItem>
                    <SelectItem value="executive">Direction</SelectItem>
                    <SelectItem value="operator">Opérateur</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-gray-500">{roleDescriptions[newUser.role]}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Département</label>
                  <Input
                    value={newUser.department}
                    onChange={(e) => setNewUser({ ...newUser, department: e.target.value })}
                    placeholder="Qualité"
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Poste</label>
                  <Input
                    value={newUser.job_title}
                    onChange={(e) => setNewUser({ ...newUser, job_title: e.target.value })}
                    placeholder="Responsable"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Annuler</Button>
              <Button onClick={handleCreateUser} disabled={!newUser.email || !newUser.full_name}>
                Créer l'utilisateur
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total utilisateurs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Administrateurs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.admins}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Comptes actifs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.active}</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Rechercher un utilisateur..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Tous les rôles" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Tous les rôles</SelectItem>
            <SelectItem value="admin">Administrateur</SelectItem>
            <SelectItem value="quality_manager">Quality Manager</SelectItem>
            <SelectItem value="auditor">Auditeur</SelectItem>
            <SelectItem value="document_controller">Contrôleur de documents</SelectItem>
            <SelectItem value="executive">Direction</SelectItem>
            <SelectItem value="operator">Opérateur</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Users Table */}
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Utilisateur</TableHead>
                <TableHead>Rôle</TableHead>
                <TableHead>Département</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead>Date de création</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                    Aucun utilisateur trouvé
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-medium">
                            {user.full_name?.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <p className="font-medium">{user.full_name}</p>
                          <p className="text-sm text-gray-500">{user.email}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={roleColors[user.role]}>
                        {roleLabels[user.role]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Building className="h-4 w-4" />
                        {user.department || '-'}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={user.status === 'active' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-700 border-gray-200'}>
                        {user.status === 'active' ? 'Actif' : 'Inactif'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {new Date(user.created_at).toLocaleDateString('fr-FR')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setEditingUser(user)}
                          title="Modifier"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSelectedAuditUser(user)}
                          title="Journal d'audit"
                        >
                          <History className="h-4 w-4 text-blue-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleSendWelcomeEmail(user)}
                          title="Envoyer email de bienvenue"
                        >
                          <Mail className="h-4 w-4 text-green-500" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handlePasswordReset(user)}
                          title="Réinitialiser mot de passe"
                        >
                          <RotateCcw className="h-4 w-4 text-orange-500" />
                        </Button>
                        {user.role !== 'admin' && (
                          user.status === 'active' ? (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteUser(user.id)}
                              title="Désactiver"
                            >
                              <UserX className="h-4 w-4 text-red-500" />
                            </Button>
                          ) : (
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleActivateUser(user.id)}
                              title="Activer"
                            >
                              <UserCheck className="h-4 w-4 text-green-500" />
                            </Button>
                          )
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Modifier l'utilisateur</DialogTitle>
            <DialogDescription>
              Mettre à jour les informations de l'utilisateur
            </DialogDescription>
          </DialogHeader>
          {editingUser && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label className="text-sm font-medium">Nom complet</label>
                <Input
                  value={editingUser.full_name}
                  onChange={(e) => setEditingUser({ ...editingUser, full_name: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Email</label>
                <Input value={editingUser.email} disabled />
              </div>
              <div className="grid gap-2">
                <label className="text-sm font-medium">Rôle</label>
                <Select
                  value={editingUser.role}
                  onValueChange={(value) => setEditingUser({ ...editingUser, role: value as UserRole })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Administrateur</SelectItem>
                    <SelectItem value="quality_manager">Quality Manager</SelectItem>
                    <SelectItem value="auditor">Auditeur</SelectItem>
                    <SelectItem value="document_controller">Contrôleur de documents</SelectItem>
                    <SelectItem value="executive">Direction</SelectItem>
                    <SelectItem value="operator">Opérateur</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Département</label>
                  <Input
                    value={editingUser.department || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, department: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Poste</label>
                  <Input
                    value={editingUser.job_title || ''}
                    onChange={(e) => setEditingUser({ ...editingUser, job_title: e.target.value })}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingUser(null)}>Annuler</Button>
            <Button onClick={handleUpdateUser}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Audit Log Modal */}
      <Dialog open={!!selectedAuditUser} onOpenChange={() => setSelectedAuditUser(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <History className="h-5 w-5" />
              Journal d'audit - {selectedAuditUser?.full_name}
            </DialogTitle>
            <DialogDescription>
              Historique des actions effectuées sur cet utilisateur
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto">
            {auditLogs.filter(log => log.targetUserId === selectedAuditUser?.id).length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Aucune entrée dans le journal d'audit pour cet utilisateur</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Effectué par</TableHead>
                    <TableHead>Détails</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLogs
                    .filter(log => log.targetUserId === selectedAuditUser?.id)
                    .map((log) => (
                      <TableRow key={log.id}>
                        <TableCell className="whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleString('fr-FR')}
                        </TableCell>
                        <TableCell>
                          <Badge className={
                            log.action.includes('CREATED') ? 'bg-green-100 text-green-700' :
                            log.action.includes('DEACTIVATED') || log.action.includes('DEACTIVATED') ? 'bg-red-100 text-red-700' :
                            log.action.includes('ACTIVATED') ? 'bg-blue-100 text-blue-700' :
                            log.action.includes('PASSWORD') ? 'bg-orange-100 text-orange-700' :
                            log.action.includes('EMAIL') ? 'bg-purple-100 text-purple-700' :
                            'bg-gray-100 text-gray-700'
                          }>
                            {log.action.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>{log.performedBy}</TableCell>
                        <TableCell>{log.details}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedAuditUser(null)}>Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
