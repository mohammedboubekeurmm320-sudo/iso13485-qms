import React, { useMemo } from 'react';
import KPICard from './ui/KPICard';
import StatusBadge from './ui/StatusBadge';
import { useCAPAs } from '../modules/capas/hooks/useCAPAs';
import { useAudits } from '../modules/audits/hooks/useAudits';
import { useNonConformances } from '../modules/non-conformances/hooks/useNCRs';
import { useDocuments } from '../modules/documents/hooks/useDocuments';
import { useOrganization } from '@/contexts/OrganizationContext';
import { toast } from 'sonner';
import { kpiData, monthlyTrends } from '../data/mockData';

const Dashboard: React.FC = () => {
  const { currentOrganization } = useOrganization();

  // Use React Query hooks for data fetching
  const { data: capas = [] } = useCAPAs();
  const { data: audits = [] } = useAudits(currentOrganization?.id || '');
  const { data: nonConformances = [] } = useNonConformances();
  const { data: documents = [] } = useDocuments();

  // Calculate KPIs using useMemo
  const openCapas = useMemo(() => capas.filter(c => c.status !== 'Closed').length, [capas]);
  const openNCRs = useMemo(() => nonConformances.filter(n => n.status !== 'Closed').length, [nonConformances]);
  const upcomingAudits = useMemo(() => audits.filter(a => a.status === 'Scheduled').length, [audits]);
  const docsForReview = useMemo(() => documents.filter(d => d.status === 'In Review').length, [documents]);

  const recentCapas = useMemo(() => capas.slice(0, 4), [capas]);
  const upcomingAuditsList = useMemo(() => audits.filter(a => a.status === 'Scheduled').slice(0, 3), [audits]);

  return (
    <div className="p-6 space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm font-medium">Open CAPAs</p>
              <p className="text-3xl font-bold mt-1">{openCapas}</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
              </svg>
            </div>
          </div>
          <p className="text-blue-100 text-xs mt-3">2 critical, 3 high priority</p>
        </div>

        <div className="bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-amber-100 text-sm font-medium">Open NCRs</p>
              <p className="text-3xl font-bold mt-1">{openNCRs}</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
          </div>
          <p className="text-amber-100 text-xs mt-3">1 critical requiring disposition</p>
        </div>

        <div className="bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-100 text-sm font-medium">Upcoming Audits</p>
              <p className="text-3xl font-bold mt-1">{upcomingAudits}</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
          </div>
          <p className="text-emerald-100 text-xs mt-3">Next: Feb 15, 2025</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm font-medium">Docs for Review</p>
              <p className="text-3xl font-bold mt-1">{docsForReview}</p>
            </div>
            <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
          </div>
          <p className="text-purple-100 text-xs mt-3">Awaiting your approval</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Key Performance Indicators</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {kpiData.map((kpi, index) => (
            <KPICard key={index} data={kpi} />
          ))}
        </div>
      </div>

      {/* Charts and Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trend Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Monthly Trends</h3>
          <div className="h-64 flex items-end justify-between gap-2">
            {monthlyTrends.map((month, index) => (
              <div key={index} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex flex-col gap-1">
                  <div
                    className="w-full bg-blue-500 rounded-t"
                    style={{ height: `${month.capas * 15}px` }}
                    title={`CAPAs: ${month.capas}`}
                  />
                  <div
                    className="w-full bg-amber-500"
                    style={{ height: `${month.ncrs * 8}px` }}
                    title={`NCRs: ${month.ncrs}`}
                  />
                  <div
                    className="w-full bg-emerald-500 rounded-b"
                    style={{ height: `${month.audits * 20}px` }}
                    title={`Audits: ${month.audits}`}
                  />
                </div>
                <span className="text-xs text-gray-500 mt-2">{month.month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-blue-500 rounded" />
              <span className="text-xs text-gray-600">CAPAs</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-amber-500 rounded" />
              <span className="text-xs text-gray-600">NCRs</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-emerald-500 rounded" />
              <span className="text-xs text-gray-600">Audits</span>
            </div>
          </div>
        </div>

        {/* Recent CAPAs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recent CAPAs</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View All</button>
          </div>
          <div className="space-y-3">
            {recentCapas.map((capa) => (
              <div
                key={capa.id}
                className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-medium text-blue-600">{capa.capaNumber}</span>
                      <StatusBadge status={capa.priority} variant="priority" />
                    </div>
                    <p className="text-sm text-gray-700 line-clamp-1">{capa.title}</p>
                    <p className="text-xs text-gray-500 mt-1">Assigned to: {capa.assignedTo}</p>
                  </div>
                  <StatusBadge status={capa.status} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Audits */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Upcoming Audits</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">View All</button>
          </div>
          <div className="space-y-3">
            {upcomingAuditsList.map((audit) => (
              <div
                key={audit.id}
                className="p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">{audit.title}</p>
                    <p className="text-xs text-gray-500">{audit.scheduledDate}</p>
                  </div>
                  <StatusBadge status={audit.type} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Compliance Status */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Compliance Status</h3>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">ISO 13485:2016</span>
                <span className="text-sm font-medium text-green-600">Certified</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full">
                <div className="h-full w-full bg-green-500 rounded-full" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">FDA 21 CFR 820</span>
                <span className="text-sm font-medium text-green-600">Compliant</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full">
                <div className="h-full w-[95%] bg-green-500 rounded-full" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">EU MDR 2017/745</span>
                <span className="text-sm font-medium text-amber-600">In Progress</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full">
                <div className="h-full w-[75%] bg-amber-500 rounded-full" />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">ISO 14971:2019</span>
                <span className="text-sm font-medium text-green-600">Compliant</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full">
                <div className="h-full w-full bg-green-500 rounded-full" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <button className="p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors text-left">
              <svg className="w-6 h-6 text-blue-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <p className="text-sm font-medium text-gray-900">New CAPA</p>
            </button>
            <button className="p-4 bg-amber-50 hover:bg-amber-100 rounded-lg transition-colors text-left">
              <svg className="w-6 h-6 text-amber-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <p className="text-sm font-medium text-gray-900">New NCR</p>
            </button>
            <button className="p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors text-left">
              <svg className="w-6 h-6 text-purple-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-sm font-medium text-gray-900">New Document</p>
            </button>
            <button className="p-4 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors text-left">
              <svg className="w-6 h-6 text-emerald-600 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-sm font-medium text-gray-900">Run Report</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
