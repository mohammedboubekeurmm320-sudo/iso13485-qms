import React from 'react';

interface StatusBadgeProps {
  status: string;
  variant?: 'default' | 'priority' | 'severity' | 'risk';
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status, variant = 'default' }) => {
  const getStatusStyles = () => {
    if (variant === 'priority') {
      switch (status) {
        case 'Critical':
          return 'bg-red-100 text-red-800 border-red-200';
        case 'High':
          return 'bg-orange-100 text-orange-800 border-orange-200';
        case 'Medium':
          return 'bg-yellow-100 text-yellow-800 border-yellow-200';
        case 'Low':
          return 'bg-green-100 text-green-800 border-green-200';
        default:
          return 'bg-gray-100 text-gray-800 border-gray-200';
      }
    }

    if (variant === 'severity') {
      switch (status) {
        case 'Critical':
          return 'bg-red-100 text-red-800 border-red-200';
        case 'Major':
          return 'bg-orange-100 text-orange-800 border-orange-200';
        case 'Minor':
          return 'bg-blue-100 text-blue-800 border-blue-200';
        default:
          return 'bg-gray-100 text-gray-800 border-gray-200';
      }
    }

    if (variant === 'risk') {
      switch (status) {
        case 'Unacceptable':
          return 'bg-red-100 text-red-800 border-red-200';
        case 'ALARP':
          return 'bg-yellow-100 text-yellow-800 border-yellow-200';
        case 'Acceptable':
          return 'bg-green-100 text-green-800 border-green-200';
        default:
          return 'bg-gray-100 text-gray-800 border-gray-200';
      }
    }

    // Default status styles
    switch (status) {
      case 'Approved':
      case 'Completed':
      case 'Closed':
      case 'Effective':
      case 'Mitigated':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'In Review':
      case 'In Progress':
      case 'Under Investigation':
      case 'Investigation':
      case 'Implementation':
      case 'Verification':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Draft':
      case 'Scheduled':
      case 'Open':
      case 'Pending':
      case 'Pending Disposition':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Obsolete':
      case 'Cancelled':
      case 'Overdue':
      case 'Not Effective':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusStyles()}`}>
      {status}
    </span>
  );
};

export default StatusBadge;
