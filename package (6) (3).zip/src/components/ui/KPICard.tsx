import React from 'react';
import { KPIData } from '../../types/qms';

interface KPICardProps {
  data: KPIData;
}

const KPICard: React.FC<KPICardProps> = ({ data }) => {
  const isOnTarget = data.value >= data.target;
  
  const getTrendIcon = () => {
    switch (data.trend) {
      case 'up':
        return (
          <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
          </svg>
        );
      case 'down':
        return (
          <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        );
      default:
        return (
          <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14" />
          </svg>
        );
    }
  };

  const progressPercentage = Math.min((data.value / data.target) * 100, 100);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <h4 className="text-sm font-medium text-gray-600 leading-tight">{data.label}</h4>
        <div className="flex items-center gap-1">
          {getTrendIcon()}
        </div>
      </div>
      
      <div className="flex items-baseline gap-2 mb-3">
        <span className={`text-3xl font-bold ${isOnTarget ? 'text-green-600' : 'text-amber-600'}`}>
          {data.value}
        </span>
        <span className="text-sm text-gray-500">{data.unit}</span>
      </div>

      <div className="mb-2">
        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              isOnTarget ? 'bg-green-500' : 'bg-amber-500'
            }`}
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      <div className="flex items-center justify-between text-xs">
        <span className="text-gray-500">Target: {data.target}{data.unit}</span>
        <span className={`font-medium ${isOnTarget ? 'text-green-600' : 'text-amber-600'}`}>
          {isOnTarget ? 'On Target' : 'Below Target'}
        </span>
      </div>
    </div>
  );
};

export default KPICard;
