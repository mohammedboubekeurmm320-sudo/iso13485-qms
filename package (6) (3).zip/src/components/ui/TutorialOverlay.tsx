import React, { useState, useCallback, useEffect } from 'react';

export interface TutorialStep {
  id: string;
  target: string;
  title: string;
  content: string;
  position?: 'top' | 'bottom' | 'left' | 'right' | 'center';
  actionLabel?: string;
}

export interface Tutorial {
  id: string;
  title: string;
  description?: string;
  steps: TutorialStep[];
}

interface TutorialContextType {
  isActive: boolean;
  currentTutorial: Tutorial | null;
  currentStep: number;
  startTutorial: (tutorial: Tutorial) => void;
  nextStep: () => void;
  previousStep: () => void;
  endTutorial: () => void;
  skipTutorial: () => void;
  progress: number;
}

const tutorials: Tutorial[] = [
  {
    id: 'document-creation',
    title: 'Creating a Document',
    description: 'Learn how to create and manage controlled documents',
    steps: [
      {
        id: 'step-1',
        target: '[data-help="create-document"]',
        title: 'Click Create Document',
        content: 'Start by clicking the "New Document" button in the document control section.',
        position: 'right',
        actionLabel: 'Next',
      },
      {
        id: 'step-2',
        target: '[data-testid="document-type"]',
        title: 'Select Document Type',
        content: 'Choose the type of document you want to create: SOP, Work Instruction, Form, or Policy.',
        position: 'bottom',
        actionLabel: 'Next',
      },
      {
        id: 'step-3',
        target: '[data-testid="document-title"]',
        title: 'Enter Document Details',
        content: 'Fill in the document title, description, and assign a document number.',
        position: 'bottom',
        actionLabel: 'Next',
      },
      {
        id: 'step-4',
        target: '[data-testid="submit-document"]',
        title: 'Submit for Approval',
        content: 'Once completed, submit the document for approval. It will enter the review workflow.',
        position: 'top',
        actionLabel: 'Finish',
      },
    ],
  },
  {
    id: 'capa-process',
    title: 'Managing CAPA',
    description: 'Learn how to create and track Corrective and Preventive Actions',
    steps: [
      {
        id: 'step-1',
        target: '[data-nav="capa"]',
        title: 'Navigate to CAPA',
        content: 'Go to the CAPA Management section from the sidebar menu.',
        position: 'right',
        actionLabel: 'Next',
      },
      {
        id: 'step-2',
        target: '[data-help="create-capa"]',
        title: 'Create New CAPA',
        content: 'Click the "New CAPA" button to start creating a corrective or preventive action.',
        position: 'right',
        actionLabel: 'Next',
      },
      {
        id: 'step-3',
        target: '[data-testid="root-cause"]',
        title: 'Root Cause Analysis',
        content: 'Document the root cause using the 5 Whys or Fishbone diagram tools.',
        position: 'bottom',
        actionLabel: 'Next',
      },
      {
        id: 'step-4',
        target: '[data-testid="actions"]',
        title: 'Define Actions',
        content: 'List all corrective actions, assign owners, and set due dates.',
        position: 'top',
        actionLabel: 'Finish',
      },
    ],
  },
];

const TutorialContext = React.createContext<TutorialContextType | undefined>(undefined);

export const TutorialProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isActive, setIsActive] = useState(false);
  const [currentTutorial, setCurrentTutorial] = useState<Tutorial | null>(null);
  const [currentStep, setCurrentStep] = useState(0);

  const startTutorial = useCallback((tutorial: Tutorial) => {
    setCurrentTutorial(tutorial);
    setCurrentStep(0);
    setIsActive(true);
  }, []);

  const nextStep = useCallback(() => {
    if (!currentTutorial) return;
    if (currentStep < currentTutorial.steps.length - 1) {
      setCurrentStep((prev) => prev + 1);
    } else {
      setIsActive(false);
    }
  }, [currentTutorial, currentStep]);

  const previousStep = useCallback(() => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
    }
  }, [currentStep]);

  const endTutorial = useCallback(() => {
    setIsActive(false);
    setCurrentTutorial(null);
    setCurrentStep(0);
  }, []);

  const skipTutorial = useCallback(() => {
    setIsActive(false);
  }, []);

  const progress = currentTutorial 
    ? ((currentStep + 1) / currentTutorial.steps.length) * 100 
    : 0;

  return (
    <TutorialContext.Provider
      value={{
        isActive,
        currentTutorial,
        currentStep,
        startTutorial,
        nextStep,
        previousStep,
        endTutorial,
        skipTutorial,
        progress,
      }}
    >
      {children}
    </TutorialContext.Provider>
  );
};

export const useTutorial = (): TutorialContextType => {
  const context = React.useContext(TutorialContext);
  if (!context) {
    throw new Error('useTutorial must be used within a TutorialProvider');
  }
  return context;
};

// Tutorial Overlay Component
export const TutorialOverlay: React.FC = () => {
  const {
    isActive,
    currentTutorial,
    currentStep,
    nextStep,
    previousStep,
    endTutorial,
    skipTutorial,
    progress,
  } = useTutorial();

  if (!isActive || !currentTutorial) return null;

  const step = currentTutorial.steps[currentStep];
  const isLastStep = currentStep === currentTutorial.steps.length - 1;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-black/50" onClick={skipTutorial} />

      {/* Tutorial card */}
      <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-md">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {currentTutorial.title}
              </h3>
              <button
                onClick={endTutorial}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                aria-label="Close tutorial"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            {/* Progress bar */}
            <div className="w-full h-1 bg-gray-200 dark:bg-gray-700 rounded-full">
              <div 
                className="h-full bg-blue-600 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            
            {/* Step indicator */}
            <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
              Step {currentStep + 1} of {currentTutorial.steps.length}
            </p>
          </div>

          {/* Content */}
          <div className="px-6 py-4">
            <h4 className="text-xl font-medium text-gray-900 dark:text-white mb-2">
              {step.title}
            </h4>
            <p className="text-gray-600 dark:text-gray-300">
              {step.content}
            </p>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 bg-gray-50 dark:bg-gray-900 flex items-center justify-between">
            <button
              onClick={previousStep}
              disabled={currentStep === 0}
              className={`px-4 py-2 text-sm font-medium rounded-lg ${
                currentStep === 0
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-700 hover:bg-gray-200 dark:text-gray-300 dark:hover:bg-gray-800'
              }`}
            >
              Previous
            </button>
            
            <button
              onClick={endTutorial}
              className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            >
              Skip
            </button>
            
            <button
              onClick={nextStep}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg"
            >
              {step.actionLabel || (isLastStep ? 'Finish' : 'Next')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Tutorial list for help menu
export const TutorialList: React.FC = () => {
  const { startTutorial } = useTutorial();

  return (
    <div className="space-y-2">
      <h4 className="font-medium text-gray-900 dark:text-white mb-3">Tutorials</h4>
      {tutorials.map((tutorial) => (
        <button
          key={tutorial.id}
          onClick={() => startTutorial(tutorial)}
          className="w-full text-left px-4 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
        >
          <p className="font-medium text-gray-900 dark:text-white">{tutorial.title}</p>
          {tutorial.description && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {tutorial.description}
            </p>
          )}
        </button>
      ))}
    </div>
  );
};

export { tutorials };
export default TutorialProvider;
