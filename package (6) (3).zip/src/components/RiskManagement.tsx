import React, { useState, useMemo } from 'react';
import DataTable from './ui/DataTable';
import StatusBadge from './ui/StatusBadge';
import Modal from './ui/Modal';
import { useRisks, useCreateRisk } from '../modules/risks/hooks/useRisks';
import { Risk } from '../types/qms';
import { useOrganization } from '@/contexts/OrganizationContext';
import { toast } from 'sonner';
import CreateCAPAModal from './CreateCAPAModal';

const RiskManagement: React.FC = () => {
  const { currentOrganization } = useOrganization();
  const [selectedRisk, setSelectedRisk] = useState<Risk | null>(null);
  const [showNewRiskModal, setShowNewRiskModal] = useState(false);
  const [showLinkDocumentModal, setShowLinkDocumentModal] = useState(false);
  const [showCreateCAPAModal, setShowCreateCAPAModal] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterRiskLevel, setFilterRiskLevel] = useState<string>('all');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Risk form state - ISO 14971:2019 compliant
  const [newRiskData, setNewRiskData] = useState({
    // Risk Identification
    title: '',
    description: '',
    
    // Product Information
    deviceName: '',
    deviceClass: '' as string,
    intendedUse: '',
    intendedUser: '',
    useEnvironment: '',
    
    // Hazard Identification
    hazardIdentification: '',
    hazard: '',
    hazardousSituation: '',
    harm: '',
    harmSeverity: 1 as number,
    harmSeverityClassification: '' as string,
    
    // Risk Estimation
    severity: 3 as number,
    probability: 3 as number,
    detectability: 3 as number,
    
    // Category
    category: 'Design' as string,
    
    // Risk Evaluation
    riskAcceptabilityCriteria: '',
    riskBenefitAnalysis: '',
    
    // Risk Control
    mitigationMeasures: '',
    riskControlOption: '' as string,
    
    // Risk Review
    owner: '',
    reviewFrequency: '',
    dueDate: '',
    
    // FMEA
    failureMode: '',
    failureEffect: '',
    failureCause: '',
    detectionMethod: '',
    
    // Links
    linkedCAPAId: '',
    linkedDeviationId: '',
    linkedDocumentId: '',
  });

  // Use React Query hooks for data fetching
  const { data: risks = [], isLoading, error, refetch } = useRisks({
    category: filterCategory !== 'all' ? filterCategory : undefined,
    status: filterStatus !== 'all' ? filterStatus : undefined,
    riskLevel: filterRiskLevel !== 'all' ? filterRiskLevel : undefined,
  });
  
  // Use mutations
  const createRiskMutation = useCreateRisk();

  // Calculate RPN helper
  const calculateRPN = (severity: number, probability: number, detectability: number) => {
    return severity * probability * detectability;
  };

  // Handle new risk creation
  const handleCreateRisk = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization) {
      toast.error('Organization required');
      return;
    }

    // Validation
    if (!newRiskData.title.trim()) {
      toast.error('Risk title is required');
      return;
    }
    if (!newRiskData.description.trim()) {
      toast.error('Description is required');
      return;
    }
    if (!newRiskData.hazard.trim()) {
      toast.error('Hazard is required');
      return;
    }
    if (!newRiskData.harm.trim()) {
      toast.error('Harm is required');
      return;
    }
    if (!newRiskData.owner.trim()) {
      toast.error('Risk owner is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const rpn = calculateRPN(newRiskData.severity, newRiskData.probability, newRiskData.detectability);
      
      await createRiskMutation.mutateAsync({
        input: {
          // Risk Identification
          title: newRiskData.title,
          description: newRiskData.description,
          
          // Product Information
          deviceName: newRiskData.deviceName,
          deviceClass: newRiskData.deviceClass as 'Class I' | 'Class IIa' | 'Class IIb' | 'Class III' | undefined,
          intendedUse: newRiskData.intendedUse,
          intendedUser: newRiskData.intendedUser,
          useEnvironment: newRiskData.useEnvironment,
          
          // Hazard Identification
          hazardIdentification: newRiskData.hazardIdentification,
          hazard: newRiskData.hazard,
          hazardousSituation: newRiskData.hazardousSituation,
          harm: newRiskData.harm,
          harmSeverity: newRiskData.harmSeverity,
          harmSeverityClassification: newRiskData.harmSeverityClassification as 'Negligible' | 'Minor' | 'Serious' | 'Critical' | 'Catastrophic' | undefined,
          
          // Risk Estimation
          severity: newRiskData.severity,
          probability: newRiskData.probability,
          detectability: newRiskData.detectability,
          
          // Category
          category: newRiskData.category as 'Design' | 'Manufacturing' | 'Use/Misuse' | 'Environmental' | 'Regulatory' | 'Software' | 'Biological' | 'Supplier',
          
          // Risk Evaluation
          riskAcceptabilityCriteria: newRiskData.riskAcceptabilityCriteria,
          riskBenefitAnalysis: newRiskData.riskBenefitAnalysis,
          
          // Risk Control
          mitigationMeasures: newRiskData.mitigationMeasures,
          riskControlOption: newRiskData.riskControlOption as 'Inherently Safe Design' | 'Protective Measure' | 'Information for Safety' | undefined,
          
          // Risk Review
          owner: newRiskData.owner,
          reviewFrequency: newRiskData.reviewFrequency,
          dueDate: newRiskData.dueDate,
          
          // FMEA
          failureMode: newRiskData.failureMode,
          failureEffect: newRiskData.failureEffect,
          failureCause: newRiskData.failureCause,
          detectionMethod: newRiskData.detectionMethod,
          
          // Links
          linkedCAPAId: newRiskData.linkedCAPAId,
          linkedDeviationId: newRiskData.linkedDeviationId,
          linkedDocumentId: newRiskData.linkedDocumentId,
        },
        userId: currentOrganization.id,
      });
      
      toast.success('Risk created successfully!', {
        description: `RPN: ${rpn} - Initial risk assessment completed.`,
      });
      
      // Reset form and close modal
      setNewRiskData({
        title: '',
        description: '',
        deviceName: '',
        deviceClass: '',
        intendedUse: '',
        intendedUser: '',
        useEnvironment: '',
        hazardIdentification: '',
        hazard: '',
        hazardousSituation: '',
        harm: '',
        harmSeverity: 1,
        harmSeverityClassification: '',
        severity: 3,
        probability: 3,
        detectability: 3,
        category: 'Design',
        riskAcceptabilityCriteria: '',
        riskBenefitAnalysis: '',
        mitigationMeasures: '',
        riskControlOption: '',
        owner: '',
        reviewFrequency: '',
        dueDate: '',
        failureMode: '',
        failureEffect: '',
        failureCause: '',
        detectionMethod: '',
        linkedCAPAId: '',
        linkedDeviationId: '',
        linkedDocumentId: '',
      });
      setShowNewRiskModal(false);
      
      // Refresh the risk list
      refetch();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create risk');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredRisks = useMemo(() => {
    return risks.filter(risk => {
      if (filterCategory !== 'all' && risk.category !== filterCategory) return false;
      if (filterStatus !== 'all' && risk.status !== filterStatus) return false;
      if (filterRiskLevel !== 'all' && risk.riskLevel !== filterRiskLevel) return false;
      return true;
    });
  }, [risks, filterCategory, filterStatus, filterRiskLevel]);

  const getRiskColor = (severity: number, probability: number) => {
    const score = severity * probability;
    if (score >= 15) return 'bg-red-500';
    if (score >= 8) return 'bg-orange-500';
    if (score >= 4) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const columns = [
    { key: 'riskId', header: 'Risk ID', sortable: true },
    { 
      key: 'title', 
      header: 'Title',
      render: (risk: Risk) => (
        <span className="line-clamp-1 max-w-xs">{risk.title}</span>
      )
    },
    { 
      key: 'category', 
      header: 'Category',
      render: (risk: Risk) => (
        <span className={`px-2 py-1 rounded text-xs font-medium ${
          risk.category === 'Design' ? 'bg-blue-100 text-blue-700' :
          risk.category === 'Manufacturing' ? 'bg-purple-100 text-purple-700' :
          risk.category === 'Use/Misuse' ? 'bg-orange-100 text-orange-700' :
          risk.category === 'Environmental' ? 'bg-green-100 text-green-700' :
          'bg-red-100 text-red-700'
        }`}>
          {risk.category}
        </span>
      )
    },
    { 
      key: 'initialRisk', 
      header: 'Initial Risk',
      render: (risk: Risk) => (
        <div className="flex items-center gap-2">
          <div className={`w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold ${getRiskColor(risk.severity, risk.probability)}`}>
            {risk.severity * risk.probability}
          </div>
          <span className="text-xs text-gray-500">S{risk.severity}×P{risk.probability}</span>
        </div>
      )
    },
    { 
      key: 'riskLevel', 
      header: 'Risk Level',
      render: (risk: Risk) => <StatusBadge status={risk.riskLevel} variant="risk" />
    },
    { 
      key: 'residualRisk', 
      header: 'Residual Risk',
      render: (risk: Risk) => (
        <div className="flex items-center gap-2">
          <div className={`w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold ${getRiskColor(risk.residualSeverity, risk.residualProbability)}`}>
            {risk.residualSeverity * risk.residualProbability}
          </div>
          <span className="text-xs text-gray-500">S{risk.residualSeverity}×P{risk.residualProbability}</span>
        </div>
      )
    },
    { 
      key: 'residualRiskLevel', 
      header: 'Residual Level',
      render: (risk: Risk) => <StatusBadge status={risk.residualRiskLevel} variant="risk" />
    },
    { 
      key: 'status', 
      header: 'Status',
      render: (risk: Risk) => <StatusBadge status={risk.status} />
    },
    { key: 'owner', header: 'Owner', sortable: true },
  ];

  const stats = {
    total: risks.length,
    unacceptable: risks.filter(r => r.riskLevel === 'Unacceptable').length,
    alarp: risks.filter(r => r.riskLevel === 'ALARP').length,
    acceptable: risks.filter(r => r.riskLevel === 'Acceptable').length,
    mitigated: risks.filter(r => r.status === 'Mitigated').length,
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Risk Management</h2>
          <p className="text-gray-500 mt-1">Risk analysis per ISO 14971:2019 and ISO 13485 Section 7.1</p>
        </div>
        <button
          onClick={() => setShowNewRiskModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add Risk
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          <p className="text-sm text-gray-500">Total Risks</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-red-200 p-4 bg-red-50">
          <p className="text-sm text-red-600">Unacceptable</p>
          <p className="text-2xl font-bold text-red-700 mt-1">{stats.unacceptable}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-yellow-200 p-4 bg-yellow-50">
          <p className="text-sm text-yellow-600">ALARP</p>
          <p className="text-2xl font-bold text-yellow-700 mt-1">{stats.alarp}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-green-200 p-4 bg-green-50">
          <p className="text-sm text-green-600">Acceptable</p>
          <p className="text-2xl font-bold text-green-700 mt-1">{stats.acceptable}</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-blue-200 p-4 bg-blue-50">
          <p className="text-sm text-blue-600">Mitigated</p>
          <p className="text-2xl font-bold text-blue-700 mt-1">{stats.mitigated}</p>
        </div>
      </div>

      {/* Risk Matrix */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Risk Assessment Matrix (Severity × Probability)</h3>
        <div className="flex gap-8">
          <div className="flex-1">
            <div className="grid grid-cols-6 gap-1">
              {/* Header row */}
              <div className="h-10"></div>
              {[1, 2, 3, 4, 5].map(p => (
                <div key={p} className="h-10 flex items-center justify-center text-sm font-medium text-gray-600">
                  P{p}
                </div>
              ))}
              
              {/* Matrix rows */}
              {[5, 4, 3, 2, 1].map(s => (
                <React.Fragment key={s}>
                  <div className="h-12 flex items-center justify-center text-sm font-medium text-gray-600">
                    S{s}
                  </div>
                  {[1, 2, 3, 4, 5].map(p => {
                    const score = s * p;
                    const riskCount = risks.filter(r => r.severity === s && r.probability === p).length;
                    return (
                      <div
                        key={`${s}-${p}`}
                        className={`h-12 rounded flex items-center justify-center text-white text-sm font-bold ${
                          score >= 15 ? 'bg-red-500' :
                          score >= 8 ? 'bg-orange-500' :
                          score >= 4 ? 'bg-yellow-500' :
                          'bg-green-500'
                        }`}
                      >
                        {riskCount > 0 && (
                          <span className="bg-white/30 rounded-full w-6 h-6 flex items-center justify-center">
                            {riskCount}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
            <div className="flex items-center justify-center gap-2 mt-2 text-sm text-gray-500">
              <span>Probability</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
              </svg>
            </div>
          </div>
          
          <div className="w-48">
            <h4 className="text-sm font-medium text-gray-700 mb-3">Legend</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-red-500 rounded"></div>
                <span className="text-sm text-gray-600">Unacceptable (15-25)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-orange-500 rounded"></div>
                <span className="text-sm text-gray-600">ALARP (8-14)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-yellow-500 rounded"></div>
                <span className="text-sm text-gray-600">Tolerable (4-7)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-green-500 rounded"></div>
                <span className="text-sm text-gray-600">Acceptable (1-3)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Categories</option>
            <option value="Design">Design</option>
            <option value="Manufacturing">Manufacturing</option>
            <option value="Use/Misuse">Use/Misuse</option>
            <option value="Environmental">Environmental</option>
            <option value="Regulatory">Regulatory</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Risk Level</label>
          <select
            value={filterRiskLevel}
            onChange={(e) => setFilterRiskLevel(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Levels</option>
            <option value="Unacceptable">Unacceptable</option>
            <option value="ALARP">ALARP</option>
            <option value="Acceptable">Acceptable</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="Open">Open</option>
            <option value="Mitigated">Mitigated</option>
            <option value="Accepted">Accepted</option>
            <option value="Closed">Closed</option>
          </select>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
            </svg>
            Export Risk Register
          </button>
        </div>
      </div>

      {/* Data Table */}
      <DataTable
        data={filteredRisks}
        columns={columns}
        onRowClick={(risk) => setSelectedRisk(risk)}
        searchPlaceholder="Search risks..."
        searchKeys={['riskId', 'title', 'hazard', 'owner']}
      />

      {/* Risk Detail Modal */}
      <Modal
        isOpen={!!selectedRisk}
        onClose={() => setSelectedRisk(null)}
        title="Risk Details"
        size="xl"
      >
        {selectedRisk && (
          <div className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <h4 className="text-lg font-semibold text-gray-900">{selectedRisk.riskId}</h4>
                  <StatusBadge status={selectedRisk.riskLevel} variant="risk" />
                </div>
                <p className="text-gray-700 mt-1">{selectedRisk.title}</p>
              </div>
              <StatusBadge status={selectedRisk.status} />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Category</p>
                <p className="font-medium text-gray-900">{selectedRisk.category}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Owner</p>
                <p className="font-medium text-gray-900">{selectedRisk.owner}</p>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Hazard</p>
              <p className="text-gray-700">{selectedRisk.hazard}</p>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Potential Harm</p>
              <p className="text-gray-700">{selectedRisk.harm}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-red-50 rounded-lg p-4 border border-red-200">
                <p className="text-xs text-red-600 uppercase tracking-wider mb-2">Initial Risk Assessment</p>
                <div className="flex items-center gap-4">
                  <div>
                    <span className="text-sm text-gray-600">Severity: </span>
                    <span className="font-bold text-gray-900">{selectedRisk.severity}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Probability: </span>
                    <span className="font-bold text-gray-900">{selectedRisk.probability}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Score: </span>
                    <span className="font-bold text-red-700">{selectedRisk.severity * selectedRisk.probability}</span>
                  </div>
                </div>
              </div>
              <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                <p className="text-xs text-green-600 uppercase tracking-wider mb-2">Residual Risk Assessment</p>
                <div className="flex items-center gap-4">
                  <div>
                    <span className="text-sm text-gray-600">Severity: </span>
                    <span className="font-bold text-gray-900">{selectedRisk.residualSeverity}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Probability: </span>
                    <span className="font-bold text-gray-900">{selectedRisk.residualProbability}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Score: </span>
                    <span className="font-bold text-green-700">{selectedRisk.residualSeverity * selectedRisk.residualProbability}</span>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">Mitigation Measures</p>
              <p className="text-gray-700">{selectedRisk.mitigationMeasures}</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">Last Reviewed</p>
              <p className="font-medium text-gray-900">{selectedRisk.lastReviewed}</p>
            </div>

            <div className="flex items-center gap-3 pt-4 border-t">
              <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Update Risk
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Add Mitigation
              </button>
              <button className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                Review History
              </button>
            </div>

            {/* Actions Following Risk Assessment */}
            {(selectedRisk.severity * selectedRisk.probability >= 8 || 
              selectedRisk.status === 'Open' || 
              selectedRisk.status === 'Under Review') && (
              <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
                <h4 className="text-sm font-semibold text-amber-800 mb-3 flex items-center gap-2">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Actions Following Risk Assessment
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <button 
                    onClick={() => setShowCreateCAPAModal(true)}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                    </svg>
                    Create CAPA
                  </button>
                  <button className="flex items-center justify-center gap-2 px-4 py-2 border border-amber-300 text-amber-700 rounded-lg hover:bg-amber-100 transition-colors">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    Report Deviation
                  </button>
                </div>
                <p className="text-xs text-amber-700 mt-2">
                  High-risk items may require corrective actions or deviation reporting.
                </p>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* New Risk Modal - ISO 14971:2019 Compliant Form */}
      <Modal
        isOpen={showNewRiskModal}
        onClose={() => setShowNewRiskModal(false)}
        title="Add New Risk Analysis"
        size="2xl"
      >
        <form onSubmit={handleCreateRisk} className="space-y-6">
          {/* Section 1: Risk Identification - ISO 14971:2019 Clause 5.2 */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <h3 className="text-sm font-semibold text-blue-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Risk Identification (ISO 14971:2019 Clause 5.2)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Risk Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newRiskData.title}
                  onChange={(e) => setNewRiskData({ ...newRiskData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Enter risk title"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={newRiskData.description}
                  onChange={(e) => setNewRiskData({ ...newRiskData, description: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Detailed description of the risk scenario"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category <span className="text-red-500">*</span>
                </label>
                <select
                  value={newRiskData.category}
                  onChange={(e) => setNewRiskData({ ...newRiskData, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  required
                >
                  <option value="Design">Design</option>
                  <option value="Manufacturing">Manufacturing</option>
                  <option value="Use/Misuse">Use/Misuse</option>
                  <option value="Environmental">Environmental</option>
                  <option value="Regulatory">Regulatory</option>
                  <option value="Software">Software</option>
                  <option value="Biological">Biological</option>
                  <option value="Supplier">Supplier</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Device Name
                </label>
                <input
                  type="text"
                  value={newRiskData.deviceName}
                  onChange={(e) => setNewRiskData({ ...newRiskData, deviceName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Name of the medical device"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Device Class
                </label>
                <select
                  value={newRiskData.deviceClass}
                  onChange={(e) => setNewRiskData({ ...newRiskData, deviceClass: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                >
                  <option value="">Select Class</option>
                  <option value="Class I">Class I</option>
                  <option value="Class IIa">Class IIa</option>
                  <option value="Class IIb">Class IIb</option>
                  <option value="Class III">Class III</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Intended Use
                </label>
                <input
                  type="text"
                  value={newRiskData.intendedUse}
                  onChange={(e) => setNewRiskData({ ...newRiskData, intendedUse: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="Intended use of the device"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Hazard Identification - ISO 14971:2019 Clause 5.3 */}
          <div className="bg-red-50 rounded-lg p-4 border border-red-200">
            <h3 className="text-sm font-semibold text-red-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              Hazard Identification (ISO 14971:2019 Clause 5.3)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hazard Identification
                </label>
                <textarea
                  value={newRiskData.hazardIdentification}
                  onChange={(e) => setNewRiskData({ ...newRiskData, hazardIdentification: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  placeholder="Describe the hazard identification process"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hazard <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={newRiskData.hazard}
                  onChange={(e) => setNewRiskData({ ...newRiskData, hazard: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  placeholder="Potential source of harm (e.g., electrical shock, toxic substance)"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Hazardous Situation
                </label>
                <textarea
                  value={newRiskData.hazardousSituation}
                  onChange={(e) => setNewRiskData({ ...newRiskData, hazardousSituation: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  placeholder="Circumstances in which people, property, or the environment are exposed to hazard"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Harm <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={newRiskData.harm}
                  onChange={(e) => setNewRiskData({ ...newRiskData, harm: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  placeholder="Damage to health (e.g., injury, death)"
                  required
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Harm Severity Classification
                  </label>
                  <select
                    value={newRiskData.harmSeverityClassification}
                    onChange={(e) => setNewRiskData({ ...newRiskData, harmSeverityClassification: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none"
                  >
                    <option value="">Select Classification</option>
                    <option value="Negligible">Negligible</option>
                    <option value="Minor">Minor</option>
                    <option value="Serious">Serious</option>
                    <option value="Critical">Critical</option>
                    <option value="Catastrophic">Catastrophic</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Risk Estimation - ISO 14971:2019 Clause 5.4 */}
          <div className="bg-yellow-50 rounded-lg p-4 border border-yellow-200">
            <h3 className="text-sm font-semibold text-yellow-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
              Risk Estimation (ISO 14971:2019 Clause 5.4)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Severity <span className="text-red-500">*</span>
                </label>
                <select
                  value={newRiskData.severity}
                  onChange={(e) => setNewRiskData({ ...newRiskData, severity: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  required
                >
                  <option value={1}>1 - Negligible</option>
                  <option value={2}>2 - Minor</option>
                  <option value={3}>3 - Moderate</option>
                  <option value={4}>4 - Major</option>
                  <option value={5}>5 - Catastrophic</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Probability <span className="text-red-500">*</span>
                </label>
                <select
                  value={newRiskData.probability}
                  onChange={(e) => setNewRiskData({ ...newRiskData, probability: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  required
                >
                  <option value={1}>1 - Rare</option>
                  <option value={2}>2 - Unlikely</option>
                  <option value={3}>3 - Possible</option>
                  <option value={4}>4 - Likely</option>
                  <option value={5}>5 - Almost Certain</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Detectability <span className="text-red-500">*</span>
                </label>
                <select
                  value={newRiskData.detectability}
                  onChange={(e) => setNewRiskData({ ...newRiskData, detectability: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-yellow-500 outline-none"
                  required
                >
                  <option value={1}>1 - Very Easy</option>
                  <option value={2}>2 - Easy</option>
                  <option value={3}>3 - Moderate</option>
                  <option value={4}>4 - Difficult</option>
                  <option value={5}>5 - Very Difficult</option>
                </select>
              </div>
            </div>
            <div className="mt-4 p-3 bg-yellow-100 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Initial RPN:</strong> {calculateRPN(newRiskData.severity, newRiskData.probability, newRiskData.detectability)} 
                (S={newRiskData.severity} × P={newRiskData.probability} × D={newRiskData.detectability})
              </p>
            </div>
          </div>

          {/* Section 4: Risk Control - ISO 14971:2019 Clause 7 */}
          <div className="bg-green-50 rounded-lg p-4 border border-green-200">
            <h3 className="text-sm font-semibold text-green-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              Risk Control (ISO 14971:2019 Clause 7)
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Risk Control Option
                </label>
                <select
                  value={newRiskData.riskControlOption}
                  onChange={(e) => setNewRiskData({ ...newRiskData, riskControlOption: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                >
                  <option value="">Select Option</option>
                  <option value="Inherently Safe Design">Inherently Safe Design</option>
                  <option value="Protective Measure">Protective Measure</option>
                  <option value="Information for Safety">Information for Safety</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Mitigation Measures
                </label>
                <textarea
                  value={newRiskData.mitigationMeasures}
                  onChange={(e) => setNewRiskData({ ...newRiskData, mitigationMeasures: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none"
                  placeholder="Describe risk control measures to reduce risk to acceptable levels"
                />
              </div>
            </div>
          </div>

          {/* Section 5: FMEA Additional Fields */}
          <div className="bg-purple-50 rounded-lg p-4 border border-purple-200">
            <h3 className="text-sm font-semibold text-purple-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
              </svg>
              FMEA Additional Fields
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Failure Mode
                </label>
                <input
                  type="text"
                  value={newRiskData.failureMode}
                  onChange={(e) => setNewRiskData({ ...newRiskData, failureMode: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="How the component fails"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Failure Effect
                </label>
                <input
                  type="text"
                  value={newRiskData.failureEffect}
                  onChange={(e) => setNewRiskData({ ...newRiskData, failureEffect: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="Effect of failure on system"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Failure Cause
                </label>
                <input
                  type="text"
                  value={newRiskData.failureCause}
                  onChange={(e) => setNewRiskData({ ...newRiskData, failureCause: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="Root cause of failure"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Detection Method
                </label>
                <input
                  type="text"
                  value={newRiskData.detectionMethod}
                  onChange={(e) => setNewRiskData({ ...newRiskData, detectionMethod: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none"
                  placeholder="Method to detect failure"
                />
              </div>
            </div>
          </div>

          {/* Section 6: Risk Review and Ownership */}
          <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
            <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Risk Review and Ownership
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Risk Owner <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={newRiskData.owner}
                  onChange={(e) => setNewRiskData({ ...newRiskData, owner: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none"
                  placeholder="Responsible person"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Review Frequency
                </label>
                <input
                  type="text"
                  value={newRiskData.reviewFrequency}
                  onChange={(e) => setNewRiskData({ ...newRiskData, reviewFrequency: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none"
                  placeholder="e.g., Monthly, Quarterly"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Due Date
                </label>
                <input
                  type="date"
                  value={newRiskData.dueDate}
                  onChange={(e) => setNewRiskData({ ...newRiskData, dueDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-500 focus:border-gray-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 7: Links to Other Modules */}
          <div className="bg-indigo-50 rounded-lg p-4 border border-indigo-200">
            <h3 className="text-sm font-semibold text-indigo-900 mb-3 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Links to Other Modules
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked CAPA ID
                </label>
                <input
                  type="text"
                  value={newRiskData.linkedCAPAId}
                  onChange={(e) => setNewRiskData({ ...newRiskData, linkedCAPAId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  placeholder="e.g., CAPA-2025-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked Deviation ID
                </label>
                <input
                  type="text"
                  value={newRiskData.linkedDeviationId}
                  onChange={(e) => setNewRiskData({ ...newRiskData, linkedDeviationId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  placeholder="e.g., DEV-2025-001"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Linked Document ID
                </label>
                <input
                  type="text"
                  value={newRiskData.linkedDocumentId}
                  onChange={(e) => setNewRiskData({ ...newRiskData, linkedDocumentId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                  placeholder="e.g., DOC-2025-001"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center gap-3 pt-4 border-t">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating Risk...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                  </svg>
                  Create Risk Analysis
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setShowNewRiskModal(false)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </Modal>

      {/* Create CAPA Modal - Linked to Risk */}
      <CreateCAPAModal
        isOpen={showCreateCAPAModal}
        onClose={() => setShowCreateCAPAModal(false)}
      />
    </div>
  );
};

export default RiskManagement;
