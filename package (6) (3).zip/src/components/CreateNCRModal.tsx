import React, { useState } from 'react';
import Modal from '@/components/ui/Modal';
import { useCreateNCR } from '@/modules/non-conformances/hooks/useNCRs';
import { useOrganization } from '@/contexts/OrganizationContext';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Audit } from '@/types/qms';

interface CreateNCRModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceAudit?: Audit;
  onSuccess?: () => void;
}

const CreateNCRModal: React.FC<CreateNCRModalProps> = ({
  isOpen,
  onClose,
  sourceAudit,
  onSuccess,
}) => {
  const { currentOrganization } = useOrganization();
  const { user } = useAuth();
  const createNCRMutation = useCreateNCR();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    title: sourceAudit ? `NCR from Audit ${sourceAudit.auditNumber}` : '',
    description: sourceAudit 
      ? `Non-conformance identified during ${sourceAudit.type} Audit: ${sourceAudit.title}\n\nAudit Department: ${sourceAudit.department}\nLead Auditor: ${sourceAudit.leadAuditor}`
      : '',
    type: 'Process' as string,
    severity: 'Minor' as string,
    source: sourceAudit ? 'Internal Audit' as string : 'Internal Inspection' as string,
    sourceDescription: '',
    detectedDate: new Date().toISOString().split('T')[0],
    detectedBy: user?.email || '',
    lotNumber: '',
    quantityAffected: 0,
    totalQuantity: 0,
    productName: '',
    partNumber: '',
    immediateAction: '',
    assignedTo: '',
    department: sourceAudit?.department || '',
    dueDate: '',
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseInt(value) || 0 : value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentOrganization || !user) {
      toast.error('Organization or user not found');
      return;
    }

    if (!formData.title.trim()) {
      toast.error('NCR title is required');
      return;
    }

    if (!formData.description.trim()) {
      toast.error('Description is required');
      return;
    }

    setIsSubmitting(true);
    try {
      const ncr = await createNCRMutation.mutateAsync({
        input: {
          title: formData.title,
          description: formData.description,
          type: formData.type,
          severity: formData.severity,
          source: formData.source,
          sourceDescription: formData.sourceDescription,
          detectedDate: formData.detectedDate,
          detectedBy: formData.detectedBy,
          lotNumber: formData.lotNumber || undefined,
          quantityAffected: formData.quantityAffected || undefined,
          totalQuantity: formData.totalQuantity || undefined,
          productName: formData.productName || undefined,
          partNumber: formData.partNumber || undefined,
          immediateAction: formData.immediateAction || undefined,
          assignedTo: formData.assignedTo || undefined,
          department: formData.department || undefined,
          dueDate: formData.dueDate || undefined,
        },
        userId: user.id,
      });

      // If there's a source audit, we would link it here
      // This would require an additional API call to update the NCR with the audit link
      if (sourceAudit) {
        toast.success('NCR created successfully and linked to audit!', {
          description: `NCR ${ncr.ncrNumber} has been created from Audit ${sourceAudit.auditNumber}.`,
        });
      } else {
        toast.success('NCR created successfully!', {
          description: `NCR ${ncr.ncrNumber} has been created.`,
        });
      }

      // Reset form
      setFormData({
        title: '',
        description: '',
        type: 'Process',
        severity: 'Minor',
        source: 'Internal Inspection',
        sourceDescription: '',
        detectedDate: new Date().toISOString().split('T')[0],
        detectedBy: user?.email || '',
        lotNumber: '',
        quantityAffected: 0,
        totalQuantity: 0,
        productName: '',
        partNumber: '',
        immediateAction: '',
        assignedTo: '',
        department: '',
        dueDate: '',
      });

      onSuccess?.();
      onClose();
    } catch (err: any) {
      toast.error(err.message || 'Failed to create NCR');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Create Non-Conformance Report"
      size="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Source Information */}
        {sourceAudit && (
          <div className="bg-red-50 rounded-lg p-4 border border-red-200">
            <h4 className="text-sm font-semibold text-red-800 mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
              </svg>
              Source Information
            </h4>
            <p className="text-sm text-red-700">
              <strong>Source Audit:</strong> {sourceAudit.auditNumber} - {sourceAudit.title}
            </p>
            <p className="text-xs text-red-600 mt-1">
              This NCR will be automatically linked to the source audit for full traceability.
            </p>
          </div>
        )}

        {/* Basic Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Title <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Enter NCR title"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Type <span className="text-red-500">*</span>
            </label>
            <select
              name="type"
              value={formData.type}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="Product">Product</option>
              <option value="Process">Process</option>
              <option value="System">System</option>
              <option value="Supplier">Supplier</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Severity <span className="text-red-500">*</span>
            </label>
            <select
              name="severity"
              value={formData.severity}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="Critical">Critical</option>
              <option value="Major">Major</option>
              <option value="Minor">Minor</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Source <span className="text-red-500">*</span>
            </label>
            <select
              name="source"
              value={formData.source}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="Incoming Inspection">Incoming Inspection</option>
              <option value="In-Process Inspection">In-Process Inspection</option>
              <option value="Final Inspection">Final Inspection</option>
              <option value="Customer Complaint">Customer Complaint</option>
              <option value="Internal Audit">Internal Audit</option>
              <option value="Process Monitoring">Process Monitoring</option>
              <option value="Supplier">Supplier</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Detected Date <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              name="detectedDate"
              value={formData.detectedDate}
              onChange={handleChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Detected By
            </label>
            <input
              type="text"
              name="detectedBy"
              value={formData.detectedBy}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Name of person who detected"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Assigned To
            </label>
            <input
              type="text"
              name="assignedTo"
              value={formData.assignedTo}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Responsible person"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Department
            </label>
            <input
              type="text"
              name="department"
              value={formData.department}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              placeholder="Department"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Due Date
            </label>
            <input
              type="date"
              name="dueDate"
              value={formData.dueDate}
              onChange={handleChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            />
          </div>
        </div>

        {/* Product Information */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Product Information</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Product Name
              </label>
              <input
                type="text"
                name="productName"
                value={formData.productName}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Affected product"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Part Number
              </label>
              <input
                type="text"
                name="partNumber"
                value={formData.partNumber}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Part number"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lot Number
              </label>
              <input
                type="text"
                name="lotNumber"
                value={formData.lotNumber}
                onChange={handleChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Lot/batch number"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Quantity Affected
                </label>
                <input
                  type="number"
                  name="quantityAffected"
                  value={formData.quantityAffected}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Total Quantity
                </label>
                <input
                  type="number"
                  name="totalQuantity"
                  value={formData.totalQuantity}
                  onChange={handleChange}
                  min="0"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Description and Immediate Action */}
        <div className="border-t pt-4">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Description of Non-Conformance <span className="text-red-500">*</span>
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Detailed description of the non-conformance..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Immediate Action (Containment)
              </label>
              <textarea
                name="immediateAction"
                value={formData.immediateAction}
                onChange={handleChange}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Immediate actions taken to contain the issue..."
              />
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex gap-3 pt-4 border-t">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Creating NCR...' : 'Create NCR'}
          </button>
          <button
            type="button"
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default CreateNCRModal;
