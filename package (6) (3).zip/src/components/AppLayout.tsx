import React, { useState, lazy, Suspense } from 'react';
import { ViewType } from '../types/qms';
import { useAuth } from '../contexts/AuthContext';
import { OrganizationProvider } from '../contexts/OrganizationContext';
import { ComplianceProvider } from '../contexts/ComplianceContext';
import { ChangeControlProvider } from '../contexts/ChangeControlContext';
import { DeviationProvider } from '../contexts/DeviationContext';
import Sidebar from './Sidebar';
import Header from './Header';
import UserProfile from './UserProfile';
import LegalDocumentAcceptance from './compliance/LegalDocumentAcceptance';
import UserManagement from './UserManagement';

// Lazy load heavy components for code splitting (Phase 5 Optimization)
const Dashboard = lazy(() => import('./Dashboard'));
const DocumentControl = lazy(() => import('./DocumentControl'));
const CAPAManagement = lazy(() => import('./CAPAManagement'));
const AuditManagement = lazy(() => import('./AuditManagement'));
const NonConformance = lazy(() => import('./NonConformance'));
const TrainingRecords = lazy(() => import('./TrainingRecords'));
const RiskManagement = lazy(() => import('./RiskManagement'));
const Reports = lazy(() => import('./Reports'));
const CompliancePage = lazy(() => import('../pages/Compliance'));
const ChangeControlPage = lazy(() => import('../pages/ChangeControl'));
const DeviationPage = lazy(() => import('../pages/Deviation'));

// Loading fallback component
const ComponentLoader = () => (
  <div className="flex items-center justify-center h-64">
    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
  </div>
);

type ExtendedViewType = ViewType | 'profile' | 'compliance' | 'change_control' | 'deviation' | 'users';

const AppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<ExtendedViewType>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { user, loading, hasPermission } = useAuth();

  const getHeaderInfo = () => {
    switch (currentView) {
      case 'dashboard':
        return { title: 'Dashboard', subtitle: 'Quality Management System Overview' };
      case 'documents':
        return { title: 'Document Control', subtitle: 'Manage controlled documents' };
      case 'capa':
        return { title: 'CAPA Management', subtitle: 'Corrective and Preventive Actions' };
      case 'audits':
        return { title: 'Audit Management', subtitle: 'Internal and external audits' };
      case 'ncr':
        return { title: 'Non-Conformance Reports', subtitle: 'Track and resolve non-conformances' };
      case 'training':
        return { title: 'Training Records', subtitle: 'Employee competence and training' };
      case 'risk':
        return { title: 'Risk Management', subtitle: 'ISO 14971 compliant risk analysis' };
      case 'reports':
        return { title: 'Reports & Analytics', subtitle: 'Management review and performance metrics' };
      case 'compliance':
        return { title: 'Compliance', subtitle: 'Regulatory compliance and documentation' };
      case 'change_control':
        return { title: 'Change Control', subtitle: 'Manage changes to products and processes' };
      case 'deviation':
        return { title: 'Deviations', subtitle: 'Track and manage deviations from procedures' };
      case 'profile':
        return { title: 'My Profile', subtitle: 'Manage your account settings' };
      case 'users':
        return { title: 'User Management', subtitle: 'Manage system users and permissions' };
      default:
        return { title: 'QMS Pro', subtitle: 'Quality Management System' };
    }
  };

  const renderContent = () => {
    // Show loading spinner while checking auth
    if (loading) {
      return (
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-500">Loading...</p>
          </div>
        </div>
      );
    }

    // Profile view
    if (currentView === 'profile') {
      if (!user) {
        return (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <svg className="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Sign in required</h3>
              <p className="text-gray-500">Please sign in to view your profile.</p>
            </div>
          </div>
        );
      }
      return <UserProfile />;
    }

    switch (currentView) {
      case 'dashboard':
        return <Suspense fallback={<ComponentLoader />}><Dashboard /></Suspense>;
      case 'documents':
        return <Suspense fallback={<ComponentLoader />}><DocumentControl /></Suspense>;
      case 'capa':
        return <Suspense fallback={<ComponentLoader />}><CAPAManagement /></Suspense>;
      case 'audits':
        return <Suspense fallback={<ComponentLoader />}><AuditManagement /></Suspense>;
      case 'ncr':
        return <Suspense fallback={<ComponentLoader />}><NonConformance /></Suspense>;
      case 'training':
        return <Suspense fallback={<ComponentLoader />}><TrainingRecords /></Suspense>;
      case 'risk':
        return <Suspense fallback={<ComponentLoader />}><RiskManagement /></Suspense>;
      case 'reports':
        return <Suspense fallback={<ComponentLoader />}><Reports /></Suspense>;
      case 'compliance':
        return <Suspense fallback={<ComponentLoader />}><CompliancePage /></Suspense>;
      case 'change_control':
        return <Suspense fallback={<ComponentLoader />}><ChangeControlPage /></Suspense>;
      case 'deviation':
        return <Suspense fallback={<ComponentLoader />}><DeviationPage /></Suspense>;
      case 'users':
        return <UserManagement />;
      default:
        return <Suspense fallback={<ComponentLoader />}><Dashboard /></Suspense>;
    }
  };

  const headerInfo = getHeaderInfo();

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar
        currentView={currentView === 'profile' ? 'dashboard' : currentView}
        onViewChange={(view) => setCurrentView(view)}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title={headerInfo.title} 
          subtitle={headerInfo.subtitle}
          onProfileClick={() => setCurrentView('profile')}
        />
        <main className="flex-1 overflow-y-auto">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

const AppLayout: React.FC = () => {
  return (
    <OrganizationProvider>
      <ComplianceProvider>
        <ChangeControlProvider>
          <DeviationProvider>
            <AppContent />
            <LegalDocumentAcceptance />
          </DeviationProvider>
        </ChangeControlProvider>
      </ComplianceProvider>
    </OrganizationProvider>
  );
};

export default AppLayout;
