import React from 'react';
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  CreditCard,
  Calendar,
  ChevronRight
} from 'lucide-react';

interface SubscriptionStatusProps {
  status: 'active' | 'trialing' | 'past_due' | 'canceled' | 'unpaid';
  planName: string;
  currentPeriodEnd?: string;
  trialEnd?: string;
  cancelAtPeriodEnd?: boolean;
  onManageBilling?: () => void;
}

const statusConfig = {
  active: {
    icon: CheckCircle,
    color: 'text-green-600',
    bgColor: 'bg-green-50',
    label: 'Active',
    description: 'Your subscription is active',
  },
  trialing: {
    icon: Clock,
    color: 'text-blue-600',
    bgColor: 'bg-blue-50',
    label: 'Trial',
    description: 'Free trial active',
  },
  past_due: {
    icon: AlertTriangle,
    color: 'text-orange-600',
    bgColor: 'bg-orange-50',
    label: 'Past Due',
    description: 'Payment failed - update your payment method',
  },
  canceled: {
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    label: 'Canceled',
    description: 'Subscription will end at period end',
  },
  unpaid: {
    icon: XCircle,
    color: 'text-red-600',
    bgColor: 'bg-red-50',
    label: 'Unpaid',
    description: 'Subscription suspended',
  },
};

const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({
  status,
  planName,
  currentPeriodEnd,
  trialEnd,
  cancelAtPeriodEnd,
  onManageBilling,
}) => {
  const config = statusConfig[status];
  const StatusIcon = config.icon;

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getDaysRemaining = () => {
    const endDate = trialEnd || currentPeriodEnd;
    if (!endDate) return null;
    
    const now = new Date();
    const end = new Date(endDate);
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  const daysRemaining = getDaysRemaining();

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className={`w-12 h-12 rounded-xl ${config.bgColor} flex items-center justify-center`}>
            <StatusIcon className={`w-6 h-6 ${config.color}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold text-gray-900">{planName}</h3>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.bgColor} ${config.color}`}>
                {config.label}
              </span>
            </div>
            <p className="text-sm text-gray-500">{config.description}</p>
          </div>
        </div>

        {onManageBilling && (
          <button
            onClick={onManageBilling}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1"
          >
            Manage Billing
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Trial Warning */}
      {status === 'trialing' && daysRemaining !== null && daysRemaining <= 7 && (
        <div className="mb-6 p-4 bg-orange-50 border border-orange-200 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-orange-800">
                {daysRemaining <= 0 
                  ? 'Your trial has ended' 
                  : `Your trial ends in ${daysRemaining} day${daysRemaining > 1 ? 's' : ''}`
                }
              </p>
              <p className="text-sm text-orange-700 mt-1">
                Subscribe now to continue using all features
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Cancellation Warning */}
      {cancelAtPeriodEnd && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-800">
                Your subscription will be canceled at the end of the billing period
              </p>
              <p className="text-sm text-red-700 mt-1">
                You will lose access to premium features on {formatDate(currentPeriodEnd)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Details Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 text-gray-500 mb-1">
            <Calendar className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">
              {status === 'trialing' ? 'Trial Ends' : 'Next Billing'}
            </span>
          </div>
          <p className="text-sm font-medium text-gray-900">
            {formatDate(status === 'trialing' ? trialEnd : currentPeriodEnd)}
          </p>
        </div>

        <div className="p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 text-gray-500 mb-1">
            <CreditCard className="w-4 h-4" />
            <span className="text-xs font-medium uppercase tracking-wider">Payment Method</span>
          </div>
          <p className="text-sm font-medium text-gray-900">
            Card ending in ••••
          </p>
        </div>
      </div>

      {/* Days Remaining Progress */}
      {status === 'trialing' && daysRemaining !== null && daysRemaining > 0 && (
        <div className="mt-4">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="text-gray-500">Trial Progress</span>
            <span className="font-medium text-gray-900">{daysRemaining} days remaining</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all"
              style={{ width: `${Math.max(0, Math.min(100, (14 - daysRemaining) / 14 * 100))}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionStatus;
