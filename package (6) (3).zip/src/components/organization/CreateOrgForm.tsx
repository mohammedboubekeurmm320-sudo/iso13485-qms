import React, { useState } from 'react';
import { useOrganization } from '@/contexts/OrganizationContext';
import { Building2, Loader2 } from 'lucide-react';

interface CreateOrgFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

const CreateOrgForm: React.FC<CreateOrgFormProps> = ({ onSuccess, onCancel }) => {
  const { createOrganization, isLoading } = useOrganization();
  const [name, setName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('Organization name is required');
      return;
    }

    try {
      await createOrganization(name.trim());
      onSuccess?.();
    } catch (err: any) {
      setError(err.message || 'Failed to create organization');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
          <Building2 className="w-6 h-6 text-blue-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Create Organization</h3>
          <p className="text-sm text-gray-500">Set up your company or team workspace</p>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      <div>
        <label htmlFor="orgName" className="block text-sm font-medium text-gray-700 mb-1">
          Organization Name
        </label>
        <input
          id="orgName"
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter organization name"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
          disabled={isLoading}
        />
        <p className="text-xs text-gray-500 mt-1">
          This will be displayed in your workspace
        </p>
      </div>

      <div className="flex gap-3 pt-4">
        {onCancel && (
          <button
            type="button"
            onClick={onCancel}
            className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            disabled={isLoading}
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={isLoading || !name.trim()}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Creating...
            </>
          ) : (
            'Create Organization'
          )}
        </button>
      </div>
    </form>
  );
};

export default CreateOrgForm;
