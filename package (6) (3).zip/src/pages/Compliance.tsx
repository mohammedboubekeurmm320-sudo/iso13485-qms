import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ComplianceDashboard from '@/components/compliance/ComplianceDashboard';
import ComplianceReportGenerator from '@/components/compliance/ComplianceReportGenerator';
import AuditLogViewer from '@/components/compliance/AuditLogViewer';
import LegalDocumentViewer from '@/components/compliance/LegalDocumentViewer';

export default function CompliancePage() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Conformité Réglementaire</h1>
        <p className="text-muted-foreground">
          Gestion de la conformité ISO 13485 et 21 CFR Part 11
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="">
        <TabsList>
          <TabsTrigger value="dashboard">Tableau de Bord</TabsTrigger>
          <TabsTrigger value="audit-trail">Journal d'Audit</TabsTrigger>
          <TabsTrigger value="reports">Rapports</TabsTrigger>
          <TabsTrigger value="legal">Documents Juridiques</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <ComplianceDashboard />
        </TabsContent>

        <TabsContent value="audit-trail">
          <AuditLogViewer />
        </TabsContent>

        <TabsContent value="reports">
          <ComplianceReportGenerator />
        </TabsContent>

        <TabsContent value="legal">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Documents Juridiques</h2>
              <p className="text-muted-foreground">
                Consultez les conditions générales d'utilisation et la politique de confidentialité
              </p>
            </div>

            <Tabs defaultValue="cgu" className="space-y-4">
              <TabsList>
                <TabsTrigger value="cgu">Conditions Générales d'Utilisation</TabsTrigger>
                <TabsTrigger value="privacy">Politique de Confidentialité</TabsTrigger>
              </TabsList>

              <TabsContent value="cgu">
                <LegalDocumentViewer documentType="terms_of_service" />
              </TabsContent>

              <TabsContent value="privacy">
                <LegalDocumentViewer documentType="privacy_policy" />
              </TabsContent>
            </Tabs>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
