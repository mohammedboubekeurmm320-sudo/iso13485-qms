import React, { useState } from 'react';
import { useChangeControl } from '@/contexts/ChangeControlContext';
import ChangeControlList from '@/components/change-control/ChangeControlList';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, FileText, AlertCircle, CheckCircle, Clock, Users, Calendar, Target, TrendingUp } from 'lucide-react';

interface ChangeControlPageProps {
  selectedId?: string;
  onBack?: () => void;
}

export default function ChangeControlPage({ selectedId, onBack }: ChangeControlPageProps) {
  const { changeControls, getChangeControl, updateStatus } = useChangeControl();
  const [selectedCCId, setSelectedCCId] = useState<string | null>(selectedId || null);

  const selectedCC = selectedCCId ? changeControls.find(cc => cc.id === selectedCCId) : null;

  const handleSelect = (id: string) => {
    setSelectedCCId(id);
  };

  const handleBack = () => {
    setSelectedCCId(null);
    onBack?.();
  };

  if (selectedCC) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h2 className="text-2xl font-bold">{selectedCC.title}</h2>
            <p className="text-gray-500">
              Change Control Request • {selectedCC.changeType}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{selectedCC.description || 'No description provided.'}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Justification</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{selectedCC.justification || 'No justification provided.'}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Impact Analysis</CardTitle>
                <CardDescription>Assessment of change impact on quality, regulatory, and operations</CardDescription>
              </CardHeader>
              <CardContent>
                {selectedCC.impactAnalysisCompleted ? (
                  <div className="space-y-2">
                    <p className="text-gray-700">{selectedCC.riskAssessmentSummary || 'Impact analysis completed.'}</p>
                    <p className="text-sm text-gray-500">Affected Systems: {selectedCC.affectedSystems || 'Not specified'}</p>
                  </div>
                ) : (
                  <div className="text-gray-500 italic">
                    Impact analysis has not been completed yet. Click "Start Impact Analysis" to begin.
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Implementation Plan</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedCC.implementationPlan && selectedCC.implementationPlan.length > 0 ? (
                  <div className="space-y-2">
                    {selectedCC.implementationPlan.map((task, index) => (
                      <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                        <input type="checkbox" checked={task.completed} readOnly />
                        <span className={task.completed ? 'line-through text-gray-400' : ''}>{task.task}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 italic">No implementation plan created yet.</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-gray-500">Current Status</label>
                  <p className="font-medium">{selectedCC.status.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Priority</label>
                  <p className="font-medium">{selectedCC.priority}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Created</label>
                  <p className="font-medium">{new Date(selectedCC.createdAt).toLocaleDateString()}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Workflow Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {selectedCC.status === 'DRAFT' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'IMPACT_ANALYSIS')}>
                    Start Impact Analysis
                  </Button>
                )}
                {selectedCC.status === 'IMPACT_ANALYSIS' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'PENDING_APPROVAL')}>
                    Submit for Approval
                  </Button>
                )}
                {selectedCC.status === 'PENDING_APPROVAL' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'APPROVED')}>
                    Approve Change
                  </Button>
                )}
                {selectedCC.status === 'APPROVED' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'IMPLEMENTATION')}>
                    Start Implementation
                  </Button>
                )}
                {selectedCC.status === 'IMPLEMENTATION' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'VERIFICATION')}>
                    Request Verification
                  </Button>
                )}
                {selectedCC.status === 'VERIFICATION' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedCC.id, 'CLOSED')}>
                    Close Change Control
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Change Control</h1>
        <p className="text-gray-500 mt-1">
          Manage changes to products, processes, and the quality management system in compliance with ISO 13485 §7.3.9
        </p>
      </div>

      <ChangeControlList onSelectChangeControl={handleSelect} />
    </div>
  );
}
