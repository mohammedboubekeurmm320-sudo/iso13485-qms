import React, { useState } from 'react';
import { useDeviation } from '@/contexts/DeviationContext';
import DeviationList from '@/components/deviation/DeviationList';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, AlertTriangle, CheckCircle, Clock, FileText, Target, TrendingUp } from 'lucide-react';

interface DeviationPageProps {
  selectedId?: string;
  onBack?: () => void;
}

export default function DeviationPage({ selectedId, onBack }: DeviationPageProps) {
  const { deviations, updateStatus, updateDeviation } = useDeviation();
  const [selectedDevId, setSelectedDevId] = useState<string | null>(selectedId || null);

  const selectedDev = selectedDevId ? deviations.find(d => d.id === selectedDevId) : null;

  const handleSelect = (id: string) => {
    setSelectedDevId(id);
  };

  const handleBack = () => {
    setSelectedDevId(null);
    onBack?.();
  };

  const getDispositionLabel = (disposition?: string) => {
    const labels: Record<string, string> = {
      'USE_AS_IS': 'Use As Is',
      'REWORK': 'Rework',
      'REPAIR': 'Repair',
      'SCRAP': 'Scrap',
      'RETURN_TO_VENDOR': 'Return to Vendor',
      'CONCESSION': 'Concession',
    };
    return disposition ? labels[disposition] || disposition : 'Not Determined';
  };

  if (selectedDev) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={handleBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h2 className="text-2xl font-bold">{selectedDev.title}</h2>
            <p className="text-gray-500 font-mono">{selectedDev.referenceNumber}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Event Description</CardTitle>
                <CardDescription>What happened and when</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-500">Description of Event</label>
                    <p className="text-gray-700">{selectedDev.descriptionOfEvent}</p>
                  </div>
                  <div>
                    <label className="text-sm text-gray-500">Occurrence Date</label>
                    <p className="text-gray-700">
                      {new Date(selectedDev.occurrenceDate).toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Immediate Action Taken</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">
                  {selectedDev.immediateActionTaken || 'No immediate action recorded.'}
                </p>
                {selectedDev.productQuarantined && (
                  <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded">
                    <div className="flex items-center gap-2 text-yellow-800">
                      <AlertTriangle className="h-4 w-4" />
                      <span className="font-medium">Product Quarantined</span>
                    </div>
                    {selectedDev.quarantineLotNumber && (
                      <p className="text-sm text-yellow-700 mt-1">
                        Lot Number: {selectedDev.quarantineLotNumber}
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Root Cause Analysis</CardTitle>
                <CardDescription>Investigation findings and contributing factors</CardDescription>
              </CardHeader>
              <CardContent>
                {selectedDev.rootCauseAnalysis ? (
                  <p className="text-gray-700">{selectedDev.rootCauseAnalysis}</p>
                ) : (
                  <div className="text-gray-500 italic">
                    Root cause analysis has not been completed. Use the actions panel to update.
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Impact Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDev.impactAssessment ? (
                  <p className="text-gray-700">{selectedDev.impactAssessment}</p>
                ) : (
                  <p className="text-gray-500 italic">Impact assessment not completed.</p>
                )}
              </CardContent>
            </Card>

            {selectedDev.disposition && (
              <Card>
                <CardHeader>
                  <CardTitle>Disposition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {getDispositionLabel(selectedDev.disposition)}
                      </Badge>
                    </div>
                    {selectedDev.dispositionJustification && (
                      <p className="text-gray-700">{selectedDev.dispositionJustification}</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm text-gray-500">Current Status</label>
                  <p className="font-medium">{selectedDev.status.replace(/_/g, ' ')}</p>
                </div>
                <div>
                  <label className="text-sm text-gray-500">Severity</label>
                  <p className="font-medium">
                    <Badge variant={
                      selectedDev.severity === 'CRITICAL' ? 'destructive' :
                      selectedDev.severity === 'MAJOR' ? 'default' : 'secondary'
                    }>
                      {selectedDev.severity}
                    </Badge>
                  </p>
                </div>
                {selectedDev.riskPriorityNumber && (
                  <div>
                    <label className="text-sm text-gray-500">Risk Priority Number</label>
                    <p className="font-medium">{selectedDev.riskPriorityNumber}</p>
                  </div>
                )}
                <div>
                  <label className="text-sm text-gray-500">Created</label>
                  <p className="font-medium">{new Date(selectedDev.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-sm text-gray-500">CAPA Required</label>
                  {selectedDev.capaRequired ? (
                    <Badge variant="destructive">Yes</Badge>
                  ) : (
                    <Badge variant="outline">No</Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Workflow Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {selectedDev.status === 'OPEN' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedDev.id, 'UNDER_INVESTIGATION')}>
                    Start Investigation
                  </Button>
                )}
                {selectedDev.status === 'UNDER_INVESTIGATION' && (
                  <>
                    <Button
                      className="w-full"
                      onClick={() => updateDeviation(selectedDev.id, { investigationCompleted: true })}
                    >
                      Complete Investigation
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => updateStatus(selectedDev.id, 'QA_REVIEW')}
                    >
                      Submit for QA Review
                    </Button>
                  </>
                )}
                {selectedDev.status === 'QA_REVIEW' && (
                  <Button className="w-full" onClick={() => updateStatus(selectedDev.id, 'PENDING_DISPOSITION')}>
                    Request Disposition
                  </Button>
                )}
                {selectedDev.status === 'PENDING_DISPOSITION' && (
                  <>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => updateDeviation(selectedDev.id, { disposition: 'USE_AS_IS' })}
                    >
                      Dispose: Use As Is
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => updateDeviation(selectedDev.id, { disposition: 'REWORK' })}
                    >
                      Dispose: Rework
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => updateDeviation(selectedDev.id, { disposition: 'SCRAP' })}
                    >
                      Dispose: Scrap
                    </Button>
                    <Button
                      className="w-full"
                      onClick={() => updateStatus(selectedDev.id, 'CLOSED')}
                    >
                      Close Deviation
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>

            {selectedDev.capaRequired && (
              <Card className="border-red-200">
                <CardHeader>
                  <CardTitle className="text-lg text-red-600">CAPA Required</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600">
                    This deviation requires a Corrective/Preventive Action. A CAPA can be linked once created.
                  </p>
                  <Button variant="destructive" size="sm" className="mt-2 w-full">
                    Create Linked CAPA
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Deviations</h1>
        <p className="text-gray-500 mt-1">
          Track and manage deviations from established procedures in compliance with ISO 13485 §8.3
        </p>
      </div>

      <DeviationList onSelectDeviation={handleSelect} />
    </div>
  );
}
