import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';

export interface Organization {
  id: string;
  name: string;
  slug: string;
  logo_url?: string;
  settings: Record<string, unknown>;
  subscription_status: string;
  subscription_plan: string;
  created_at: string;
}

export interface OrganizationMember {
  id: string;
  organization_id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  status: string;
  created_at: string;
}

export interface Invitation {
  id: string;
  email: string;
  organization_id: string;
  role: 'admin' | 'member' | 'viewer';
  token: string;
  status: string;
  expires_at: string;
  created_by: string;
  created_at: string;
}

interface OrganizationContextType {
  currentOrg: Organization | null;
  currentOrganization: Organization | null; // Alias for compatibility
  memberships: OrganizationMember[];
  isLoading: boolean;
  error: string | null;
  setCurrentOrg: (org: Organization | null) => Promise<void>;
  switchOrganization: (orgId: string) => Promise<void>;
  createOrganization: (name: string) => Promise<Organization>;
  updateOrganization: (updates: Partial<Organization>) => Promise<void>;
  inviteUser: (email: string, role: 'admin' | 'member' | 'viewer') => Promise<Invitation>;
  removeMember: (memberId: string) => Promise<void>;
  updateMemberRole: (memberId: string, role: string) => Promise<void>;
  refreshMemberships: () => Promise<void>;
}

const OrganizationContext = createContext<OrganizationContextType | undefined>(undefined);

export const OrganizationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [currentOrg, setCurrentOrgState] = useState<Organization | null>(null);
  const [memberships, setMemberships] = useState<OrganizationMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadMemberships = useCallback(async () => {
    if (!user) {
      setMemberships([]);
      setIsLoading(false);
      return;
    }

    try {
      const { data: members, error: membersError } = await supabase
        .from('organization_members')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'active');

      if (membersError) throw membersError;

      if (members && members.length > 0) {
        setMemberships(members as OrganizationMember[]);

        const savedOrgId = localStorage.getItem('currentOrgId');
        if (savedOrgId) {
          const savedOrg = members.find(m => m.organization_id === savedOrgId);
          if (savedOrg) {
            const { data: org } = await supabase
              .from('organizations')
              .select('*')
              .eq('id', savedOrg.organization_id)
              .single();
            if (org) {
              setCurrentOrgState(org as Organization);
              setIsLoading(false);
              return;
            }
          }
        }

        const firstMember = members[0];
        if (firstMember) {
          const { data: org } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', firstMember.organization_id)
            .single();
          if (org) {
            setCurrentOrgState(org as Organization);
            localStorage.setItem('currentOrgId', org.id);
          }
        }
      }
    } catch (err: any) {
      console.error('Error loading memberships:', err);
      setError(err.message);
      
      // Fallback for demo mode - create a default organization when no Supabase
      const demoOrg: Organization = {
        id: 'demo-org-001',
        name: 'Demo Medical Devices Inc.',
        slug: 'demo-medical',
        settings: {},
        subscription_status: 'active',
        subscription_plan: 'enterprise',
        created_at: new Date().toISOString(),
      };
      setCurrentOrgState(demoOrg);
      localStorage.setItem('currentOrgId', demoOrg.id);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadMemberships();
  }, [loadMemberships]);

  const setCurrentOrg = async (org: Organization | null) => {
    setCurrentOrgState(org);
    if (org) {
      localStorage.setItem('currentOrgId', org.id);
    } else {
      localStorage.removeItem('currentOrgId');
    }
  };

  const switchOrganization = async (orgId: string) => {
    setIsLoading(true);
    try {
      const { data: org, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', orgId)
        .single();

      if (error) throw error;
      if (org) {
        setCurrentOrgState(org as Organization);
        localStorage.setItem('currentOrgId', org.id);
      }
    } catch (err: any) {
      console.error('Error switching organization:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const createOrganization = async (name: string): Promise<Organization> => {
    if (!user) throw new Error('User not authenticated');

    const slug = name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '') 
      + '-' + Date.now().toString(36);

    const { data: org, error } = await supabase
      .from('organizations')
      .insert({
        name,
        slug,
        subscription_status: 'trial',
        subscription_plan: 'starter'
      })
      .select()
      .single();

    if (error) throw error;

    const { error: memberError } = await supabase
      .from('organization_members')
      .insert({
        organization_id: org.id,
        user_id: user.id,
        role: 'owner',
        status: 'active'
      });

    if (memberError) throw memberError;

    await loadMemberships();

    return org as Organization;
  };

  const updateOrganization = async (updates: Partial<Organization>) => {
    if (!currentOrg) throw new Error('No organization selected');

    const { error } = await supabase
      .from('organizations')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', currentOrg.id);

    if (error) throw error;

    const { data: org } = await supabase
      .from('organizations')
      .select('*')
      .eq('id', currentOrg.id)
      .single();

    if (org) {
      setCurrentOrgState(org as Organization);
    }
  };

  const inviteUser = async (email: string, role: 'admin' | 'member' | 'viewer'): Promise<Invitation> => {
    if (!currentOrg || !user) throw new Error('No organization selected or user not authenticated');

    const token = crypto.randomUUID();
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    const { data: invitation, error } = await supabase
      .from('invitations')
      .insert({
        email,
        organization_id: currentOrg.id,
        role,
        token,
        expires_at: expiresAt.toISOString(),
        created_by: user.id,
        status: 'pending'
      })
      .select()
      .single();

    if (error) throw error;

    return invitation as Invitation;
  };

  const removeMember = async (memberId: string) => {
    const { error } = await supabase
      .from('organization_members')
      .delete()
      .eq('id', memberId);

    if (error) throw error;
    await loadMemberships();
  };

  const updateMemberRole = async (memberId: string, role: string) => {
    const { error } = await supabase
      .from('organization_members')
      .update({ role, updated_at: new Date().toISOString() })
      .eq('id', memberId);

    if (error) throw error;
    await loadMemberships();
  };

  const refreshMemberships = async () => {
    await loadMemberships();
  };

  return (
    <OrganizationContext.Provider
      value={{
        currentOrg,
        currentOrganization: currentOrg, // Alias for compatibility
        memberships,
        isLoading,
        error,
        setCurrentOrg,
        switchOrganization,
        createOrganization,
        updateOrganization,
        inviteUser,
        removeMember,
        updateMemberRole,
        refreshMemberships
      }}
    >
      {children}
    </OrganizationContext.Provider>
  );
};

export const useOrganization = () => {
  const context = useContext(OrganizationContext);
  if (context === undefined) {
    throw new Error('useOrganization must be used within an OrganizationProvider');
  }
  return context;
};
