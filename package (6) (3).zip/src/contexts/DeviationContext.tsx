import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { Deviation, DeviationCategory, DeviationSeverity, DeviationDisposition, DeviationStatus } from '@/types/qms';

interface DeviationContextType {
  deviations: Deviation[];
  categories: DeviationCategory[];
  loading: boolean;
  error: string | null;
  fetchDeviations: () => Promise<void>;
  getDeviation: (id: string) => Promise<Deviation | null>;
  createDeviation: (data: Partial<Deviation>) => Promise<Deviation | null>;
  updateDeviation: (id: string, data: Partial<Deviation>) => Promise<void>;
  updateStatus: (id: string, status: DeviationStatus) => Promise<void>;
  deleteDeviation: (id: string) => Promise<void>;
  fetchCategories: () => Promise<void>;
  closeDeviation: (id: string) => Promise<void>;
}

const DeviationContext = createContext<DeviationContextType | undefined>(undefined);

export const useDeviation = () => {
  const context = useContext(DeviationContext);
  if (!context) {
    throw new Error('useDeviation must be used within a DeviationProvider');
  }
  return context;
};

export const DeviationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [deviations, setDeviations] = useState<Deviation[]>([]);
  const [categories, setCategories] = useState<DeviationCategory[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchDeviations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchError } = await supabase
        .from('deviations')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;

      const mapped = (data || []).map((row: any) => ({
        id: row.id,
        referenceNumber: row.reference_number,
        title: row.title,
        occurrenceDate: row.occurrence_date,
        identifiedById: row.identified_by_id,
        descriptionOfEvent: row.description_of_event,
        immediateActionTaken: row.immediate_action_taken,
        rootCauseAnalysis: row.root_cause_analysis,
        fiveWhys: row.five_whys || [],
        fishboneDiagram: row.fishbone_diagram || {},
        impactAssessment: row.impact_assessment,
        severity: row.severity as DeviationSeverity,
        detectability: row.detectability,
        riskPriorityNumber: row.risk_priority_number,
        disposition: row.disposition as DeviationDisposition,
        dispositionJustification: row.disposition_justification,
        dispositionApprovedBy: row.disposition_approved_by,
        dispositionApprovedAt: row.disposition_approved_at,
        capaRequired: row.capa_required || false,
        linkedCapaId: row.linked_capa_id,
        status: row.status as DeviationStatus,
        investigationCompleted: row.investigation_completed || false,
        productQuarantined: row.product_quarantined || false,
        quarantineLotNumber: row.quarantine_lot_number,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        closedAt: row.closed_at,
      }));

      setDeviations(mapped);
    } catch (err: any) {
      console.error('Error fetching deviations:', err);
      // Provide demo data if table doesn't exist
      setDeviations(getDemoDeviations());
    } finally {
      setLoading(false);
    }
  }, []);

  const getDeviation = useCallback(async (id: string): Promise<Deviation | null> => {
    try {
      const { data, error } = await supabase
        .from('deviations')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;

      return data ? {
        id: data.id,
        referenceNumber: data.reference_number,
        title: data.title,
        occurrenceDate: data.occurrence_date,
        identifiedById: data.identified_by_id,
        descriptionOfEvent: data.description_of_event,
        immediateActionTaken: data.immediate_action_taken,
        rootCauseAnalysis: data.root_cause_analysis,
        fiveWhys: data.five_whys || [],
        fishboneDiagram: data.fishbone_diagram || {},
        impactAssessment: data.impact_assessment,
        severity: data.severity,
        detectability: data.detectability,
        riskPriorityNumber: data.risk_priority_number,
        disposition: data.disposition,
        dispositionJustification: data.disposition_justification,
        dispositionApprovedBy: data.disposition_approved_by,
        dispositionApprovedAt: data.disposition_approved_at,
        capaRequired: data.capa_required || false,
        linkedCapaId: data.linked_capa_id,
        status: data.status,
        investigationCompleted: data.investigation_completed || false,
        productQuarantined: data.product_quarantined || false,
        quarantineLotNumber: data.quarantine_lot_number,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
        closedAt: data.closed_at,
      } : null;
    } catch (err) {
      console.error('Error fetching deviation:', err);
      return getDemoDeviations().find(d => d.id === id) || null;
    }
  }, []);

  const createDeviation = useCallback(async (data: Partial<Deviation>): Promise<Deviation | null> => {
    try {
      const referenceNumber = `DEV-${new Date().getFullYear()}-${String(Date.now()).slice(-4)}`;

      const { data: result, error } = await supabase
        .from('deviations')
        .insert({
          reference_number: referenceNumber,
          title: data.title,
          occurrence_date: data.occurrenceDate || new Date().toISOString(),
          identified_by_id: user?.id,
          description_of_event: data.descriptionOfEvent,
          immediate_action_taken: data.immediateActionTaken,
          root_cause_analysis: data.rootCauseAnalysis,
          five_whys: data.fiveWhys || [],
          fishbone_diagram: data.fishboneDiagram || {},
          impact_assessment: data.impactAssessment,
          severity: data.severity || 'MINOR',
          detectability: data.detectability,
          risk_priority_number: data.riskPriorityNumber,
          disposition: data.disposition,
          disposition_justification: data.dispositionJustification,
          capa_required: data.capaRequired || false,
          status: 'OPEN',
          investigation_completed: false,
          product_quarantined: data.productQuarantined || false,
          quarantine_lot_number: data.quarantineLotNumber,
        })
        .select()
        .single();

      if (error) throw error;

      await fetchDeviations();
      return result ? {
        id: result.id,
        referenceNumber: result.reference_number,
        title: result.title,
        occurrenceDate: result.occurrence_date,
        identifiedById: result.identified_by_id,
        descriptionOfEvent: result.description_of_event,
        severity: result.severity,
        status: result.status,
        capaRequired: result.capa_required || false,
        investigationCompleted: false,
        productQuarantined: result.product_quarantined || false,
        createdAt: result.created_at,
      } : null;
    } catch (err) {
      console.error('Error creating deviation:', err);
      // Return demo data
      const newDemo: Deviation = {
        id: `demo-dev-${Date.now()}`,
        referenceNumber: `DEV-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999)).padStart(4, '0')}`,
        title: data.title || 'New Deviation',
        occurrenceDate: data.occurrenceDate || new Date().toISOString(),
        identifiedById: user?.id,
        descriptionOfEvent: data.descriptionOfEvent || '',
        severity: data.severity || 'MINOR',
        status: 'OPEN',
        capaRequired: data.capaRequired || false,
        investigationCompleted: false,
        productQuarantined: data.productQuarantined || false,
        createdAt: new Date().toISOString(),
      };
      setDeviations(prev => [newDemo, ...prev]);
      return newDemo;
    }
  }, [user, fetchDeviations]);

  const updateDeviation = useCallback(async (id: string, data: Partial<Deviation>) => {
    try {
      const updateObj: any = {};
      if (data.title !== undefined) updateObj.title = data.title;
      if (data.descriptionOfEvent !== undefined) updateObj.description_of_event = data.descriptionOfEvent;
      if (data.immediateActionTaken !== undefined) updateObj.immediate_action_taken = data.immediateActionTaken;
      if (data.rootCauseAnalysis !== undefined) updateObj.root_cause_analysis = data.rootCauseAnalysis;
      if (data.fiveWhys !== undefined) updateObj.five_whys = data.fiveWhys;
      if (data.fishboneDiagram !== undefined) updateObj.fishbone_diagram = data.fishboneDiagram;
      if (data.impactAssessment !== undefined) updateObj.impact_assessment = data.impactAssessment;
      if (data.severity !== undefined) updateObj.severity = data.severity;
      if (data.detectability !== undefined) updateObj.detectability = data.detectability;
      if (data.riskPriorityNumber !== undefined) updateObj.risk_priority_number = data.riskPriorityNumber;
      if (data.disposition !== undefined) updateObj.disposition = data.disposition;
      if (data.dispositionJustification !== undefined) updateObj.disposition_justification = data.dispositionJustification;
      if (data.capaRequired !== undefined) updateObj.capa_required = data.capaRequired;
      if (data.status !== undefined) updateObj.status = data.status;
      if (data.investigationCompleted !== undefined) updateObj.investigation_completed = data.investigationCompleted;
      if (data.productQuarantined !== undefined) updateObj.product_quarantined = data.productQuarantined;
      if (data.quarantineLotNumber !== undefined) updateObj.quarantine_lot_number = data.quarantineLotNumber;

      updateObj.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('deviations')
        .update(updateObj)
        .eq('id', id);

      if (error) throw error;
      await fetchDeviations();
    } catch (err) {
      console.error('Error updating deviation:', err);
    }
  }, [fetchDeviations]);

  const updateStatus = useCallback(async (id: string, status: DeviationStatus) => {
    await updateDeviation(id, { status });
  }, [updateDeviation]);

  const deleteDeviation = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('deviations')
        .delete()
        .eq('id', id);

      if (error) throw error;
      await fetchDeviations();
    } catch (err) {
      console.error('Error deleting deviation:', err);
    }
  }, [fetchDeviations]);

  const fetchCategories = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('deviation_categories')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;

      setCategories((data || []).map((row: any) => ({
        id: row.id,
        name: row.name,
        description: row.description,
        isActive: row.is_active,
      })));
    } catch (err) {
      console.error('Error fetching categories:', err);
      setCategories(getDemoCategories());
    }
  }, []);

  const closeDeviation = useCallback(async (id: string) => {
    await updateDeviation(id, {
      status: 'CLOSED',
      closedAt: new Date().toISOString(),
    });
  }, [updateDeviation]);

  useEffect(() => {
    fetchDeviations();
    fetchCategories();
  }, [fetchDeviations, fetchCategories]);

  return (
    <DeviationContext.Provider
      value={{
        deviations,
        categories,
        loading,
        error,
        fetchDeviations,
        getDeviation,
        createDeviation,
        updateDeviation,
        updateStatus,
        deleteDeviation,
        fetchCategories,
        closeDeviation,
      }}
    >
      {children}
    </DeviationContext.Provider>
  );
};

// Demo data for when database is not available
function getDemoDeviations(): Deviation[] {
  return [
    {
      id: 'demo-dev-1',
      referenceNumber: 'DEV-2024-0001',
      title: 'Temperature Excursion in Storage',
      occurrenceDate: '2024-01-18T14:30:00Z',
      identifiedById: 'user-1',
      descriptionOfEvent: 'Temperature in cold storage exceeded 8°C for 2 hours during weekend',
      immediateActionTaken: 'Product quarantined, temperature log reviewed',
      rootCauseAnalysis: 'HVAC system malfunction due to dirty filter',
      impactAssessment: 'Product quality may be affected - requires investigation',
      severity: 'MAJOR',
      detectability: 'MEDIUM',
      riskPriorityNumber: 12,
      disposition: 'PENDING_DISPOSITION',
      dispositionJustification: '',
      capaRequired: true,
      status: 'UNDER_INVESTIGATION',
      investigationCompleted: false,
      productQuarantined: true,
      quarantineLotNumber: 'LOT-2024-0156',
      createdAt: '2024-01-18T15:00:00Z',
      updatedAt: '2024-01-19T10:00:00Z',
    },
    {
      id: 'demo-dev-2',
      referenceNumber: 'DEV-2024-0002',
      title: 'Wrong Label Applied to Product',
      occurrenceDate: '2024-01-17T09:15:00Z',
      identifiedById: 'user-2',
      descriptionOfEvent: 'Product labeled with incorrect catalog number',
      immediateActionTaken: 'Affected units segregated immediately',
      rootCauseAnalysis: 'Label printer - wrong template loaded',
      impactAssessment: 'Customer received wrong misconfigured product - recall not required as identified before shipment',
      severity: 'CRITICAL',
      detectability: 'HIGH',
      riskPriorityNumber: 15,
      disposition: 'REWORK',
      dispositionJustification: 'Labels can be removed and reapplied correctly',
      dispositionApprovedBy: 'user-1',
      dispositionApprovedAt: '2024-01-18T11:00:00Z',
      capaRequired: true,
      status: 'CLOSED',
      investigationCompleted: true,
      productQuarantined: false,
      createdAt: '2024-01-17T10:00:00Z',
      updatedAt: '2024-01-18T11:00:00Z',
      closedAt: '2024-01-18T11:00:00Z',
    },
    {
      id: 'demo-dev-3',
      referenceNumber: 'DEV-2024-0003',
      title: 'Testing Procedure Deviation',
      occurrenceDate: '2024-01-20T11:00:00Z',
      identifiedById: 'user-3',
      descriptionOfEvent: 'Test performed at room temperature instead of required 25°C',
      immediateActionTaken: 'Test repeated at correct temperature',
      severity: 'MINOR',
      detectability: 'HIGH',
      riskPriorityNumber: 4,
      disposition: 'USE_AS_IS',
      dispositionJustification: 'Results verified within specification at correct temperature',
      capaRequired: false,
      status: 'CLOSED',
      investigationCompleted: true,
      productQuarantined: false,
      createdAt: '2024-01-20T12:00:00Z',
      updatedAt: '2024-01-20T14:00:00Z',
      closedAt: '2024-01-20T14:00:00Z',
    },
  ];
}

function getDemoCategories(): DeviationCategory[] {
  return [
    { id: 'cat-1', name: 'Process Deviation', description: 'Departure from approved process parameters', isActive: true },
    { id: 'cat-2', name: 'Documentation Error', description: 'Error or omission in controlled documents', isActive: true },
    { id: 'cat-3', name: 'Equipment Malfunction', description: 'Failure or deviation of equipment', isActive: true },
    { id: 'cat-4', name: 'Material Defect', description: 'Non-conforming material or component', isActive: true },
    { id: 'cat-5', name: 'Testing Deviation', description: 'Departure from approved test methods', isActive: true },
    { id: 'cat-6', name: 'Software Deviation', description: 'Departure from validated software', isActive: true },
    { id: 'cat-7', name: 'Labeling Error', description: 'Error in product labeling', isActive: true },
    { id: 'cat-8', name: 'Other', description: 'Other types of deviations', isActive: true },
  ];
}
