# Non-Conformances Module

## Overview

This module handles non-conformances per ISO 13485 Section 8.3 requirements.

## Services

### ncrService.ts

Main service for non-conformance management.

#### Methods

- `getAll(filters?)` - Retrieve all NCRs
- `getById(id)` - Get a single NCR
- `create(input, userId)` - Create a new NCR
- `update(id, input, userId)` - Update NCR
- `getStats()` - Get NCR statistics

## Hooks

### useNonConformances

React Query hook for NCR list management.

```typescript
const { data } = useNonConformances({ severity: 'Critical' });
```

## Types

```typescript
interface NonConformance {
  id: string;
  ncrNumber: string;
  title: string;
  description?: string;
  type: 'Product' | 'Process' | 'System';
  severity: 'Critical' | 'Major' | 'Minor';
  status: 'Open' | 'Under Review' | 'Closed';
  source: string;
  department: string;
  identifiedBy: string;
  identifiedDate: string;
  disposition?: string;
}
```

## Compliance

- ISO 13485:2016 Section 8.3 - Control of nonconforming product
