// React Query Hooks pour les Non-Conformances

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ncrService, NCRFilters } from '../services/ncrService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

export const ncrKeys = {
  all: ['ncr'] as const,
  lists: () => [...ncrKeys.all, 'list'] as const,
  list: (filters: NCRFilters) => [...ncrKeys.lists(), filters] as const,
  details: () => [...ncrKeys.all, 'detail'] as const,
  detail: (id: string) => [...ncrKeys.details(), id] as const,
  stats: () => [...ncrKeys.all, 'stats'] as const,
};

export const useNonConformances = (filters?: NCRFilters) => {
  return useQuery({
    queryKey: ncrKeys.list(filters || {}),
    queryFn: () => ncrService.getAll(filters),
    staleTime: 5 * 60 * 1000,
  });
};

export const useNonConformance = (id: string) => {
  return useQuery({
    queryKey: ncrKeys.detail(id),
    queryFn: () => ncrService.getById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
};

export const useNCRStats = () => {
  return useQuery({
    queryKey: ncrKeys.stats(),
    queryFn: () => ncrService.getStats(),
    staleTime: 60 * 1000,
  });
};

export const useCreateNCR = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      input,
      userId,
    }: {
      input: {
        title: string;
        description: string;
        type?: string;
        severity?: string;
        source?: string;
        sourceDescription?: string;
        detectedDate?: string;
        detectedBy?: string;
        lotNumber?: string;
        quantityAffected?: number;
        totalQuantity?: number;
        productName?: string;
        partNumber?: string;
        immediateAction?: string;
        assignedTo?: string;
        department?: string;
        dueDate?: string;
      };
      userId: string;
    }) => ncrService.create(input, userId),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ncrKeys.all });
      toast.success('Non-conformance created', {
        description: `NCR ${data.ncrNumber} has been created`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create NCR');
    },
  });
};

export const useUpdateNCR = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      input,
      userId,
    }: {
      id: string;
      input: {
        title?: string;
        description?: string;
        status?: string;
        severity?: string;
        rootCause?: string;
        correctiveAction?: string;
        preventiveAction?: string;
        assignedTo?: string;
      };
      userId: string;
    }) => ncrService.update(id, input, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ncrKeys.all });
      toast.success('Non-conformance updated');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update NCR');
    },
  });
};

export const useCloseNCR = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      userId,
    }: {
      id: string;
      userId: string;
    }) => ncrService.close(id, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ncrKeys.all });
      toast.success('Non-conformance closed');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to close NCR');
    },
  });
};

export default {
  useNonConformances,
  useNonConformance,
  useNCRStats,
  useCreateNCR,
  useUpdateNCR,
  useCloseNCR,
};
