# CAPA Module

## Overview

This module handles Corrective and Preventive Actions (CAPA) per ISO 13485 Section 8.5 requirements.

## Services

### capaService.ts

Main service for CAPA management.

#### Methods

- `getAll(filters?: CAPAFilters)` - Retrieve all CAPAs with optional filtering
- `getById(id: string)` - Get a single CAPA by ID
- `create(input, userId)` - Create a new CAPA
- `update(id, input, userId)` - Update an existing CAPA
- `delete(id, userId)` - Delete a CAPA
- `close(id, userId)` - Close a CAPA
- `getStats()` - Get CAPA statistics

## Hooks

### useCAPAs

React Query hook for CAPA list management.

```typescript
const { data, isLoading, error } = useCAPAs({ status: 'Open' });
```

### useCreateCAPA

Hook for creating new CAPAs with automatic audit logging.

### useUpdateCAPA

Hook for updating CAPAs with optimistic updates.

## Types

```typescript
interface CAPA {
  id: string;
  capaNumber: string;
  title: string;
  description?: string;
  type: 'Corrective' | 'Preventive';
  status: 'Open' | 'Investigation' | 'Implementation' | 'Verification' | 'Closed';
  priority: 'Critical' | 'High' | 'Medium' | 'Low';
  source: string;
  assignedTo: string;
  dueDate: string;
  effectiveness?: 'Effective' | 'Ineffective' | 'Pending';
  rootCause?: string;
  correctiveAction?: string;
  preventiveAction?: string;
}
```

## Workflow

```
Open → Investigation → Implementation → Verification → Closed
```

## Compliance

- ISO 13485:2016 Section 8.5 - Improvement
- FDA 21 CFR 820.100 - Corrective and preventive action
