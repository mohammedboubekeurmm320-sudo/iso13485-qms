// Legal Document Service - Service pour les documents légaux/réglementaires
// Conforme aux exigences de gestion documentaire ISO 13485

import { supabase } from '@/lib/supabase';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';

// Demo store for offline mode
const demoLegalDocuments: LegalDocument[] = [
  {
    id: 'demo-legal-1',
    type: 'Policy',
    version: '1.0',
    title: 'Politique Qualité',
    content: 'La direction s\'engage à maintenir un système de management de la qualité conforme aux exigences ISO 13485:2016...',
    is_active: true,
    effective_date: '2024-01-01',
    created_at: '2024-01-01T10:00:00Z',
    updated_at: '2024-01-01T10:00:00Z',
  },
  {
    id: 'demo-legal-2',
    type: 'Procedure',
    version: '2.0',
    title: 'Procédure de gestion des non-conformités',
    content: 'Cette procédure définit le processus de gestion des non-conformités selon ISO 13485 Section 8.3...',
    is_active: true,
    effective_date: '2024-01-15',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
  },
  {
    id: 'demo-legal-3',
    type: 'Regulation',
    version: '1.0',
    title: 'Règlement intérieur',
    content: 'Le présent règlement intérieur définit les règles de fonctionnement de l\'entreprise...',
    is_active: true,
    effective_date: '2023-06-01',
    created_at: '2023-06-01T10:00:00Z',
    updated_at: '2023-06-01T10:00:00Z',
  },
];

export interface LegalDocument {
  id: string;
  type: string;
  version: string;
  title: string;
  content: string;
  is_active: boolean;
  effective_date: string;
  created_at: string;
  updated_at?: string;
}

export interface LegalDocumentFilters {
  type?: string;
  isActive?: boolean;
  version?: string;
}

// Service de gestion des documents légaux
export const legalDocumentService = {
  // Récupérer tous les documents légaux
  async getDocuments(documentType: string): Promise<LegalDocument[]> {
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('type', documentType)
        .order('created_at', { ascending: false });

      if (error) throw handleSupabaseError(error, 'fetch legal documents');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo legal documents');
      return demoLegalDocuments.filter(d => d.type === documentType)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    }
  },

  // Récupérer un document par ID
  async getDocumentById(documentId: string): Promise<LegalDocument | null> {
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('id', documentId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw handleSupabaseError(error, 'fetch legal document');
      }

      return data;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo legal document');
      return demoLegalDocuments.find(d => d.id === documentId) || null;
    }
  },

  // Récupérer un document par type et version
  async getDocumentByVersion(documentType: string, version: string): Promise<LegalDocument | null> {
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .select('*')
        .eq('type', documentType)
        .eq('version', version)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw handleSupabaseError(error, 'fetch legal document by version');
      }

      return data;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo legal document by version');
      return demoLegalDocuments.find(d => d.type === documentType && d.version === version) || null;
    }
  },

  // Créer un nouveau document légal
  async createDocument(documentData: Partial<LegalDocument>): Promise<LegalDocument> {
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .insert({
          type: documentData.type,
          version: documentData.version,
          title: documentData.title,
          content: documentData.content,
          is_active: documentData.is_active || false,
          effective_date: documentData.effective_date,
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create legal document');

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create legal document', { originalError: error as Error });
    }
  },

  // Mettre à jour un document légal
  async updateDocument(documentId: string, documentData: Partial<LegalDocument>): Promise<LegalDocument> {
    try {
      const { data, error } = await supabase
        .from('legal_documents')
        .update({
          title: documentData.title,
          content: documentData.content,
          is_active: documentData.is_active,
          effective_date: documentData.effective_date,
          updated_at: new Date().toISOString(),
        })
        .eq('id', documentId)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update legal document');

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update legal document', { originalError: error as Error });
    }
  },
};

export default legalDocumentService;
