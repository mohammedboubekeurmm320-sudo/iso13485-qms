# Risks Module

## Overview

This module handles risk management per ISO 14971 and ISO 13485 Section 7.1 requirements.

## Services

### riskService.ts

Main service for risk management.

#### Methods

- `getAll(filters?)` - Retrieve all risks
- `getById(id)` - Get a single risk
- `create(input, userId)` - Create a new risk
- `update(id, input, userId)` - Update risk
- `delete(id, userId)` - Delete a risk
- `getStats()` - Get risk statistics

## Hooks

### useRisks

React Query hook for risk list management.

```typescript
const { data } = useRisks({ status: 'Open' });
```

## Risk Assessment

The module uses a Risk Priority Number (RPN) calculation:

```
RPN = Severity × Probability × Detectability
```

Where each factor is rated 1-5:

- **Severity (S)**: Impact on product quality or patient safety
- **Probability (P)**: Likelihood of occurrence
- **Detectability (D)**: Ability to detect the issue

Risk Levels:
- **High**: RPN ≥ 16 (requires immediate action)
- **Medium**: RPN 8-15 (requires mitigation plan)
- **Low**: RPN < 8 (monitor regularly)

## Types

```typescript
interface Risk {
  id: string;
  riskNumber: string;
  title: string;
  description: string;
  category: 'Operational' | 'Regulatory' | 'Financial' | 'Strategic';
  severity: number; // 1-5
  probability: number; // 1-5
  detectability: number; // 1-5
  riskLevel: 'High' | 'Medium' | 'Low';
  status: 'Open' | 'Mitigated' | 'Closed';
  mitigationPlan?: string;
  residualRisk?: number;
}
```

## Compliance

- ISO 14971:2019 - Medical devices risk management
- ISO 13485:2016 Section 7.1 - Planning of product realization
