// React Query Hooks pour les Risques

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { riskService, RiskFilters, CreateRiskInput } from '../services/riskService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

export const riskKeys = {
  all: ['risks'] as const,
  lists: () => [...riskKeys.all, 'list'] as const,
  list: (filters: RiskFilters) => [...riskKeys.lists(), filters] as const,
  details: () => [...riskKeys.all, 'detail'] as const,
  detail: (id: string) => [...riskKeys.details(), id] as const,
  stats: () => [...riskKeys.all, 'stats'] as const,
  critical: () => [...riskKeys.all, 'critical'] as const,
};

export const useRisks = (filters?: RiskFilters) => {
  return useQuery({
    queryKey: riskKeys.list(filters || {}),
    queryFn: () => riskService.getAll(filters),
    staleTime: 5 * 60 * 1000,
  });
};

export const useRisk = (id: string) => {
  return useQuery({
    queryKey: riskKeys.detail(id),
    queryFn: () => riskService.getById(id),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });
};

export const useRiskStats = () => {
  return useQuery({
    queryKey: riskKeys.stats(),
    queryFn: () => riskService.getStats(),
    staleTime: 60 * 1000,
  });
};

export const useCriticalRisks = () => {
  return useQuery({
    queryKey: riskKeys.critical(),
    queryFn: () => riskService.getCriticalRisks(),
    staleTime: 60 * 1000,
  });
};

export const useCreateRisk = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      input,
      userId,
    }: {
      input: CreateRiskInput;
      userId: string;
    }) => riskService.create(input, userId),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: riskKeys.all });
      toast.success('Risk created successfully', {
        description: `Risk ${data.riskId} - RPN: ${data.initialRPN}`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create risk');
    },
  });
};

export const useUpdateRisk = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      input,
      userId,
    }: {
      id: string;
      input: {
        title?: string;
        description?: string;
        severity?: number;
        probability?: number;
        detectability?: number;
        status?: string;
        mitigation?: string;
        residualRisk?: number;
      };
      userId: string;
    }) => riskService.update(id, input, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: riskKeys.all });
      toast.success('Risk updated successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update risk');
    },
  });
};

export const useCloseRisk = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      userId,
    }: {
      id: string;
      userId: string;
    }) => riskService.close(id, userId),

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: riskKeys.all });
      toast.success('Risk closed successfully');
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to close risk');
    },
  });
};

export default {
  useRisks,
  useRisk,
  useRiskStats,
  useCriticalRisks,
  useCreateRisk,
  useUpdateRisk,
  useCloseRisk,
};
