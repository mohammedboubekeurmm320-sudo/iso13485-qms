// Risk Service - Service pour la gestion des risques
// Conforme ISO 14971 & ISO 13485 Section 7.1

import { supabase } from '@/lib/supabase';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';
import { auditApi } from '../../documents/services/auditService';

// Demo store for offline mode
const demoRisks: Risk[] = [
  {
    id: 'demo-risk-1',
    riskNumber: 'RISK-2024-0001',
    title: 'Risque de contamination croisée',
    description: 'Potentiel risque de contamination croisée lors de la production de dispositifs médicaux',
    severity: 4,
    probability: 3,
    detectability: 2,
    rpn: 24,
    status: 'Open',
    mitigation: 'Mise en place de procédures de nettoyage renforcées',
    residualRisk: 12,
    createdBy: 'demo-user-1',
    createdAt: '2024-01-15T10:00:00Z',
    updatedAt: '2024-01-15T10:00:00Z',
    category: 'Manufacturing',
    hazard: 'Contamination biologique',
    harm: 'Infection patient',
    harmSeverity: 5,
    harmSeverityClassification: 'Critical',
    mitigationMeasures: 'Validation des procédures de nettoyage',
    owner: 'Responsable Production',
  },
  {
    id: 'demo-risk-2',
    riskNumber: 'RISK-2024-0002',
    title: 'Défaut de stérilisation',
    description: 'Risque de défaut dans le processus de stérilisation des implants',
    severity: 5,
    probability: 2,
    detectability: 3,
    rpn: 30,
    status: 'Mitigation',
    mitigation: 'Installation de监控系统 supplémentaire',
    residualRisk: 15,
    createdBy: 'demo-user-1',
    createdAt: '2024-02-01T10:00:00Z',
    updatedAt: '2024-02-10T10:00:00Z',
    category: 'Manufacturing',
    hazard: 'Stérilisation inadéquate',
    harm: 'Infection grave',
    harmSeverity: 5,
    harmSeverityClassification: 'Catastrophic',
    mitigationMeasures: 'Double contrôle du process',
    owner: 'Responsable Qualité',
  },
  {
    id: 'demo-risk-3',
    riskNumber: 'RISK-2024-0003',
    title: 'Erreur de dosage médicament',
    description: 'Risque d\'erreur de dosage dans les dispositifs d\'administration',
    severity: 4,
    probability: 1,
    detectability: 4,
    rpn: 16,
    status: 'Closed',
    mitigation: 'Vérification systématique par second opérateur',
    residualRisk: 4,
    createdBy: 'demo-user-2',
    createdAt: '2024-01-20T10:00:00Z',
    updatedAt: '2024-03-01T10:00:00Z',
    category: 'Design',
    hazard: 'Dosage incorrect',
    harm: 'Surdose ou sous-dose',
    harmSeverity: 4,
    harmSeverityClassification: 'Serious',
    mitigationMeasures: 'Double vérification',
    owner: 'Responsable R&D',
  },
];

export interface Risk {
  id: string;
  riskNumber: string;
  title: string;
  description: string;
  severity: number; // 1-5
  probability: number; // 1-5
  detectability: number; // 1-5
  rpn: number; // Risk Priority Number (severity * probability * detectability)
  status: 'Open' | 'Mitigation' | 'Closed';
  mitigation: string;
  residualRisk: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface RiskFilters {
  status?: string;
  severity?: string;
  search?: string;
}

export interface CreateRiskInput {
  // ISO 14971 - Risk Identification
  title: string;
  description: string;
  
  // Product Information
  deviceName?: string;
  deviceClass?: 'Class I' | 'Class IIa' | 'Class IIb' | 'Class III';
  intendedUse?: string;
  intendedUser?: string;
  useEnvironment?: string;
  
  // Hazard Identification - ISO 14971:2019 Clause 5.3
  hazardIdentification?: string;
  hazard: string;
  hazardousSituation?: string;
  harm: string;
  harmSeverity?: number;
  harmSeverityClassification?: 'Negligible' | 'Minor' | 'Serious' | 'Critical' | 'Catastrophic';
  
  // Risk Estimation - ISO 14971:2019 Clause 5.4
  severity: number;
  probability: number;
  detectability: number;
  
  // Category
  category: 'Design' | 'Manufacturing' | 'Use/Misuse' | 'Environmental' | 'Regulatory' | 'Software' | 'Biological' | 'Supplier';
  
  // Risk Evaluation
  riskAcceptabilityCriteria?: string;
  riskBenefitAnalysis?: string;
  
  // Risk Control - ISO 14971:2019 Clause 7
  mitigationMeasures: string;
  riskControlMeasures?: string[];
  riskControlOption?: 'Inherently Safe Design' | 'Protective Measure' | 'Information for Safety';
  
  // Residual Risk
  residualSeverity?: number;
  residualProbability?: number;
  residualDetectability?: number;
  
  // Risk Review and Monitoring
  owner: string;
  reviewFrequency?: string;
  dueDate?: string;
  
  // FMEA specific
  failureMode?: string;
  failureEffect?: string;
  failureCause?: string;
  detectionMethod?: string;
  
  // Links
  linkedCAPAId?: string;
  linkedDeviationId?: string;
  linkedDocumentId?: string;
}

export interface UpdateRiskInput {
  title?: string;
  description?: string;
  severity?: number;
  probability?: number;
  detectability?: number;
  status?: string;
  mitigation?: string;
  residualRisk?: number;
}

// Calculer le RPN (Risk Priority Number)
const calculateRPN = (severity: number, probability: number, detectability: number): number => {
  return severity * probability * detectability;
};

// Déterminer le niveau de risque basé sur le RPN
const getRiskLevel = (rpn: number): string => {
  if (rpn >= 100) return 'Critical';
  if (rpn >= 50) return 'High';
  if (rpn >= 20) return 'Medium';
  return 'Low';
};

export const riskService = {
  async getAll(filters?: RiskFilters): Promise<Risk[]> {
    try {
      let query = supabase
        .from('risks')
        .select('*')
        .order('rpn', { ascending: false });

      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }
      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,risk_number.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch risks');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo risks data');
      let filtered = [...demoRisks];
      if (filters?.status && filters.status !== 'all') {
        filtered = filtered.filter(r => r.status === filters.status);
      }
      if (filters?.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(r => 
          r.title.toLowerCase().includes(search) || 
          r.riskNumber.toLowerCase().includes(search)
        );
      }
      return filtered.sort((a, b) => b.rpn - a.rpn);
    }
  },

  async getById(id: string): Promise<Risk | null> {
    try {
      const { data, error } = await supabase
        .from('risks')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw handleSupabaseError(error, 'fetch risk');

      return data;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo risk data');
      return demoRisks.find(r => r.id === id) || null;
    }
  },

  async create(input: CreateRiskInput, userId: string): Promise<Risk> {
    try {
      const riskNumber = await generateRiskNumber();
      const rpn = calculateRPN(input.severity, input.probability, input.detectability);
      const riskLevel = getRiskLevel(rpn);

      const { data, error } = await supabase
        .from('risks')
        .insert({
          // Risk Identification
          risk_number: riskNumber,
          title: input.title,
          description: input.description,
          
          // Product Information
          device_name: input.deviceName,
          device_class: input.deviceClass,
          intended_use: input.intendedUse,
          intended_user: input.intendedUser,
          use_environment: input.useEnvironment,
          
          // Hazard Identification
          hazard_identification: input.hazardIdentification,
          hazard: input.hazard,
          hazardous_situation: input.hazardousSituation,
          harm: input.harm,
          harm_severity: input.harmSeverity,
          harm_severity_classification: input.harmSeverityClassification,
          
          // Risk Estimation
          severity: input.severity,
          probability: input.probability,
          detectability: input.detectability,
          initial_rpn: rpn,
          risk_level: riskLevel,
          
          // Category
          category: input.category,
          
          // Risk Evaluation
          risk_acceptability_criteria: input.riskAcceptabilityCriteria,
          risk_benefit_analysis: input.riskBenefitAnalysis,
          
          // Risk Control
          mitigation_measures: input.mitigationMeasures,
          risk_control_measures: input.riskControlMeasures,
          risk_control_option: input.riskControlOption,
          
          // Residual Risk (initial = RPN before mitigation)
          residual_severity: input.residualSeverity || input.severity,
          residual_probability: input.residualProbability || input.probability,
          residual_detectability: input.residualDetectability || input.detectability,
          residual_rpn: rpn,
          residual_risk_level: riskLevel,
          
          // Status
          status: 'Open',
          
          // Owner
          owner: input.owner,
          review_frequency: input.reviewFrequency,
          due_date: input.dueDate,
          
          // FMEA
          failure_mode: input.failureMode,
          failure_effect: input.failureEffect,
          failure_cause: input.failureCause,
          detection_method: input.detectionMethod,
          
          // Links
          linked_capa_id: input.linkedCAPAId,
          linked_deviation_id: input.linkedDeviationId,
          linked_document_id: input.linkedDocumentId,
          
          created_by: userId,
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create risk');

      await auditApi.logAudit({
        action: 'CREATE',
        tableName: 'risks',
        recordId: data.id,
        userId,
        newValues: data,
      });

      return mapToRisk(data);
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create risk', { originalError: error as Error });
    }
  },

  async update(id: string, input: UpdateRiskInput, userId: string): Promise<Risk> {
    try {
      const oldRisk = await this.getById(id);

      // Recalculer RPN si les paramètres changent
      const severity = input.severity ?? oldRisk!.severity;
      const probability = input.probability ?? oldRisk!.probability;
      const detectability = input.detectability ?? oldRisk!.detectability;
      const rpn = calculateRPN(severity, probability, detectability);

      const { data, error } = await supabase
        .from('risks')
        .update({
          ...input,
          rpn,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update risk');

      await auditApi.logAudit({
        action: 'UPDATE',
        tableName: 'risks',
        recordId: id,
        userId,
        oldValues: oldRisk,
        newValues: data,
      });

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update risk', { originalError: error as Error });
    }
  },

  async close(id: string, userId: string): Promise<Risk> {
    return this.update(id, {
      status: 'Closed',
    }, userId);
  },

  async getStats(): Promise<{
    total: number;
    critical: number;
    high: number;
    medium: number;
    low: number;
    open: number;
    mitigation: number;
    closed: number;
  }> {
    try {
      const { data, error } = await supabase
        .from('risks')
        .select('rpn, status');

      if (error) throw handleSupabaseError(error, 'fetch risk stats');

      const risks = data || [];
      return {
        total: risks.length,
        critical: risks.filter(r => r.rpn >= 100).length,
        high: risks.filter(r => r.rpn >= 50 && r.rpn < 100).length,
        medium: risks.filter(r => r.rpn >= 20 && r.rpn < 50).length,
        low: risks.filter(r => r.rpn < 20).length,
        open: risks.filter(r => r.status === 'Open').length,
        mitigation: risks.filter(r => r.status === 'Mitigation').length,
        closed: risks.filter(r => r.status === 'Closed').length,
      };
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo risk stats');
      return {
        total: demoRisks.length,
        critical: demoRisks.filter(r => r.rpn >= 100).length,
        high: demoRisks.filter(r => r.rpn >= 50 && r.rpn < 100).length,
        medium: demoRisks.filter(r => r.rpn >= 20 && r.rpn < 50).length,
        low: demoRisks.filter(r => r.rpn < 20).length,
        open: demoRisks.filter(r => r.status === 'Open').length,
        mitigation: demoRisks.filter(r => r.status === 'Mitigation').length,
        closed: demoRisks.filter(r => r.status === 'Closed').length,
      };
    }
  },

  async getCriticalRisks(): Promise<Risk[]> {
    try {
      const { data, error } = await supabase
        .from('risks')
        .select('*')
        .gte('rpn', 100)
        .eq('status', 'Open')
        .order('rpn', { ascending: false });

      if (error) throw handleSupabaseError(error, 'fetch critical risks');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo critical risks data');
      return demoRisks.filter(r => r.rpn >= 100 && r.status === 'Open').sort((a, b) => b.rpn - a.rpn);
    }
  },
};

async function generateRiskNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('risks')
    .select('*', { count: 'exact', head: true });

  const num = (count || 0) + 1;
  return `RISK-${year}-${num.toString().padStart(4, '0')}`;
}

// Map database record to Risk interface
function mapToRisk(data: any): Risk {
  return {
    id: data.id,
    riskId: data.risk_number,
    title: data.title,
    description: data.description,
    deviceName: data.device_name,
    deviceClass: data.device_class,
    intendedUse: data.intended_use,
    intendedUser: data.intended_user,
    useEnvironment: data.use_environment,
    hazardIdentification: data.hazard_identification,
    hazard: data.hazard,
    hazardousSituation: data.hazardous_situation,
    harm: data.harm,
    harmSeverity: data.harm_severity,
    harmSeverityClassification: data.harm_severity_classification,
    severity: data.severity,
    probability: data.probability,
    detectability: data.detectability,
    initialRPN: data.initial_rpn,
    riskLevel: data.risk_level,
    category: data.category,
    riskAcceptabilityCriteria: data.risk_acceptability_criteria,
    riskBenefitAnalysis: data.risk_benefit_analysis,
    mitigationMeasures: data.mitigation_measures,
    riskControlMeasures: data.risk_control_measures,
    riskControlOption: data.risk_control_option,
    residualSeverity: data.residual_severity,
    residualProbability: data.residual_probability,
    residualDetectability: data.residual_detectability,
    residualRPN: data.residual_rpn,
    residualRiskLevel: data.residual_risk_level,
    status: data.status,
    owner: data.owner,
    reviewFrequency: data.review_frequency,
    lastReviewed: data.last_reviewed,
    nextReview: data.next_review,
    verificationMethod: data.verification_method,
    verificationDate: data.verification_date,
    verifiedBy: data.verified_by,
    verificationEvidence: data.verification_evidence,
    feedbackSource: data.feedback_source,
    fieldSafetyIssue: data.field_safety_issue,
    trendAnalysis: data.trend_analysis,
    failureMode: data.failure_mode,
    failureEffect: data.failure_effect,
    failureCause: data.failure_cause,
    detectionMethod: data.detection_method,
    riskAnalysisReport: data.risk_analysis_report,
    riskManagementFile: data.risk_management_file,
    linkedCAPAId: data.linked_capa_id,
    linkedDeviationId: data.linked_deviation_id,
    linkedDocumentId: data.linked_document_id,
    createdDate: data.created_date,
    closedDate: data.closed_date,
    dueDate: data.due_date,
    created_by: data.created_by,
    created_at: data.created_at,
    updated_at: data.updated_at,
  };
}

export default riskService;
