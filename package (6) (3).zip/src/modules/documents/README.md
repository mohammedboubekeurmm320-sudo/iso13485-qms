# Documents Module

## Overview

This module handles all document control operations per ISO 13485 Section 4.2.4 requirements for controlled documents.

## Services

### documentService.ts

Main service for document CRUD operations.

#### Methods

- `getAll(filters?: DocumentFilters)` - Retrieve all documents with optional filtering
- `getById(id: string)` - Get a single document by ID
- `create(input, userId)` - Create a new document
- `update(id, input, userId)` - Update an existing document
- `delete(id, userId)` - Mark document as obsolete
- `signDocument(id, userId, userEmail, password, reason)` - Electronic signature
- `getStats()` - Get document statistics

### auditService.ts

Service for audit trail logging per ISO 13485 requirements.

#### Methods

- `logAudit(entry)` - Log an action to the audit trail
- `getAuditLogs(filters)` - Retrieve audit logs with filtering

## Hooks

### useDocuments

React Query hook for document list management.

```typescript
const { data, isLoading, error } = useDocuments({ type: 'SOP' });
```

### useSignDocument

Hook for document signing with electronic signature support.

## Types

```typescript
interface Document {
  id: string;
  documentNumber: string;
  title: string;
  type: 'SOP' | 'WI' | 'Form' | 'Policy' | 'Specification';
  version: string;
  status: 'Draft' | 'In Review' | 'Approved' | 'Obsolete';
  owner: string;
  department: string;
  effectiveDate: string;
  nextReview: string;
  description?: string;
}
```

## Compliance

- ISO 13485:2016 Section 4.2.4 - Control of documents
- FDA 21 CFR Part 11 - Electronic records and signatures
