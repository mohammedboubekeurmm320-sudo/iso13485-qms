// React Query Hooks pour les Documents
// Gestion du state et des side-effects pour les documents

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { documentService, DocumentFilters } from '../services/documentService';
import { Document } from '@/types/qms';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const documentKeys = {
  all: ['documents'] as const,
  lists: () => [...documentKeys.all, 'list'] as const,
  list: (filters: DocumentFilters) => [...documentKeys.lists(), filters] as const,
  details: () => [...documentKeys.all, 'detail'] as const,
  detail: (id: string) => [...documentKeys.details(), id] as const,
  stats: () => [...documentKeys.all, 'stats'] as const,
};

// Hook pour récupérer la liste des documents
export const useDocuments = (filters?: DocumentFilters) => {
  return useQuery({
    queryKey: documentKeys.list(filters || {}),
    queryFn: () => documentService.getAll(filters),
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
};

// Hook pour récupérer un document par ID
export const useDocument = (id: string) => {
  return useQuery({
    queryKey: documentKeys.detail(id),
    queryFn: () => documentService.getById(id),
    enabled: !!id, // Ne pas exécuter si pas d'ID
    staleTime: 5 * 60 * 1000,
  });
};

// Hook pour les statistiques des documents
export const useDocumentStats = () => {
  return useQuery({
    queryKey: documentKeys.stats(),
    queryFn: () => documentService.getStats(),
    staleTime: 60 * 1000, // 1 minute
  });
};

// Hook pour créer un document
export const useCreateDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      input,
      userId,
    }: {
      input: {
        title: string;
        type: string;
        description?: string;
        department?: string;
        owner?: string;
        // ISO 13485:2016 Section 4.2.4 fields
        documentNumber?: string;
        version?: string;
        classification?: 'Internal' | 'External' | 'Regulatory' | 'Confidential';
        retentionPeriod?: string;
        effectiveDate?: string;
        nextReviewDate?: string;
        scope?: string;
        references?: string;
        attachments?: string[];
      };
      userId: string;
    }) => documentService.create(input, userId),

    onSuccess: (data) => {
      // Invalider le cache pour forcer un refresh
      queryClient.invalidateQueries({ queryKey: documentKeys.all });
      queryClient.invalidateQueries({ queryKey: documentKeys.lists() });
      queryClient.invalidateQueries({ queryKey: documentKeys.stats() });
      
      // Also directly update the cache with the new document for immediate display
      // Update all possible list query variations
      queryClient.setQueryData<Document[]>(documentKeys.list({}), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: undefined }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: 'Draft' }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: 'Pending Review' }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: 'Approved' }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: 'Rejected' }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      queryClient.setQueryData<Document[]>(documentKeys.list({ status: 'Archived' }), (old) => {
        if (!old) return [data];
        return [data, ...old];
      });
      
      toast.success('Document created successfully', {
        description: `Document ${data.documentNumber} has been created.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to create document');
    },
  });
};

// Hook pour mettre à jour un document
export const useUpdateDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      input,
      userId,
    }: {
      id: string;
      input: {
        title?: string;
        description?: string;
        status?: string;
        version?: string;
      };
      userId: string;
    }) => documentService.update(id, input, userId),

    onSuccess: (data, variables) => {
      // Invalider le cache
      queryClient.invalidateQueries({ queryKey: documentKeys.all });
      queryClient.invalidateQueries({ queryKey: documentKeys.detail(variables.id) });
      queryClient.invalidateQueries({ queryKey: documentKeys.stats() });
      
      toast.success('Document updated successfully', {
        description: `Document has been updated.`,
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to update document');
    },
  });
};

// Hook pour supprimer un document
export const useDeleteDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      userId,
    }: {
      id: string;
      userId: string;
    }) => documentService.delete(id, userId),

    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: documentKeys.all });
      queryClient.invalidateQueries({ queryKey: documentKeys.stats() });
      
      toast.success('Document deleted successfully', {
        description: 'Document has been marked as obsolete.',
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to delete document');
    },
  });
};

// Hook pour signer un document
export const useSignDocument = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      documentId,
      userId,
      userEmail,
      password,
      reason,
    }: {
      documentId: string;
      userId: string;
      userEmail: string;
      password: string;
      reason: string;
    }) => documentService.signDocument(documentId, userId, userEmail, password, reason),

    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: documentKeys.all });
      queryClient.invalidateQueries({ queryKey: documentKeys.stats() });
      
      toast.success('Document signed successfully', {
        description: 'Electronic signature has been recorded.',
      });
    },

    onError: (error: Error) => {
      const qmsError = error as QMSError;
      toast.error(qmsError.userMessage || 'Failed to sign document');
    },
  });
};

export default {
  useDocuments,
  useDocument,
  useDocumentStats,
  useCreateDocument,
  useUpdateDocument,
  useDeleteDocument,
  useSignDocument,
};
