// React Query Hooks pour les Audit Logs
// Gestion du state et des side-effects pour les logs d'audit

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { auditApi, AuditFilters, AuditLogEntry } from '../services/auditService';
import { QMSError } from '@/lib/error/QMSError';
import { toast } from 'sonner';

// Clés de cache pour React Query
export const auditKeys = {
  all: ['audit'] as const,
  lists: () => [...auditKeys.all, 'list'] as const,
  list: (filters: AuditFilters) => [...auditKeys.lists(), filters] as const,
  details: () => [...auditKeys.all, 'detail'] as const,
  detail: (id: string) => [...auditKeys.details(), id] as const,
};

// Hook pour récupérer les logs d'audit
export const useAuditLogs = (filters?: AuditFilters) => {
  return useQuery({
    queryKey: auditKeys.list(filters || {}),
    queryFn: () => auditApi.getAuditLogs(filters),
    staleTime: 30 * 1000, // 30 secondes
    retry: 2,
  });
};

// Hook pour logger une action d'audit
export const useLogAudit = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (entry: AuditLogEntry) => auditApi.logAudit(entry),
    onSuccess: () => {
      // Invalider le cache pour refetcher les logs
      queryClient.invalidateQueries({ queryKey: auditKeys.all });
    },
    onError: (error: Error) => {
      const qmsError = error as QMSError;
      // Ne pas afficher de toast pour les erreurs d'audit - c'est secondaire
      console.error('Audit logging failed:', qmsError.message);
    },
  });
};

export default {
  useAuditLogs,
  useLogAudit,
};
