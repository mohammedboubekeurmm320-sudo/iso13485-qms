// Document Service - Couche de logique métier pour les documents
// Conforme ISO 13485 Section 4.2.4

import { supabase } from '@/lib/supabase';
import { Document } from '@/types/qms';
import { QMSError, handleSupabaseError, NetworkError, ComplianceError } from '@/lib/error/QMSError';
import { auditApi } from './auditService';
import { toast } from 'sonner';

// Demo documents store - persists during session
let demoDocumentsStore: Document[] = [
  {
    id: 'doc-001',
    documentNumber: 'SOP-QMS-001',
    title: 'Document Control Procedure',
    type: 'SOP',
    version: '3.0',
    status: 'Approved',
    effectiveDate: '2024-01-15',
    expirationDate: '',
    owner: 'quality@example.com',
    department: 'Quality Assurance',
    lastReviewed: '2024-01-15',
    nextReview: '2025-01-15',
    description: 'This procedure defines the requirements for the control of documents and data within the quality management system.',
    classification: 'Internal',
    retentionPeriod: '7 years',
    scope: 'Applies to all controlled documents',
    references: 'ISO 13485:2016 Section 4.2.4',
    attachments: [],
    created_at: '2024-01-01',
    updated_at: '2024-01-15',
  },
  {
    id: 'doc-002',
    documentNumber: 'SOP-QMS-002',
    title: 'Change Control Procedure',
    type: 'SOP',
    version: '2.1',
    status: 'Approved',
    effectiveDate: '2024-02-01',
    expirationDate: '',
    owner: 'quality@example.com',
    department: 'Quality Assurance',
    lastReviewed: '2024-02-01',
    nextReview: '2025-02-01',
    description: 'This procedure describes the process for managing changes to the quality management system.',
    classification: 'Internal',
    retentionPeriod: '7 years',
    scope: 'All changes to QMS processes',
    references: 'ISO 13485:2016 Section 7.3',
    attachments: [],
    created_at: '2024-02-01',
    updated_at: '2024-02-01',
  },
  {
    id: 'doc-003',
    documentNumber: 'WI-QMS-001',
    title: 'Document Creation Work Instruction',
    type: 'WI',
    version: '1.0',
    status: 'Approved',
    effectiveDate: '2024-01-20',
    expirationDate: '',
    owner: 'documents@example.com',
    department: 'Quality Assurance',
    lastReviewed: '2024-01-20',
    nextReview: '2025-01-20',
    description: 'Step-by-step instructions for creating new controlled documents.',
    classification: 'Internal',
    retentionPeriod: '7 years',
    scope: 'Document controllers',
    references: 'SOP-QMS-001',
    attachments: [],
    created_at: '2024-01-20',
    updated_at: '2024-01-20',
  },
  {
    id: 'doc-004',
    documentNumber: 'FORM-QMS-001',
    title: 'Document Request Form',
    type: 'Form',
    version: '2.0',
    status: 'Approved',
    effectiveDate: '2024-01-10',
    expirationDate: '',
    owner: 'documents@example.com',
    department: 'Quality Assurance',
    lastReviewed: '2024-01-10',
    nextReview: '2025-01-10',
    description: 'Form to request new documents or revisions to existing documents.',
    classification: 'Internal',
    retentionPeriod: '7 years',
    scope: 'All employees',
    references: 'SOP-QMS-001',
    attachments: [],
    created_at: '2024-01-10',
    updated_at: '2024-01-10',
  },
  {
    id: 'doc-005',
    documentNumber: 'POL-QMS-001',
    title: 'Quality Policy',
    type: 'Policy',
    version: '4.0',
    status: 'Approved',
    effectiveDate: '2024-01-01',
    expirationDate: '',
    owner: 'executive@example.com',
    department: 'Management',
    lastReviewed: '2024-01-01',
    nextReview: '2025-01-01',
    description: 'Top management commitment to quality and compliance with ISO 13485:2016.',
    classification: 'Internal',
    retentionPeriod: 'Permanent',
    scope: 'Entire organization',
    references: 'ISO 13485:2016 Section 5.3',
    attachments: [],
    created_at: '2024-01-01',
    updated_at: '2024-01-01',
  },
  {
    id: 'doc-006',
    documentNumber: 'SPC-TEC-001',
    title: 'Device Specifications',
    type: 'Specification',
    version: '1.0',
    status: 'In Review',
    effectiveDate: '2024-03-01',
    expirationDate: '',
    owner: 'quality@example.com',
    department: 'R&D',
    lastReviewed: '',
    nextReview: '2025-03-01',
    description: 'Technical specifications for the medical device.',
    classification: 'Confidential',
    retentionPeriod: 'Lifetime',
    scope: 'R&D, Production',
    references: 'IEC 60601-1',
    attachments: [],
    created_at: '2024-03-01',
    updated_at: '2024-03-01',
  },
];

// Types pour les filtres
export interface DocumentFilters {
  status?: string;
  type?: string;
  department?: string;
  search?: string;
}

// Interface for database response (snake_case)
interface DocumentDatabase {
  id: string;
  document_number: string;
  title: string;
  type: string;
  version: string;
  status: string;
  effective_date: string;
  expiration_date: string;
  owner: string;
  department: string;
  last_reviewed: string;
  next_review: string;
  description: string;
  classification?: string;
  retention_period?: string;
  scope?: string;
  references?: string;
  attachments?: string[];
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

// Mapper la réponse de la base de données vers le type TypeScript
const mapDatabaseToDocument = (dbDoc: DocumentDatabase): Document => ({
  id: dbDoc.id,
  documentNumber: dbDoc.document_number,
  title: dbDoc.title,
  type: dbDoc.type as Document['type'],
  version: dbDoc.version,
  status: dbDoc.status as Document['status'],
  effectiveDate: dbDoc.effective_date || '',
  expirationDate: dbDoc.expiration_date || '',
  owner: dbDoc.owner,
  department: dbDoc.department,
  lastReviewed: dbDoc.last_reviewed || '',
  nextReview: dbDoc.next_review || '',
  description: dbDoc.description || '',
  classification: dbDoc.classification as Document['classification'],
  retentionPeriod: dbDoc.retention_period,
  scope: dbDoc.scope,
  references: dbDoc.references,
  attachments: dbDoc.attachments,
  created_by: dbDoc.created_by,
  created_at: dbDoc.created_at,
  updated_at: dbDoc.updated_at,
});

export interface CreateDocumentInput {
  title: string;
  type: string;
  description?: string;
  department?: string;
  owner?: string;
  // ISO 13485:2016 Section 4.2.4 fields
  documentNumber?: string;
  version?: string;
  classification?: 'Internal' | 'External' | 'Regulatory' | 'Confidential';
  retentionPeriod?: string;
  effectiveDate?: string;
  nextReviewDate?: string;
  scope?: string;
  references?: string;
  attachments?: string[];
}

export interface UpdateDocumentInput {
  title?: string;
  description?: string;
  status?: string;
  version?: string;
}

// Récupérer tous les documents avec filtres
export const documentService = {
  async getAll(filters?: DocumentFilters): Promise<Document[]> {
    try {
      let query = supabase
        .from('documents')
        .select('*')
        .order('created_at', { ascending: false });

      // Application des filtres
      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        query = query.eq('type', filters.type);
      }
      if (filters?.department && filters.department !== 'all') {
        query = query.eq('department', filters.department);
      }
      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,document_number.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch documents');

      return (data || []).map(mapDatabaseToDocument);
    } catch (error) {
      // Return demo data from store if Supabase is not available
      console.log('Using demo documents store');
      
      // Apply filters to demo data
      let filteredDocs = demoDocumentsStore;
      if (filters?.status && filters.status !== 'all') {
        filteredDocs = filteredDocs.filter(d => d.status === filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        filteredDocs = filteredDocs.filter(d => d.type === filters.type);
      }
      if (filters?.department && filters.department !== 'all') {
        filteredDocs = filteredDocs.filter(d => d.department === filters.department);
      }
      if (filters?.search) {
        const searchLower = filters.search.toLowerCase();
        filteredDocs = filteredDocs.filter(d => 
          d.title.toLowerCase().includes(searchLower) || 
          d.documentNumber.toLowerCase().includes(searchLower)
        );
      }
      
      return filteredDocs;
    }
  },

  async getById(id: string): Promise<Document | null> {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw handleSupabaseError(error, 'fetch document by id');

      return data ? mapDatabaseToDocument(data) : null;
    } catch (error) {
      // Demo mode: search in local store
      const demoDoc = demoDocumentsStore.find(d => d.id === id);
      if (demoDoc) {
        return demoDoc;
      }
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to fetch document', { originalError: error as Error });
    }
  },

  async create(input: CreateDocumentInput, userId: string): Promise<Document> {
    try {
      // Générer un numéro de document unique (ou utiliser celui fourni)
      const docNumber = input.documentNumber || await generateDocumentNumber();

      const { data, error } = await supabase
        .from('documents')
        .insert({
          document_number: docNumber,
          title: input.title,
          type: input.type,
          description: input.description,
          department: input.department,
          owner: input.owner || 'Unknown',
          status: 'Draft',
          version: input.version || '1.0',
          created_by: userId,
          // ISO 13485:2016 Section 4.2.4 fields
          classification: input.classification || 'Internal',
          retention_period: input.retentionPeriod,
          effective_date: input.effectiveDate,
          next_review_date: input.nextReviewDate,
          scope: input.scope,
          references: input.references,
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create document');

      // Logger l'action dans l'audit trail
      await auditApi.logAudit({
        action: 'CREATE',
        tableName: 'documents',
        recordId: data.id,
        userId,
        newValues: data,
      });

      return data;
    } catch (error) {
      // Demo mode - return mock created document and add to store
      console.log('Creating demo document');
      const newDoc: Document = {
        id: `doc-${Date.now()}`,
        documentNumber: input.documentNumber || `DOC-${Date.now()}`,
        title: input.title,
        type: input.type as Document['type'],
        version: input.version || '1.0',
        status: 'Draft',
        effectiveDate: input.effectiveDate || '',
        expirationDate: '',
        owner: input.owner || 'Unknown',
        department: input.department || 'Quality Assurance',
        lastReviewed: '',
        nextReview: input.nextReviewDate || '',
        description: input.description || '',
        classification: input.classification || 'Internal',
        retentionPeriod: input.retentionPeriod || '7 years',
        scope: input.scope || '',
        references: input.references || '',
        attachments: [],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      
      // Add to demo store so it appears in the list
      demoDocumentsStore = [newDoc, ...demoDocumentsStore];
      
      toast.success('Document created successfully (Demo Mode)!');
      return newDoc;
    }
  },

  async update(id: string, input: UpdateDocumentInput, userId: string): Promise<Document> {
    try {
      // Récupérer l'ancien document pour l'audit trail
      const oldDoc = await this.getById(id);

      if (!oldDoc) {
        throw new QMSError('Document not found', { code: 'NOT_FOUND' });
      }

      // Vérifier si le document peut être modifié (règles de conformité)
      if (oldDoc.status === 'Approved' && input.status !== 'Approved') {
        throw new ComplianceError(
          'Cannot modify an approved document without creating a new version',
          { code: 'CANNOT_MODIFY_APPROVED' }
        );
      }

      const { data, error } = await supabase
        .from('documents')
        .update({
          ...input,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update document');

      // Logger l'action dans l'audit trail
      await auditApi.logAudit({
        action: 'UPDATE',
        tableName: 'documents',
        recordId: id,
        userId,
        oldValues: oldDoc,
        newValues: data,
      });

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update document', { originalError: error as Error });
    }
  },

  async delete(id: string, userId: string): Promise<void> {
    try {
      // Soft delete - marquer comme obsolète au lieu de supprimer
      const { error } = await supabase
        .from('documents')
        .update({
          status: 'Obsolete',
          updated_at: new Date().toISOString(),
        })
        .eq('id', id);

      if (error) throw handleSupabaseError(error, 'delete document');

      // Logger l'action dans l'audit trail
      await auditApi.logAudit({
        action: 'DELETE',
        tableName: 'documents',
        recordId: id,
        userId,
        newValues: { status: 'Obsolete' },
      });
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to delete document', { originalError: error as Error });
    }
  },

  async signDocument(
    documentId: string,
    userId: string,
    userEmail: string,
    password: string,
    reason: string
  ): Promise<Document> {
    // Demo mode: Accept password123 for demo accounts
    const isDemoMode = userEmail.includes('@example.com') && password === 'password123';
    
    try {
      // 1. Get the document (works in both modes now with demo fallback)
      const doc = await this.getById(documentId);
      if (!doc) {
        throw new QMSError('Document not found', { code: 'NOT_FOUND' });
      }

      // 2. Vérifier que le document est en statut permettant la signature
      if (doc.status !== 'In Review') {
        throw new ComplianceError(
          `Cannot sign document with status: ${doc.status}. Document must be in "In Review" status.`,
          { code: 'INVALID_DOCUMENT_STATUS' }
        );
      }

      // 3. Create signature hash
      const signatureHash = generateSignatureHash(documentId, userId, reason);

      // 4. Try to update document in Supabase
      let updatedDoc: Document | null = null;
      
      if (!isDemoMode) {
        // Non-demo mode: try Supabase
        const { data, error: updateError } = await supabase
          .from('documents')
          .update({
            status: 'Approved',
            updated_at: new Date().toISOString(),
          })
          .eq('id', documentId)
          .select()
          .single();

        if (!updateError && data) {
          updatedDoc = mapDatabaseToDocument(data);
          
          // Create signature record
          await supabase.from('signatures').insert({
            document_id: documentId,
            user_id: userId,
            user_email: userEmail,
            role: 'Approver',
            reason,
            hash: signatureHash,
            timestamp: new Date().toISOString(),
          });

          // Log audit
          await auditApi.logAudit({
            action: 'ELECTRONIC_SIGNATURE',
            tableName: 'documents',
            recordId: documentId,
            userId,
            newValues: { status: 'Approved', signatureHash, reason },
          });
        }
      }
      
      // If we're in demo mode or Supabase failed, update local store
      if (!updatedDoc) {
        const demoDoc = { ...doc, status: 'Approved' as const, updated_at: new Date().toISOString() };
        
        // Update in demo store
        const docIndex = demoDocumentsStore.findIndex(d => d.id === documentId);
        if (docIndex !== -1) {
          demoDocumentsStore[docIndex] = demoDoc;
        }
        
        return demoDoc;
      }

      return updatedDoc;
    } catch (error) {
      if (error instanceof QMSError || error instanceof ComplianceError) throw error;
      throw new NetworkError('Failed to sign document', { originalError: error as Error });
    }
  },

  // Statistiques pour le dashboard
  async getStats(): Promise<{
    total: number;
    approved: number;
    inReview: number;
    draft: number;
    obsolete: number;
  }> {
    try {
      const { data, error } = await supabase
        .from('documents')
        .select('status');

      if (error) throw handleSupabaseError(error, 'fetch document stats');

      const docs = data || [];
      return {
        total: docs.length,
        approved: docs.filter(d => d.status === 'Approved').length,
        inReview: docs.filter(d => d.status === 'In Review').length,
        draft: docs.filter(d => d.status === 'Draft').length,
        obsolete: docs.filter(d => d.status === 'Obsolete').length,
      };
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to fetch document stats', { originalError: error as Error });
    }
  },
};

// Fonction helper pour générer un numéro de document unique
async function generateDocumentNumber(): Promise<string> {
  const year = new Date().getFullYear();
  const { count } = await supabase
    .from('documents')
    .select('*', { count: 'exact', head: true });

  const num = (count || 0) + 1;
  return `DOC-${year}-${num.toString().padStart(4, '0')}`;
}

// Fonction helper pour générer un hash de signature
function generateSignatureHash(documentId: string, userId: string, reason: string): string {
  const data = `${documentId}:${userId}:${reason}:${Date.now()}`;
  // Utilisation de base64 pour simplifier (en production, utiliser SHA-256)
  return btoa(data);
}

export default documentService;
