# Users Module

## Overview

This module handles user management and authentication.

## Services

### userService.ts

Main service for user management.

#### Methods

- `getUsers(organizationId, filters?)` - Retrieve all users
- `getUserById(id)` - Get a single user
- `createUser(organizationId, userData)` - Create a new user
- `updateUser(id, userData)` - Update user
- `deleteUser(id)` - Delete a user
- `getUserStats()` - Get user statistics

## Hooks

### useUsers

React Query hook for user list management.

```typescript
const { data } = useUsers(orgId, { role: 'quality_manager' });
```

## Types

```typescript
interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  department?: string;
  job_title?: string;
  created_at?: string;
  updated_at?: string;
}

type UserRole = 
  | 'admin'
  | 'quality_manager'
  | 'auditor'
  | 'document_controller'
  | 'executive'
  | 'operator';
```

## Permissions

| Role | Permissions |
|------|-------------|
| admin | Full system access |
| quality_manager | Manage QMS processes |
| auditor | View audits and findings |
| document_controller | Manage documents |
| executive | View reports |
| operator | Execute procedures |
