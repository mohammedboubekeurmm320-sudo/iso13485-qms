// User Service - Service pour la gestion des utilisateurs
// Conforme aux exigences de gestion des utilisateurs ISO 13485

import { supabase } from '@/lib/supabase';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';

// Demo store for offline mode
const demoUsers: User[] = [
  {
    id: 'demo-user-1',
    email: 'admin@example.com',
    full_name: 'Admin User',
    role: 'admin',
    department: 'IT',
    job_title: 'System Administrator',
    created_at: '2024-01-01T10:00:00Z',
    updated_at: '2024-01-01T10:00:00Z',
  },
  {
    id: 'demo-user-2',
    email: 'quality@example.com',
    full_name: 'Sophie Bernard',
    role: 'quality_manager',
    department: 'Qualité',
    job_title: 'Responsable Qualité',
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
  },
  {
    id: 'demo-user-3',
    email: 'operator@example.com',
    full_name: 'Jean Dupont',
    role: 'operator',
    department: 'Production',
    job_title: 'Technicien de production',
    created_at: '2024-02-01T10:00:00Z',
    updated_at: '2024-02-01T10:00:00Z',
  },
];

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: string;
  department?: string;
  job_title?: string;
  created_at?: string;
  updated_at?: string;
}

export interface UserFilters {
  role?: string;
  department?: string;
  search?: string;
}

// Service de gestion des utilisateurs
export const userService = {
  // Récupérer tous les utilisateurs d'une organisation
  async getUsers(organizationId: string, filters?: UserFilters): Promise<User[]> {
    try {
      let query = supabase
        .from('users')
        .select('*')
        .eq('organization_id', organizationId)
        .order('full_name', { ascending: true });

      if (filters?.role && filters.role !== 'all') {
        query = query.eq('role', filters.role);
      }

      if (filters?.department && filters.department !== 'all') {
        query = query.eq('department', filters.department);
      }

      if (filters?.search) {
        query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch users');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo user data');
      let filtered = [...demoUsers];
      if (filters?.role && filters.role !== 'all') {
        filtered = filtered.filter(u => u.role === filters.role);
      }
      if (filters?.department && filters.department !== 'all') {
        filtered = filtered.filter(u => u.department === filters.department);
      }
      if (filters?.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(u => 
          u.full_name.toLowerCase().includes(search) || 
          u.email.toLowerCase().includes(search)
        );
      }
      return filtered.sort((a, b) => a.full_name.localeCompare(b.full_name));
    }
  },

  // Récupérer un utilisateur par ID
  async getUserById(userId: string): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null; // No rows returned
        throw handleSupabaseError(error, 'fetch user');
      }

      return data;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo user');
      return demoUsers.find(u => u.id === userId) || null;
    }
  },

  // Créer un nouvel utilisateur
  async createUser(organizationId: string, userData: Partial<User>): Promise<User> {
    try {
      const { data, error } = await supabase
        .from('users')
        .insert({
          organization_id: organizationId,
          email: userData.email,
          full_name: userData.full_name,
          role: userData.role || 'operator',
          department: userData.department,
          job_title: userData.job_title,
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create user');

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create user', { originalError: error as Error });
    }
  },

  // Mettre à jour un utilisateur
  async updateUser(userId: string, userData: Partial<User>): Promise<User> {
    try {
      const { data, error } = await supabase
        .from('users')
        .update({
          full_name: userData.full_name,
          role: userData.role,
          department: userData.department,
          job_title: userData.job_title,
          updated_at: new Date().toISOString(),
        })
        .eq('id', userId)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update user');

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update user', { originalError: error as Error });
    }
  },

  // Supprimer un utilisateur
  async deleteUser(userId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('users')
        .delete()
        .eq('id', userId);

      if (error) throw handleSupabaseError(error, 'delete user');
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to delete user', { originalError: error as Error });
    }
  },

  // Obtenir les statistiques des utilisateurs
  async getUserStats(organizationId: string): Promise<{
    total: number;
    byRole: Record<string, number>;
    byDepartment: Record<string, number>;
  }> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('role, department')
        .eq('organization_id', organizationId);

      if (error) throw handleSupabaseError(error, 'fetch user stats');

      const users = data || [];
      const byRole: Record<string, number> = {};
      const byDepartment: Record<string, number> = {};

      users.forEach(user => {
        byRole[user.role] = (byRole[user.role] || 0) + 1;
        if (user.department) {
          byDepartment[user.department] = (byDepartment[user.department] || 0) + 1;
        }
      });

      return {
        total: users.length,
        byRole,
        byDepartment,
      };
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo user stats');
      const byRole: Record<string, number> = {};
      const byDepartment: Record<string, number> = {};
      demoUsers.forEach(user => {
        byRole[user.role] = (byRole[user.role] || 0) + 1;
        if (user.department) {
          byDepartment[user.department] = (byDepartment[user.department] || 0) + 1;
        }
      });
      return {
        total: demoUsers.length,
        byRole,
        byDepartment,
      };
    }
  },
};

export default userService;
