# Audits Module

## Overview

This module handles audit management per ISO 13485 Section 8.2 requirements for internal and external audits.

## Services

### auditService.ts

Main service for audit management.

#### Methods

- `getAudits(organizationId, filters?)` - Retrieve all audits
- `getAuditById(id)` - Get a single audit by ID
- `createAudit(organizationId, auditData)` - Create a new audit
- `updateAudit(id, auditData)` - Update an existing audit
- `getAuditStats()` - Get audit statistics

## Hooks

### useAudits

React Query hook for audit list management.

```typescript
const { data, isLoading, error } = useAudits(orgId, { status: 'Scheduled' });
```

### useCreateAudit

Hook for creating new audits.

### useAuditStats

Hook for retrieving audit statistics.

## Types

```typescript
interface Audit {
  id: string;
  auditNumber: string;
  title: string;
  description?: string;
  type: 'Internal' | 'External' | 'Supplier';
  status: 'Scheduled' | 'In Progress' | 'Completed' | 'Cancelled';
  scheduledDate: string;
  completedDate?: string;
  leadAuditor: string;
  department: string;
  scope: string;
  findings: number;
  observations: number;
}
```

## Workflow

```
Scheduled → In Progress → Completed
```

## Compliance

- ISO 13485:2016 Section 8.2 - Internal audit
- ISO 19011 - Guidelines for auditing management systems
