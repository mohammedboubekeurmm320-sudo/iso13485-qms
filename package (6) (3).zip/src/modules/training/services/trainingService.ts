// Training Service - Service pour la gestion des formations
// Conforme ISO 13485 Section 7.2 & 7.3

import { supabase } from '@/lib/supabase';
import { TrainingRecord } from '@/types/qms';
import { QMSError, handleSupabaseError, NetworkError } from '@/lib/error/QMSError';
import { auditApi } from '../../documents/services/auditService';

// Demo store for offline mode
const demoTrainings: TrainingRecord[] = [
  {
    id: 'demo-training-1',
    employeeId: 'EMP001',
    employeeName: 'Jean Dupont',
    employeeEmail: 'jean.dupont@example.com',
    department: 'Production',
    jobTitle: 'Technicien de production',
    trainingTitle: 'GMP - Bonnes Pratiques de Fabrication',
    trainingType: 'Initial',
    trainingCategory: 'GMP',
    trainingProvider: 'Société de formation QMS',
    status: 'Completed',
    completedDate: '2024-01-15',
    dueDate: '2025-01-15',
    startDate: '2024-01-10',
    expirationDate: '2025-01-15',
    trainer: 'Marie Martin',
    trainingMethod: 'Classroom',
    trainingDuration: '2 jours',
    assessmentMethod: 'Exam',
    score: 85,
    passingScore: 70,
    documentRef: 'DOC-GMP-001',
    certificateNumber: 'CERT-2024-001',
    created_by: 'demo-user-1',
    created_at: '2024-01-10T10:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
  },
  {
    id: 'demo-training-2',
    employeeId: 'EMP002',
    employeeName: 'Sophie Bernard',
    employeeEmail: 'sophie.bernard@example.com',
    department: 'Qualité',
    jobTitle: 'Responsable Qualité',
    trainingTitle: 'ISO 13485:2016 - Systèmes de Management de la Qualité',
    trainingType: 'Refresher',
    trainingCategory: 'ISO 13485',
    trainingProvider: 'Institut de Formation Médicale',
    status: 'Scheduled',
    dueDate: '2024-06-01',
    startDate: '2024-05-28',
    trainer: 'Pierre Durant',
    trainingMethod: 'Online',
    trainingDuration: '1 jour',
    assessmentMethod: 'Exam',
    passingScore: 75,
    documentRef: 'DOC-ISO-001',
    created_by: 'demo-user-1',
    created_at: '2024-02-01T10:00:00Z',
    updated_at: '2024-02-01T10:00:00Z',
  },
  {
    id: 'demo-training-3',
    employeeId: 'EMP003',
    employeeName: 'Pierre Martin',
    employeeEmail: 'pierre.martin@example.com',
    department: 'R&D',
    jobTitle: 'Ingénieur R&D',
    trainingTitle: 'Validation des processus de stérilisation',
    trainingType: 'Certification',
    trainingCategory: 'Technical',
    trainingProvider: 'Centre de Formation Technique',
    status: 'Completed',
    completedDate: '2024-02-20',
    dueDate: '2025-02-20',
    startDate: '2024-02-15',
    expirationDate: '2025-02-20',
    trainer: 'Jean-Claude Petit',
    trainingMethod: 'Workshop',
    trainingDuration: '3 jours',
    assessmentMethod: 'Practical',
    score: 92,
    passingScore: 80,
    documentRef: 'DOC-VAL-001',
    certificateNumber: 'CERT-2024-002',
    effectivenessCriteria: 'Capacité à réaliser une validation complète',
    effectivenessEvaluation: 'Compétent',
    created_by: 'demo-user-2',
    created_at: '2024-02-15T10:00:00Z',
    updated_at: '2024-02-20T10:00:00Z',
  },
];

export interface TrainingFilters {
  status?: string;
  type?: string;
  department?: string;
  search?: string;
}

export interface CreateTrainingInput {
  // Employee Information - ISO 13485:7.2
  employeeName: string;
  employeeId?: string;
  employeeEmail?: string;
  department: string;
  jobTitle?: string;
  
  // Training Details - ISO 13485:7.2
  trainingTitle: string;
  trainingType: 'Initial' | 'Refresher' | 'Certification' | 'On-the-Job' | 'External';
  trainingCategory?: 'GMP' | 'ISO 13485' | 'Quality' | 'Technical' | 'Safety' | 'Regulatory' | 'Software' | 'Process';
  trainingProvider?: string;
  trainingLocation?: string;
  
  // ISO 13485:7.2 - Competence requirements
  competenceRequirements?: string;
  skillsMatrixArea?: string;
  
  // Status and dates
  dueDate: string;
  startDate?: string;
  expirationDate?: string;
  
  // Training delivery
  trainer?: string;
  trainingMethod?: 'Classroom' | 'Online' | 'OJT' | 'Workshop' | 'External Course' | 'Self-Paced';
  trainingDuration?: string;
  
  // Assessment - ISO 13485:7.3
  assessmentMethod?: 'Exam' | 'Practical' | 'Observation' | 'Certification' | 'Portfolio';
  passingScore?: number;
  
  // Documentation - ISO 13485:7.3
  documentRef: string;
  trainingMaterialRef?: string;
  
  // Effectiveness - ISO 13485:7.3.1
  effectivenessCriteria?: string;
  
  // Links to other modules
  linkedCAPAId?: string;
  linkedAuditId?: string;
}

export interface UpdateTrainingInput {
  status?: string;
  completionDate?: string;
  certificateUrl?: string;
}

export const trainingService = {
  async getAll(filters?: TrainingFilters): Promise<TrainingRecord[]> {
    try {
      let query = supabase
        .from('training_records')
        .select('*')
        .order('created_at', { ascending: false });

      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        query = query.eq('training_type', filters.type);
      }
      if (filters?.department && filters.department !== 'all') {
        query = query.eq('department', filters.department);
      }
      if (filters?.search) {
        query = query.or(`employee_name.ilike.%${filters.search}%,training_title.ilike.%${filters.search}%`);
      }

      const { data, error } = await query;

      if (error) throw handleSupabaseError(error, 'fetch training records');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo training data');
      let filtered = [...demoTrainings];
      if (filters?.status && filters.status !== 'all') {
        filtered = filtered.filter(t => t.status === filters.status);
      }
      if (filters?.type && filters.type !== 'all') {
        filtered = filtered.filter(t => t.trainingType === filters.type);
      }
      if (filters?.department && filters.department !== 'all') {
        filtered = filtered.filter(t => t.department === filters.department);
      }
      if (filters?.search) {
        const search = filters.search.toLowerCase();
        filtered = filtered.filter(t => 
          t.employeeName.toLowerCase().includes(search) || 
          t.trainingTitle.toLowerCase().includes(search)
        );
      }
      return filtered.sort((a, b) => new Date(b.created_at || '').getTime() - new Date(a.created_at || '').getTime());
    }
  },

  async getById(id: string): Promise<TrainingRecord | null> {
    try {
      const { data, error } = await supabase
        .from('training_records')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw handleSupabaseError(error, 'fetch training record');

      return data;
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo training record');
      return demoTrainings.find(t => t.id === id) || null;
    }
  },

  async create(input: CreateTrainingInput, userId: string): Promise<TrainingRecord> {
    try {
      const { data, error } = await supabase
        .from('training_records')
        .insert({
          // Employee Information
          employee_id: input.employeeId,
          employee_name: input.employeeName,
          employee_email: input.employeeEmail,
          department: input.department,
          job_title: input.jobTitle,
          
          // Training Details
          training_title: input.trainingTitle,
          training_type: input.trainingType,
          training_category: input.trainingCategory,
          training_provider: input.trainingProvider,
          training_location: input.trainingLocation,
          
          // Competence requirements
          competence_requirements: input.competenceRequirements,
          skills_matrix_area: input.skillsMatrixArea,
          
          // Dates
          due_date: input.dueDate,
          start_date: input.startDate,
          expiration_date: input.expirationDate,
          
          // Training delivery
          trainer: input.trainer,
          training_method: input.trainingMethod,
          training_duration: input.trainingDuration,
          
          // Assessment
          assessment_method: input.assessmentMethod,
          passing_score: input.passingScore,
          
          // Documentation
          document_ref: input.documentRef,
          training_material_ref: input.trainingMaterialRef,
          
          // Effectiveness
          effectiveness_criteria: input.effectivenessCriteria,
          
          // Links
          linked_capa_id: input.linkedCAPAId,
          linked_audit_id: input.linkedAuditId,
          
          // Default status
          status: 'Scheduled',
          created_by: userId,
        })
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'create training record');

      await auditApi.logAudit({
        action: 'CREATE',
        tableName: 'training_records',
        recordId: data.id,
        userId,
        newValues: data,
      });

      return mapToTrainingRecord(data);
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to create training record', { originalError: error as Error });
    }
  },

  async update(id: string, input: UpdateTrainingInput, userId: string): Promise<TrainingRecord> {
    try {
      const oldRecord = await this.getById(id);

      const { data, error } = await supabase
        .from('training_records')
        .update({
          ...input,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .select()
        .single();

      if (error) throw handleSupabaseError(error, 'update training record');

      await auditApi.logAudit({
        action: 'UPDATE',
        tableName: 'training_records',
        recordId: id,
        userId,
        oldValues: oldRecord,
        newValues: data,
      });

      return data;
    } catch (error) {
      if (error instanceof QMSError) throw error;
      throw new NetworkError('Failed to update training record', { originalError: error as Error });
    }
  },

  async complete(id: string, certificateUrl: string, userId: string): Promise<TrainingRecord> {
    return this.update(id, {
      status: 'Completed',
      completionDate: new Date().toISOString().split('T')[0],
      certificateUrl,
    }, userId);
  },

  async getStats(): Promise<{
    total: number;
    completed: number;
    scheduled: number;
    expired: number;
  }> {
    try {
      const { data, error } = await supabase
        .from('training_records')
        .select('status, expiry_date');

      if (error) throw handleSupabaseError(error, 'fetch training stats');

      const records = data || [];
      const today = new Date().toISOString().split('T')[0];

      return {
        total: records.length,
        completed: records.filter(r => r.status === 'Completed').length,
        scheduled: records.filter(r => r.status === 'Scheduled').length,
        expired: records.filter(r => r.expiry_date && r.expiry_date < today).length,
      };
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo training stats');
      const today = new Date().toISOString().split('T')[0];
      return {
        total: demoTrainings.length,
        completed: demoTrainings.filter(t => t.status === 'Completed').length,
        scheduled: demoTrainings.filter(t => t.status === 'Scheduled').length,
        expired: demoTrainings.filter(t => t.expirationDate && t.expirationDate < today).length,
      };
    }
  },

  async getExpiringTrainings(days: number = 30): Promise<TrainingRecord[]> {
    try {
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + days);

      const { data, error } = await supabase
        .from('training_records')
        .select('*')
        .lte('expiry_date', futureDate.toISOString().split('T')[0])
        .eq('status', 'Completed')
        .order('expiry_date', { ascending: true });

      if (error) throw handleSupabaseError(error, 'fetch expiring trainings');

      return data || [];
    } catch (error) {
      // Fallback to demo data in offline mode
      console.log('Using demo expiring trainings');
      const futureDate = new Date();
      futureDate.setDate(futureDate.getDate() + days);
      return demoTrainings.filter(t => 
        t.status === 'Completed' && 
        t.expirationDate && 
        t.expirationDate <= futureDate.toISOString().split('T')[0]
      ).sort((a, b) => (a.expirationDate || '').localeCompare(b.expirationDate || ''));
    }
  },
};

// Map database record to TrainingRecord interface
function mapToTrainingRecord(data: any): TrainingRecord {
  return {
    id: data.id,
    employeeId: data.employee_id,
    employeeName: data.employee_name,
    employeeEmail: data.employee_email,
    department: data.department,
    jobTitle: data.job_title,
    trainingTitle: data.training_title,
    trainingType: data.training_type,
    trainingCategory: data.training_category,
    trainingProvider: data.training_provider,
    trainingLocation: data.training_location,
    competenceRequirements: data.competence_requirements,
    skillsMatrixArea: data.skills_matrix_area,
    status: data.status,
    completedDate: data.completed_date,
    dueDate: data.due_date,
    startDate: data.start_date,
    expirationDate: data.expiration_date,
    trainer: data.trainer,
    trainingMethod: data.training_method,
    trainingDuration: data.training_duration,
    assessmentMethod: data.assessment_method,
    score: data.score,
    passingScore: data.passing_score,
    assessmentDate: data.assessment_date,
    assessorName: data.assessor_name,
    documentRef: data.document_ref,
    certificateNumber: data.certificate_number,
    certificateUrl: data.certificate_url,
    trainingMaterialRef: data.training_material_ref,
    effectivenessCriteria: data.effectiveness_criteria,
    effectivenessEvaluation: data.effectiveness_evaluation,
    effectivenessComments: data.effectiveness_comments,
    verifiedBy: data.verified_by,
    verificationDate: data.verification_date,
    approvalStatus: data.approval_status,
    approvedBy: data.approved_by,
    approvalDate: data.approval_date,
    linkedCAPAId: data.linked_capa_id,
    linkedAuditId: data.linked_audit_id,
    created_by: data.created_by,
    created_at: data.created_at,
    updated_at: data.updated_at,
  };
}

export default trainingService;
