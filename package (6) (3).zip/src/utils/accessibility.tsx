// Accessibility utilities and components

import React, { useEffect, useRef } from 'react';

/**
 * Hook for managing focus within a modal or dropdown
 * Creates a focus trap for accessibility
 */
export const useFocusTrap = (isActive: boolean = false) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isActive) return;

    const container = containerRef.current;
    if (!container) return;

    const focusableElements = container.querySelectorAll(
      'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
    );
    
    const firstElement = focusableElements[0] as HTMLElement;
    const lastElement = focusableElements[focusableElements.length - 1] as HTMLElement;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key !== 'Tab') return;

      if (e.shiftKey) {
        if (document.activeElement === firstElement) {
          lastElement?.focus();
          e.preventDefault();
        }
      } else {
        if (document.activeElement === lastElement) {
          firstElement?.focus();
          e.preventDefault();
        }
      }
    };

    container.addEventListener('keydown', handleKeyDown);
    firstElement?.focus();

    return () => {
      container.removeEventListener('keydown', handleKeyDown);
    };
  }, [isActive]);

  return containerRef;
};

/**
 * Skip link component for keyboard navigation
 */
export const SkipLink = ({ targetId, children }: { targetId: string; children: React.ReactNode }) => (
  <a
    href={`#${targetId}`}
    className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-blue-600 focus:text-white focus:rounded-lg"
  >
    {children}
  </a>
);

/**
 * Live region for announcing dynamic content to screen readers
 */
export const LiveRegion = ({ message, priority = 'polite' }: { message: string; priority?: 'polite' | 'assertive' }) => {
  const regionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (regionRef.current) {
      regionRef.current.textContent = message;
    }
  }, [message]);

  return (
    <div
      ref={regionRef}
      role="status"
      aria-live={priority}
      aria-atomic="true"
      className="sr-only"
    />
  );
};

/**
 * Icon button with proper ARIA label
 */
export const IconButton = ({
  icon,
  label,
  onClick,
  className = '',
  disabled = false,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  className?: string;
  disabled?: boolean;
}) => (
  <button
    onClick={onClick}
    disabled={disabled}
    aria-label={label}
    className={`p-2 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
  >
    {icon}
  </button>
);

/**
 * Table with proper ARIA annotations
 */
export const AccessibleTable = ({
  columns,
  data,
  caption,
  onRowClick,
}: {
  columns: { key: string; header: string }[];
  data: any[];
  caption: string;
  onRowClick?: (row: any) => void;
}) => (
  <table 
    role="grid"
    aria-label={caption}
    className="w-full"
  >
    <caption className="sr-only">{caption}</caption>
    <thead>
      <tr role="row">
        {columns.map((col) => (
          <th
            key={col.key}
            scope="col"
            role="columnheader"
            className="px-4 py-3 text-left text-sm font-medium text-gray-500"
          >
            {col.header}
          </th>
        ))}
      </tr>
    </thead>
    <tbody role="rowgroup">
      {data.map((row, idx) => (
        <tr
          key={idx}
          role="row"
          onClick={() => onRowClick?.(row)}
          className={onRowClick ? 'cursor-pointer hover:bg-gray-50' : ''}
        >
          {columns.map((col) => (
            <td key={col.key} role="cell" className="px-4 py-3 text-sm text-gray-900">
              {row[col.key]}
            </td>
          ))}
        </tr>
      ))}
    </tbody>
  </table>
);

/**
 * Form field with proper labeling
 */
export const AccessibleField = ({
  label,
  error,
  required = false,
  children,
}: {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
}) => (
  <div className="space-y-1">
    <label className="block text-sm font-medium text-gray-700">
      {label}
      {required && <span className="text-red-500 ml-1" aria-hidden="true">*</span>}
    </label>
    {children}
    {error && (
      <p role="alert" className="text-sm text-red-600">
        {error}
      </p>
    )}
  </div>
);

/**
 * Modal with focus trap and ARIA attributes
 */
export const AccessibleModal = ({
  isOpen,
  onClose,
  title,
  children,
}: {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}) => {
  const modalRef = useFocusTrap(isOpen);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 overflow-y-auto"
    >
      <div className="flex min-h-screen items-center justify-center p-4">
        <div 
          className="fixed inset-0 bg-black/50" 
          aria-hidden="true"
          onClick={onClose}
        />
        <div 
          ref={modalRef}
          className="relative bg-white rounded-xl shadow-xl max-w-lg w-full p-6"
        >
          <h2 id="modal-title" className="text-xl font-semibold mb-4">
            {title}
          </h2>
          {children}
        </div>
      </div>
    </div>
  );
};

export default {
  useFocusTrap,
  SkipLink,
  LiveRegion,
  IconButton,
  AccessibleTable,
  AccessibleField,
  AccessibleModal,
};
