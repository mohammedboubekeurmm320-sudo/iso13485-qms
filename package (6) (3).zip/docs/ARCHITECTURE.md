# Architecture Documentation

## Overview

This document describes the architecture of the Quality Management System (QMS) built with React, TypeScript, and Supabase.

## Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + TypeScript |
| State Management | React Query (TanStack Query) |
| Database | Supabase (PostgreSQL) |
| Styling | Tailwind CSS |
| Error Handling | Custom QMSError hierarchy |
| Testing | Vitest |
| Build Tool | Vite |

## Project Structure

```
src/
├── components/          # React UI components
│   ├── ui/            # Reusable UI components
│   ├── auth/          # Authentication components
│   └── compliance/    # Compliance-related components
├── contexts/          # React Context providers
├── modules/           # Domain modules (DDD)
│   ├── documents/
│   ├── capas/
│   ├── audits/
│   ├── training/
│   ├── non-conformances/
│   ├── risks/
│   ├── users/
│   └── legal-documents/
├── lib/               # Utility libraries
│   ├── error/         # Error handling
│   └── monitoring/    # Sentry integration
├── types/             # TypeScript type definitions
└── hooks/            # Custom React hooks
```

## Domain-Driven Design (DDD)

The application follows a modular DDD architecture where each business domain is encapsulated in its own module:

### Module Structure

Each module follows a consistent structure:

```
module-name/
├── services/          # Business logic
│   └── *.ts         # Service implementation
├── hooks/            # React Query hooks
│   └── use*.ts      # Custom hooks
└── README.md         # Module documentation
```

### Service Layer

Services encapsulate all business logic and database operations:

```typescript
// Example: documentService.ts
export const documentService = {
  async getAll(filters?: DocumentFilters): Promise<Document[]> {
    // Business logic here
  },
  
  async create(input: CreateDocumentInput): Promise<Document> {
    // Validation and creation
  }
};
```

### Hook Layer

React Query hooks provide a clean interface for data fetching:

```typescript
// Example: useDocuments.ts
export const useDocuments = (filters?: DocumentFilters) => {
  return useQuery({
    queryKey: documentKeys.list(filters),
    queryFn: () => documentService.getAll(filters),
    staleTime: 5 * 60 * 1000,
  });
};
```

## State Management

### Server State

Server state is managed using React Query, which provides:

- **Automatic caching** - Data is cached and reused
- **Background refetching** - Stale data is refreshed automatically
- **Optimistic updates** - UI updates before server confirmation
- **Error handling** - Automatic retry on failure

### Client State

Client state is managed using React Context:

- `AuthContext` - User authentication
- `OrganizationContext` - Multi-tenant organization
- `NotificationContext` - Toast notifications

## Error Handling

### Error Hierarchy

```
QMSError (base)
├── ValidationError
├── AuthError
├── NetworkError
└── NotFoundError
```

### Error Boundaries

React Error Boundaries catch component errors:

```typescript
// ErrorBoundary.tsx
class ErrorBoundary extends React.Component {
  componentDidCatch(error, errorInfo) {
    // Log to Sentry
    captureException(error, { extra: errorInfo });
  }
}
```

## Security

### Authentication

- Supabase Auth for user management
- JWT-based session handling
- Role-based access control (RBAC)

### Permissions

| Role | canCreate | canEdit | canApprove | canExport |
|------|-----------|---------|------------|-----------|
| admin | ✓ | ✓ | ✓ | ✓ |
| quality_manager | ✓ | ✓ | ✓ | ✓ |
| auditor | ✗ | ✗ | ✗ | ✓ |
| document_controller | ✓ | ✓ | ✗ | ✓ |
| operator | ✗ | ✗ | ✗ | ✗ |

### Row Level Security (RLS)

Supabase RLS policies ensure data isolation between organizations.

## Performance Optimization

### Code Splitting

Components are lazy-loaded:

```typescript
const DocumentControl = lazy(() => import('./DocumentControl'));
```

### Memoization

Expensive computations use `useMemo`:

```typescript
const filteredDocuments = useMemo(() => {
  return documents.filter(doc => filterLogic);
}, [documents, filters]);
```

### Query Optimization

React Query settings:

- `staleTime` - Time before data becomes stale
- `cacheTime` - Time to keep unused data in cache
- `refetchOnWindowFocus` - Refetch when window gains focus

## Testing Strategy

### Unit Tests

Services and hooks are tested with Vitest:

```typescript
describe('documentService', () => {
  it('should fetch documents', async () => {
    const docs = await documentService.getAll();
    expect(docs).toBeDefined();
  });
});
```

### Integration Tests

React Query tests verify hook behavior.

## Compliance

### ISO 13485:2016

The system implements all required QMS processes:

| Requirement | Implementation |
|-------------|----------------|
| Document Control | Documents module |
| Records Control | Supabase storage |
| Management Review | Reports module |
| Internal Audit | Audits module |
| CAPA | CAPA module |
| Risk Management | Risks module |
| Training | Training module |

### FDA 21 CFR Part 11

- Electronic signatures
- Audit trail
- System access controls

## Deployment

The application is deployed to a static hosting platform:

- Build: Vite
- Optimization: Code splitting, tree shaking
- CDN: Global distribution
