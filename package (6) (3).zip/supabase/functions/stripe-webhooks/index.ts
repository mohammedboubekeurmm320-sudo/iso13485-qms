// Stripe Webhooks Handler
// This would be deployed as a Supabase Edge Function
// File: supabase/functions/stripe-webhooks/index.ts

import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const stripe = require('https://esm.sh/stripe@14?target=deno');

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const stripeSecretKey = Deno.env.get('STRIPE_SECRET_KEY')!;
const webhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!;

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const stripeClient = new stripe(stripeSecretKey);

serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  const signature = req.headers.get('stripe-signature')!;
  const body = await req.text();

  let event;

  try {
    event = stripeClient.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return new Response('Webhook signature verification failed', { status: 400 });
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const organizationId = session.metadata?.organizationId;
        
        if (!organizationId) {
          console.error('No organization ID in session metadata');
          break;
        }

        // Create or update subscription
        await supabase.from('subscriptions').upsert({
          organization_id: organizationId,
          stripe_subscription_id: session.subscription,
          stripe_customer_id: session.customer,
          stripe_price_id: session.line_items?.data[0]?.price?.id,
          status: 'active',
          current_period_start: new Date().toISOString(),
        }, {
          onConflict: 'organization_id'
        });

        // Update organization subscription status
        await supabase.from('organizations').update({
          subscription_status: 'active'
        }).eq('id', organizationId);

        console.log('Checkout completed for org:', organizationId);
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object;
        const customerId = invoice.customer;
        
        // Find organization by customer ID
        const { data: subscription } = await supabase
          .from('subscriptions')
          .select('organization_id')
          .eq('stripe_customer_id', customerId)
          .single();

        if (subscription) {
          // Update subscription period
          await supabase.from('subscriptions').update({
            status: 'active',
            current_period_start: new Date(invoice.period_start * 1000).toISOString(),
            current_period_end: new Date(invoice.period_end * 1000).toISOString(),
          }).eq('organization_id', subscription.organization_id);

          // Create invoice record
          await supabase.from('invoices').insert({
            organization_id: subscription.organization_id,
            stripe_invoice_id: invoice.id,
            amount: invoice.amount_paid,
            currency: invoice.currency,
            status: 'paid',
            invoice_number: invoice.number,
            pdf_url: invoice.invoice_pdf,
            hosted_invoice_url: invoice.hosted_invoice_url,
            invoice_date: new Date(invoice.created * 1000).toISOString(),
            paid_at: new Date().toISOString(),
          });

          // Update organization status
          await supabase.from('organizations').update({
            subscription_status: 'active'
          }).eq('id', subscription.organization_id);
        }

        console.log('Payment succeeded for customer:', customerId);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        const customerId = invoice.customer;

        const { data: subscription } = await supabase
          .from('subscriptions')
          .select('organization_id')
          .eq('stripe_customer_id', customerId)
          .single();

        if (subscription) {
          await supabase.from('subscriptions').update({
            status: 'past_due',
          }).eq('organization_id', subscription.organization_id);

          await supabase.from('organizations').update({
            subscription_status: 'past_due'
          }).eq('id', subscription.organization_id);
        }

        console.log('Payment failed for customer:', customerId);
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object;
        
        const { data: existingSub } = await supabase
          .from('subscriptions')
          .select('organization_id')
          .eq('stripe_subscription_id', subscription.id)
          .single();

        if (existingSub) {
          let status = subscription.status;
          if (subscription.cancel_at_period_end && !subscription.canceled_at) {
            status = 'active'; // Still active until period end
          }

          await supabase.from('subscriptions').update({
            status,
            cancel_at_period_end: subscription.cancel_at_period_end,
            current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
          }).eq('stripe_subscription_id', subscription.id);

          // Update organization status
          const orgStatus = subscription.status === 'active' ? 'active' : 
                           subscription.cancel_at_period_end ? 'active' : 'canceled';
          await supabase.from('organizations').update({
            subscription_status: orgStatus
          }).eq('id', existingSub.organization_id);
        }

        console.log('Subscription updated:', subscription.id);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;

        await supabase.from('subscriptions').update({
          status: 'canceled',
        }).eq('stripe_subscription_id', subscription.id);

        const { data: existingSub } = await supabase
          .from('subscriptions')
          .select('organization_id')
          .eq('stripe_subscription_id', subscription.id)
          .single();

        if (existingSub) {
          await supabase.from('organizations').update({
            subscription_status: 'canceled'
          }).eq('id', existingSub.organization_id);
        }

        console.log('Subscription deleted:', subscription.id);
        break;
      }

      default:
        console.log('Unhandled event type:', event.type);
    }

    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (err) {
    console.error('Error processing webhook:', err);
    return new Response('Webhook processing failed', { status: 500 });
  }
});
